Quantara CI Baseline Repair — 2026-08-16

Pinned base:
c61f1a3fd6ae996704e471b96cd4fe29c01872e5

Expected worktree:
C:\Users\PC\Desktop\quantara-ai-boq\.worktrees\ci-baseline-20260816

Expected branch:
fix/ci-baseline-20260816

Purpose:
Repair only the five CI baseline failures blocking TAYQAN PR #52:
- Cloudflare actor request-context wrapping for the three refund routes
- /login signed-in-looking redirect contract
- remove two obsolete HTTP migration/schema writers and preserve the historical Prisma migration
- allow explicit Arabic-screen technical identifiers while still rejecting English prose
- update stale extraction→BOQ bridge test to the merged AI Draft workflow

Safety:
- Does not touch the dirty primary checkout.
- Does not touch PR #52.
- No production database writes.
- No Prisma command.
- No npm install.
- No Stripe provider or fulfillment code change.
- No schema or migration file modification.
- No reset/clean/stash/force-push.
- Full DB-backed suite is intentionally left to GitHub CI's ephemeral PostgreSQL.

The script stops automatically if the pinned baseline or expected failure shape has moved.
