$ErrorActionPreference = "Stop"

$root   = "$env:USERPROFILE\Desktop\quantara-ai-boq"
$wt     = "$root\.worktrees\ci-baseline-20260816"
$branch = "fix/ci-baseline-20260816"
$base   = "c61f1a3fd6ae996704e471b96cd4fe29c01872e5"

function Stop-Now([string]$Message) {
    throw "STOP: $Message"
}

function Read-Normalized([string]$Path) {
    return ([System.IO.File]::ReadAllText($Path)).Replace("`r`n", "`n")
}

function Write-Utf8NoBom([string]$Path, [string]$Text) {
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Text.Replace("`r`n", "`n"), $utf8)
}

function Replace-Exact([string]$Path, [string]$Old, [string]$New) {
    $text = Read-Normalized $Path
    $oldNorm = $Old.Replace("`r`n", "`n")
    $newNorm = $New.Replace("`r`n", "`n")

    $first = $text.IndexOf($oldNorm, [System.StringComparison]::Ordinal)
    if ($first -lt 0) {
        Stop-Now "Expected pre-image not found in $Path"
    }

    $second = $text.IndexOf($oldNorm, $first + $oldNorm.Length, [System.StringComparison]::Ordinal)
    if ($second -ge 0) {
        Stop-Now "Expected pre-image appears more than once in $Path"
    }

    Write-Utf8NoBom $Path ($text.Substring(0, $first) + $newNorm + $text.Substring($first + $oldNorm.Length))
}

function Relative-RepoPath([string]$FullName) {
    return $FullName.Substring($wt.Length + 1).Replace("\", "/")
}

function Assert-SameSet([string[]]$Actual, [string[]]$Expected, [string]$Label) {
    $a = @($Actual | Sort-Object -Unique)
    $e = @($Expected | Sort-Object -Unique)
    $delta = @(Compare-Object -ReferenceObject $e -DifferenceObject $a)
    if ($delta.Count -gt 0) {
        Write-Host "`n$Label mismatch:" -ForegroundColor Red
        Write-Host "Expected:" -ForegroundColor Yellow
        $e | ForEach-Object { Write-Host "  $_" }
        Write-Host "Actual:" -ForegroundColor Yellow
        $a | ForEach-Object { Write-Host "  $_" }
        Stop-Now "$Label did not match the pinned baseline."
    }
}

Write-Host "`n=== CI BASELINE REPAIR — PINNED PREFLIGHT ===" -ForegroundColor Cyan

if (-not (Test-Path -LiteralPath $wt)) {
    Stop-Now "CI baseline worktree does not exist: $wt"
}

$actualBranch = (git -C $wt branch --show-current).Trim()
$actualHead   = (git -C $wt rev-parse HEAD).Trim()
$statusBefore = @(git -C $wt status --porcelain)

if ($actualBranch -ne $branch) {
    Stop-Now "Wrong branch. Expected $branch, got $actualBranch"
}
if ($actualHead -ne $base) {
    Stop-Now "Wrong HEAD. Expected $base, got $actualHead"
}
if ($statusBefore.Count -gt 0) {
    $statusBefore | ForEach-Object { Write-Host $_ -ForegroundColor Yellow }
    Stop-Now "CI baseline worktree is not clean. Do not overwrite existing work."
}

git -C $wt fetch origin
if ($LASTEXITCODE -ne 0) {
    Stop-Now "git fetch origin failed."
}

$originMain = (git -C $wt rev-parse origin/main).Trim()
if ($originMain -ne $base) {
    Stop-Now "origin/main moved from the pinned base. No changes were made."
}

$expectedContextOffenders = @(
    "src/app/api/commerce/refunds/eligibility/route.ts",
    "src/app/api/commerce/refunds/request/route.ts",
    "src/app/api/commerce/refunds/route.ts"
)

$contextOffenders = @(
    Get-ChildItem -LiteralPath "$wt\src\app\api" -Recurse -Filter "route.ts" -File |
    ForEach-Object {
        $source = Read-Normalized $_.FullName
        if ($source.Contains("setActorContext(") -and -not $source.Contains("withActorRequestContext")) {
            Relative-RepoPath $_.FullName
        }
    }
)
Assert-SameSet $contextOffenders $expectedContextOffenders "Unwrapped actor-context routes"

$expectedHttpWriters = @(
    "src/app/api/admin/commerce/refunds/apply-refund-workflow-migration/route.ts",
    "src/app/api/admin/tayqan/apply-worker-brief-migration/route.ts"
)

$httpWriters = @(
    Get-ChildItem -LiteralPath "$wt\src\app\api" -Recurse -Filter "route.ts" -File |
    ForEach-Object {
        $source = Read-Normalized $_.FullName
        $hasDdl = $source -match '\b(?:CREATE|ALTER|DROP)\s+(?:TABLE|INDEX|TYPE|FUNCTION|TRIGGER)\b'
        $writesHistory = $source -match 'INSERT\s+INTO\s+"_prisma_migrations"'
        if ($hasDdl -or $writesHistory) {
            Relative-RepoPath $_.FullName
        }
    }
)
Assert-SameSet $httpWriters $expectedHttpWriters "HTTP schema/migration writers"

$requiredFiles = @(
    "src/app/api/commerce/refunds/eligibility/route.ts",
    "src/app/api/commerce/refunds/request/route.ts",
    "src/app/api/commerce/refunds/route.ts",
    "src/middleware.ts",
    "tests/worker-tayqan.test.ts",
    "tests/extraction-boq-ui-bridge.test.ts",
    "tests/release-route-integrity.test.ts",
    "tests/tayqan-worker-brief-migration-route.test.ts",
    "src/app/api/admin/commerce/refunds/apply-refund-workflow-migration/route.ts",
    "src/app/api/admin/tayqan/apply-worker-brief-migration/route.ts",
    "prisma/migrations/20260814172326_tayqan_1_worker_run_brief/migration.sql"
)

foreach ($relative in $requiredFiles) {
    if (-not (Test-Path -LiteralPath (Join-Path $wt $relative))) {
        Stop-Now "Required baseline file is missing: $relative"
    }
}

$refundWriter = Read-Normalized (Join-Path $wt "src/app/api/admin/commerce/refunds/apply-refund-workflow-migration/route.ts")
if (-not $refundWriter.Contains('INSERT INTO "_prisma_migrations"')) {
    Stop-Now "Refund migration writer pre-image changed."
}

$tayqanWriter = Read-Normalized (Join-Path $wt "src/app/api/admin/tayqan/apply-worker-brief-migration/route.ts")
if (-not $tayqanWriter.Contains('ALTER TABLE "WorkerRun"') -or -not $tayqanWriter.Contains('INSERT INTO "_prisma_migrations"')) {
    Stop-Now "TAYQAN migration writer pre-image changed."
}

Write-Host "PASS: pinned main/base/worktree verified." -ForegroundColor Green
Write-Host "PASS: exactly three unwrapped refund actor-context routes found." -ForegroundColor Green
Write-Host "PASS: exactly two HTTP schema/migration writers found." -ForegroundColor Green

Write-Host "`n=== APPLY BOUNDED BASELINE REPAIR ===" -ForegroundColor Cyan

$eligibilityPath = Join-Path $wt "src/app/api/commerce/refunds/eligibility/route.ts"
$eligibilityNew = @'
import { apiSuccess, handleApiError } from "@/lib/http/api-response";
import { getCurrentActor } from "@/lib/auth/current-actor";
import { setActorContext, withActorRequestContext } from "@/lib/auth/request-context";
import { getRefundEligibility } from "@/lib/services/refund-request-service";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/** REFUND-20 — read-only. Lets the customer UI show the exact refund deadline (or why it's unavailable) before ever attempting a submission. Same capability posture as GET /api/commerce/refunds: every authenticated company member may view it. */
async function GETHandler() {
  try {
    const actor = await getCurrentActor();
    setActorContext(actor);
    return apiSuccess(await getRefundEligibility(actor));
  } catch (error) {
    return handleApiError(error);
  }
}

export const GET = withActorRequestContext(GETHandler);
'@
Write-Utf8NoBom $eligibilityPath $eligibilityNew

$refundListPath = Join-Path $wt "src/app/api/commerce/refunds/route.ts"
$refundListNew = @'
import { apiSuccess, handleApiError } from "@/lib/http/api-response";
import { getCurrentActor } from "@/lib/auth/current-actor";
import { setActorContext, withActorRequestContext } from "@/lib/auth/request-context";
import { listOwnRefundRequests } from "@/lib/services/refund-request-service";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/** REFUND-10 — every authenticated company member may view their own company's refund requests; only entitlements:manage may create one. Read access is never company-role-gated elsewhere in this codebase (see rbac.ts's own header comment), and refund status is not more sensitive than the subscription state it's read from. */
async function GETHandler() {
  try {
    const actor = await getCurrentActor();
    setActorContext(actor);
    return apiSuccess(await listOwnRefundRequests(actor));
  } catch (error) {
    return handleApiError(error);
  }
}

export const GET = withActorRequestContext(GETHandler);
'@
Write-Utf8NoBom $refundListPath $refundListNew

$refundRequestPath = Join-Path $wt "src/app/api/commerce/refunds/request/route.ts"
$refundRequestNew = @'
import { apiSuccess, handleApiError, parseJsonBody } from "@/lib/http/api-response";
import { getCurrentActor } from "@/lib/auth/current-actor";
import { setActorContext, withActorRequestContext } from "@/lib/auth/request-context";
import { requireCapability } from "@/lib/auth/rbac";
import { requestRefund } from "@/lib/services/refund-request-service";
import { refundRequestSchema } from "@/lib/validation/commerce-schema";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/**
 * REFUND-9 — customer creates a refund REQUEST only. The request body
 * carries only `reason`; every provider ID and amount is resolved
 * server-side (see refund-request-service.ts). Gated on the same
 * `entitlements:manage` capability as checkout — billing is a
 * company-owner/administrator action, not a general member action.
 */
async function POSTHandler(request: Request) {
  try {
    const actor = await getCurrentActor();
    setActorContext(actor);
    requireCapability(actor, "entitlements:manage");

    const input = await parseJsonBody(request, refundRequestSchema);
    const result = await requestRefund(actor, input);
    return apiSuccess(result, 201);
  } catch (error) {
    return handleApiError(error);
  }
}

export const POST = withActorRequestContext(POSTHandler);
'@
Write-Utf8NoBom $refundRequestPath $refundRequestNew

$middlewarePath = Join-Path $wt "src/middleware.ts"
$middlewareOld = @'
  const hasSessionCookie = Boolean(request.cookies.get(SESSION_COOKIE_NAME)?.value);


  if (!isPublicPage(pathname) && !hasSessionCookie) {
'@
$middlewareNew = @'
  const hasSessionCookie = Boolean(request.cookies.get(SESSION_COOKIE_NAME)?.value);

  if (pathname === "/login" && hasSessionCookie) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  if (!isPublicPage(pathname) && !hasSessionCookie) {
'@
Replace-Exact $middlewarePath $middlewareOld $middlewareNew

$workerTestPath = Join-Path $wt "tests/worker-tayqan.test.ts"
$workerOld = @'
        const withoutBrandAndVars = node.replace(/TAYQAN/g, "").replace(/\{\w+\}/g, "");
        if (LATIN_PROSE.test(withoutBrandAndVars)) offenders.push(`${path} = ${JSON.stringify(node)}`);
'@
$workerNew = @'
        const withoutTechnicalIdentifiersAndVars = node
          .replace(/TAYQAN|Quantara|Stripe|MEP|HVAC|ELV|Hardscape|Softscape/g, "")
          .replace(/\{\w+\}/g, "");
        if (LATIN_PROSE.test(withoutTechnicalIdentifiersAndVars)) {
          offenders.push(`${path} = ${JSON.stringify(node)}`);
        }
'@
Replace-Exact $workerTestPath $workerOld $workerNew

$bridgeTestPath = Join-Path $wt "tests/extraction-boq-ui-bridge.test.ts"
$bridgeOld = @'
  it("connects completed extraction review directly to the BOQ import workspace", () => {
    expect(extractionPage).toContain("/boq?action=import-reviewed");
    expect(boqPage).toContain('action === "import-reviewed"');
    expect(boqPage).toContain('setAddItemInitialTab("reviewed")');
    expect(boqPage).toContain("initialTab={addItemInitialTab}");
  });
'@
$bridgeNew = @'
  it("connects extraction review to the AI Draft BOQ while preserving governed reviewed import", () => {
    expect(extractionPage).toContain("/extractions/generate-draft-boq");
    expect(extractionPage).toContain('aiDraft: "1"');
    expect(extractionPage).toContain("Generate Draft BOQ Now");
    expect(boqPage).toContain('searchParams.get("aiDraft") === "1"');
    expect(boqPage).toContain("/ai-draft/confirm-quantities");

    // The legacy explicit reviewed-import action remains available in the BOQ
    // workspace; the extraction page simply no longer forces users through it.
    expect(boqPage).toContain('action === "import-reviewed"');
    expect(boqPage).toContain('setAddItemInitialTab("reviewed")');
    expect(boqPage).toContain("initialTab={addItemInitialTab}");
  });
'@
Replace-Exact $bridgeTestPath $bridgeOld $bridgeNew

$releaseTestPath = Join-Path $wt "tests/release-route-integrity.test.ts"
$releaseOld = @'
  "src/app/api/admin/system-health/apply-catalogue-reference-disciplines-migration/route.ts",
] as const;
'@
$releaseNew = @'
  "src/app/api/admin/system-health/apply-catalogue-reference-disciplines-migration/route.ts",
  "src/app/api/admin/commerce/refunds/apply-refund-workflow-migration/route.ts",
  "src/app/api/admin/tayqan/apply-worker-brief-migration/route.ts",
] as const;
'@
Replace-Exact $releaseTestPath $releaseOld $releaseNew

$tayqanMigrationTestPath = Join-Path $wt "tests/tayqan-worker-brief-migration-route.test.ts"
$tayqanMigrationTestPre = Read-Normalized $tayqanMigrationTestPath
if (-not $tayqanMigrationTestPre.Contains('POST /api/admin/tayqan/apply-worker-brief-migration')) {
    Stop-Now "TAYQAN migration-route test pre-image changed."
}
$tayqanMigrationTestNew = @'
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const repoRoot = path.resolve(import.meta.dirname, "..");
const routePath = path.join(
  repoRoot,
  "src/app/api/admin/tayqan/apply-worker-brief-migration/route.ts",
);
const migrationPath = path.join(
  repoRoot,
  "prisma/migrations/20260814172326_tayqan_1_worker_run_brief/migration.sql",
);

describe("TAYQAN worker brief migration release posture", () => {
  it("does not expose the historical one-time migration writer over HTTP", () => {
    expect(existsSync(routePath)).toBe(false);
  });

  it("keeps the authoritative additive Prisma migration in repository history", () => {
    expect(existsSync(migrationPath)).toBe(true);
    const sql = readFileSync(migrationPath, "utf8");
    const executableSql = sql
      .split(/\r?\n/)
      .filter((line) => !line.trimStart().startsWith("--"))
      .join("\n");

    expect(executableSql).toContain('ALTER TABLE "WorkerRun"');
    expect(executableSql).toContain('"assignmentObjective" TEXT');
    expect(executableSql).toContain('"specialInstructions" TEXT');
    expect(executableSql).not.toMatch(/\bDROP\b/i);
  });
});
'@
Write-Utf8NoBom $tayqanMigrationTestPath $tayqanMigrationTestNew

Remove-Item -LiteralPath (Join-Path $wt "src/app/api/admin/commerce/refunds/apply-refund-workflow-migration/route.ts")
Remove-Item -LiteralPath (Join-Path $wt "src/app/api/admin/tayqan/apply-worker-brief-migration/route.ts")

Write-Host "PASS: bounded changes applied." -ForegroundColor Green

Write-Host "`n=== STATIC SAFETY GATES ===" -ForegroundColor Cyan

$contextAfter = @(
    Get-ChildItem -LiteralPath "$wt\src\app\api" -Recurse -Filter "route.ts" -File |
    ForEach-Object {
        $source = Read-Normalized $_.FullName
        if ($source.Contains("setActorContext(") -and -not $source.Contains("withActorRequestContext")) {
            Relative-RepoPath $_.FullName
        }
    }
)
if ($contextAfter.Count -gt 0) {
    $contextAfter | ForEach-Object { Write-Host $_ -ForegroundColor Red }
    Stop-Now "Unwrapped actor-context routes remain."
}

$writersAfter = @(
    Get-ChildItem -LiteralPath "$wt\src\app\api" -Recurse -Filter "route.ts" -File |
    ForEach-Object {
        $source = Read-Normalized $_.FullName
        $hasDdl = $source -match '\b(?:CREATE|ALTER|DROP)\s+(?:TABLE|INDEX|TYPE|FUNCTION|TRIGGER)\b'
        $writesHistory = $source -match 'INSERT\s+INTO\s+"_prisma_migrations"'
        if ($hasDdl -or $writesHistory) {
            Relative-RepoPath $_.FullName
        }
    }
)
if ($writersAfter.Count -gt 0) {
    $writersAfter | ForEach-Object { Write-Host $_ -ForegroundColor Red }
    Stop-Now "HTTP schema/migration writer remains."
}

$expectedChanged = @(
    "src/app/api/admin/commerce/refunds/apply-refund-workflow-migration/route.ts",
    "src/app/api/admin/tayqan/apply-worker-brief-migration/route.ts",
    "src/app/api/commerce/refunds/eligibility/route.ts",
    "src/app/api/commerce/refunds/request/route.ts",
    "src/app/api/commerce/refunds/route.ts",
    "src/middleware.ts",
    "tests/extraction-boq-ui-bridge.test.ts",
    "tests/release-route-integrity.test.ts",
    "tests/tayqan-worker-brief-migration-route.test.ts",
    "tests/worker-tayqan.test.ts"
)

$changed = @(
    git -C $wt diff --name-only |
    ForEach-Object { $_.Trim() } |
    Where-Object { $_ }
)
Assert-SameSet $changed $expectedChanged "Changed-file scope"

git -C $wt diff --check
if ($LASTEXITCODE -ne 0) {
    Stop-Now "git diff --check failed."
}

Write-Host "PASS: exact ten-file baseline scope." -ForegroundColor Green
Write-Host "PASS: no unwrapped actor-context route remains." -ForegroundColor Green
Write-Host "PASS: no application route contains DDL or Prisma migration-history writes." -ForegroundColor Green

Write-Host "`n=== FOCUSED NON-DESTRUCTIVE TESTS ===" -ForegroundColor Cyan

$vitest = "$root\node_modules\.bin\vitest.cmd"
$eslint = "$root\node_modules\.bin\eslint.cmd"

if (-not (Test-Path -LiteralPath $vitest)) {
    Stop-Now "Shared Vitest binary not found at $vitest. No package install was attempted."
}
if (-not (Test-Path -LiteralPath $eslint)) {
    Stop-Now "Shared ESLint binary not found at $eslint. No package install was attempted."
}

Push-Location $wt
try {
    & $vitest run `
      tests/request-context-cloudflare-compat.test.ts `
      tests/middleware.test.ts `
      tests/release-route-integrity.test.ts `
      tests/tayqan-worker-brief-migration-route.test.ts `
      tests/extraction-boq-ui-bridge.test.ts
    if ($LASTEXITCODE -ne 0) {
        Stop-Now "Focused baseline tests failed."
    }

    & $vitest run tests/worker-tayqan.test.ts -t "the Arabic TAYQAN screen introduces no English-only presentation strings beyond the TAYQAN brand/technical identifiers"
    if ($LASTEXITCODE -ne 0) {
        Stop-Now "Focused TAYQAN Arabic presentation test failed."
    }

    & $eslint `
      src/app/api/commerce/refunds/eligibility/route.ts `
      src/app/api/commerce/refunds/request/route.ts `
      src/app/api/commerce/refunds/route.ts `
      src/middleware.ts `
      tests/worker-tayqan.test.ts `
      tests/extraction-boq-ui-bridge.test.ts `
      tests/release-route-integrity.test.ts `
      tests/tayqan-worker-brief-migration-route.test.ts `
      --max-warnings=0
    if ($LASTEXITCODE -ne 0) {
        Stop-Now "ESLint failed."
    }

    npm run typecheck
    if ($LASTEXITCODE -ne 0) {
        Stop-Now "Typecheck failed."
    }
}
finally {
    Pop-Location
}

Write-Host "PASS: focused tests, ESLint and typecheck." -ForegroundColor Green
Write-Host "NOTE: full DB-backed npm test is intentionally left to GitHub CI's ephemeral Postgres." -ForegroundColor Yellow

Write-Host "`n=== COMMIT + PUSH ===" -ForegroundColor Cyan

$changedBeforeStage = @(
    git -C $wt diff --name-only |
    ForEach-Object { $_.Trim() } |
    Where-Object { $_ }
)
Assert-SameSet $changedBeforeStage $expectedChanged "Pre-stage changed-file scope"

git -C $wt add -- $expectedChanged
if ($LASTEXITCODE -ne 0) {
    Stop-Now "git add failed."
}

$staged = @(
    git -C $wt diff --cached --name-only |
    ForEach-Object { $_.Trim() } |
    Where-Object { $_ }
)
Assert-SameSet $staged $expectedChanged "Staged-file scope"

git -C $wt diff --cached --check
if ($LASTEXITCODE -ne 0) {
    Stop-Now "git diff --cached --check failed."
}

git -C $wt commit -m "fix: restore release integrity baseline"
if ($LASTEXITCODE -ne 0) {
    Stop-Now "git commit failed."
}

$newHead = (git -C $wt rev-parse HEAD).Trim()
if ($newHead -eq $base) {
    Stop-Now "Commit did not advance HEAD."
}

git -C $wt push -u origin $branch
if ($LASTEXITCODE -ne 0) {
    Stop-Now "git push failed."
}

$statusAfter = @(git -C $wt status --porcelain)
if ($statusAfter.Count -gt 0) {
    $statusAfter | ForEach-Object { Write-Host $_ -ForegroundColor Yellow }
    Stop-Now "Worktree is not clean after commit/push."
}

Write-Host "`n==================================================" -ForegroundColor Green
Write-Host "CI BASELINE REPAIR PUSHED" -ForegroundColor Green
Write-Host "Branch: $branch" -ForegroundColor Green
Write-Host "Base:   $base" -ForegroundColor Green
Write-Host "Head:   $newHead" -ForegroundColor Green
Write-Host "Files:  10 exact paths (8 modified, 2 obsolete HTTP migration writers removed)" -ForegroundColor Green
Write-Host "PR #52: UNTOUCHED" -ForegroundColor Green
Write-Host "Production DB writes: NONE" -ForegroundColor Green
Write-Host "Prisma/schema/migrations: UNCHANGED" -ForegroundColor Green
Write-Host "Stripe provider/runtime: UNCHANGED" -ForegroundColor Green
Write-Host "npm install: NOT RUN" -ForegroundColor Green
Write-Host "Prisma command: NOT RUN" -ForegroundColor Green
Write-Host "Full DB-backed suite: DEFERRED TO GITHUB CI EPHEMERAL POSTGRES" -ForegroundColor Green
Write-Host "==================================================" -ForegroundColor Green
