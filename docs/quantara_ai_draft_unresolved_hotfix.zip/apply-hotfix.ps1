$ErrorActionPreference = "Stop"

function Stop-Run([string]$Message) {
    throw "STOP: $Message"
}

$root = "$env:USERPROFILE\Desktop\quantara-ai-boq"
$wt = "$root\.worktrees\ai-draft-unresolved-hotfix-20260816"
$trustedWt = "$root\.worktrees\ai-draft-boq-20260816"
$bundle = Split-Path -Parent $MyInvocation.MyCommand.Path

$expectedMain = "c61f1a3fd6ae996704e471b96cd4fe29c01872e5"
$branch = "fix/ai-draft-unresolved-measurements-20260816"

Write-Host "`n=== 1. VERIFY CURRENT PRODUCTION MAIN ===" -ForegroundColor Cyan

if (-not (Test-Path -LiteralPath $root)) {
    Stop-Run "main repository folder not found."
}

Set-Location $root
git fetch origin main
if ($LASTEXITCODE -ne 0) { Stop-Run "git fetch origin main failed." }

$remoteMain = [string](git rev-parse origin/main)
$remoteMain = $remoteMain.Trim()
Write-Host "origin/main: $remoteMain"

if ($remoteMain -ne $expectedMain) {
    Stop-Run "production main moved. Expected $expectedMain but found $remoteMain."
}

if (Test-Path -LiteralPath $wt) {
    Stop-Run "hotfix worktree already exists. Do not overwrite it."
}

$localBranch = @(git branch --list $branch)
if ($localBranch.Count -gt 0) {
    Stop-Run "local hotfix branch already exists."
}

$remoteBranch = @(git ls-remote --heads origin "refs/heads/$branch")
if ($remoteBranch.Count -gt 0) {
    Stop-Run "remote hotfix branch already exists."
}

Write-Host "PASS: exact production base confirmed." -ForegroundColor Green


Write-Host "`n=== 2. CREATE ISOLATED HOTFIX WORKTREE ===" -ForegroundColor Cyan

git worktree add -b $branch $wt $expectedMain
if ($LASTEXITCODE -ne 0) { Stop-Run "git worktree creation failed." }

Set-Location $wt

$createdHead = [string](git rev-parse HEAD)
$createdHead = $createdHead.Trim()
if ($createdHead -ne $expectedMain) {
    Stop-Run "new worktree is not on exact production main."
}

$dirty = @(git status --porcelain=v1 --untracked-files=all)
if ($dirty.Count -gt 0) {
    $dirty
    Stop-Run "new hotfix worktree is not clean."
}

Write-Host "PASS: isolated worktree created." -ForegroundColor Green


Write-Host "`n=== 3. DEPENDENCIES ===" -ForegroundColor Cyan

$reused = $false

if (
    (Test-Path -LiteralPath "$trustedWt\node_modules") -and
    (Test-Path -LiteralPath "$trustedWt\package-lock.json") -and
    (Test-Path -LiteralPath "$trustedWt\prisma\schema.prisma")
) {
    $newLock = (Get-FileHash -LiteralPath "$wt\package-lock.json" -Algorithm SHA256).Hash
    $trustedLock = (Get-FileHash -LiteralPath "$trustedWt\package-lock.json" -Algorithm SHA256).Hash
    $newSchema = (Get-FileHash -LiteralPath "$wt\prisma\schema.prisma" -Algorithm SHA256).Hash
    $trustedSchema = (Get-FileHash -LiteralPath "$trustedWt\prisma\schema.prisma" -Algorithm SHA256).Hash

    if (($newLock -eq $trustedLock) -and ($newSchema -eq $trustedSchema)) {
        try {
            New-Item -ItemType Junction -Path "$wt\node_modules" -Target "$trustedWt\node_modules" -ErrorAction Stop | Out-Null
            $reused = $true
            Write-Host "PASS: reused verified dependency tree." -ForegroundColor Green
        } catch {
            Write-Host "Dependency reuse failed; installing only inside isolated hotfix worktree." -ForegroundColor Yellow
        }
    }
}

if (-not $reused) {
    npm.cmd ci --ignore-scripts --no-audit --no-fund
    if ($LASTEXITCODE -ne 0) { Stop-Run "npm ci failed." }

    $env:DATABASE_URL = "postgresql://codegen:codegen@127.0.0.1:1/quantara_codegen"
    npx.cmd prisma generate --schema prisma/schema.prisma
    if ($LASTEXITCODE -ne 0) { Stop-Run "prisma generate failed." }
}


Write-Host "`n=== 4. APPLY HOTFIX ===" -ForegroundColor Cyan

$transform = Join-Path $bundle "transforms\apply-hotfix.cjs"
if (-not (Test-Path -LiteralPath $transform)) {
    Stop-Run "hotfix transform missing."
}

node $transform $wt
if ($LASTEXITCODE -ne 0) {
    Stop-Run "hotfix transform failed."
}


Write-Host "`n=== 5. EXACT FILE SCOPE + PROTECTED AREA CHECK ===" -ForegroundColor Cyan

$expectedFiles = @(
    "src/app/projects/[projectId]/extractions/page.tsx",
    "src/lib/guidance/ai-draft-boq.ts",
    "src/lib/services/ai-draft-boq-service.ts",
    "tests/ai-draft-boq-workflow.test.ts"
) | Sort-Object

$changed = @(
    @(git diff --name-only)
    @(git ls-files --others --exclude-standard)
) | Where-Object { $_ } | Sort-Object -Unique

if (Compare-Object $expectedFiles $changed) {
    Write-Host "EXPECTED:" -ForegroundColor Yellow
    $expectedFiles
    Write-Host "ACTUAL:" -ForegroundColor Yellow
    $changed
    Stop-Run "unexpected file scope."
}

$protectedPatterns = @(
    "^prisma/",
    "^src/lib/db/",
    "^src/lib/worker/",
    "^src/app/projects/\[projectId\]/tayqan/",
    "^src/lib/services/industry-package",
    "^src/lib/services/master-catalogue",
    "^src/lib/entitlements/",
    "^src/lib/stripe/",
    "^src/app/api/stripe/"
)

foreach ($file in $changed) {
    foreach ($pattern in $protectedPatterns) {
        if ($file -match $pattern) {
            Stop-Run "protected file changed: $file"
        }
    }
}

git diff --check
if ($LASTEXITCODE -ne 0) { Stop-Run "git diff --check failed." }

Write-Host "PASS: exactly 4 intended files." -ForegroundColor Green
Write-Host "DATABASE/PRISMA/MIGRATIONS: NO" -ForegroundColor Green
Write-Host "TAYQAN/ROBOT: NO" -ForegroundColor Green
Write-Host "EXTRACTION ENGINE: NO" -ForegroundColor Green
Write-Host "PACKAGE/CATALOGUE/STRIPE: NO" -ForegroundColor Green


Write-Host "`n=== 6. FOCUSED TESTS ===" -ForegroundColor Cyan

npx.cmd vitest run tests/ai-draft-boq-workflow.test.ts tests/extraction-review-filters.test.ts
if ($LASTEXITCODE -ne 0) {
    Stop-Run "focused tests failed."
}


Write-Host "`n=== 7. TARGETED ESLINT ===" -ForegroundColor Cyan

npx.cmd eslint `
    --no-eslintrc `
    --config "$wt\.eslintrc.json" `
    --resolve-plugins-relative-to "$wt" `
    "src/app/projects/[projectId]/extractions/page.tsx" `
    "src/lib/guidance/ai-draft-boq.ts" `
    "src/lib/services/ai-draft-boq-service.ts" `
    "tests/ai-draft-boq-workflow.test.ts" `
    --max-warnings=0

if ($LASTEXITCODE -ne 0) {
    Stop-Run "ESLint failed."
}


Write-Host "`n=== 8. FULL TYPECHECK ===" -ForegroundColor Cyan

npm.cmd run typecheck
if ($LASTEXITCODE -ne 0) {
    Stop-Run "typecheck failed. Nothing will be committed."
}


Write-Host "`n=== 9. RE-CHECK MAIN HAS NOT MOVED ===" -ForegroundColor Cyan

Set-Location $root
git fetch origin main
if ($LASTEXITCODE -ne 0) { Stop-Run "final git fetch failed." }

$finalMain = [string](git rev-parse origin/main)
$finalMain = $finalMain.Trim()
if ($finalMain -ne $expectedMain) {
    Set-Location $wt
    Stop-Run "main changed while validating. Hotfix remains isolated and uncommitted."
}

Set-Location $wt
Write-Host "PASS: main is still the exact pinned base." -ForegroundColor Green


Write-Host "`n=== 10. STAGE EXACT FILES + COMMIT ===" -ForegroundColor Cyan

git add -- `
    "src/app/projects/[projectId]/extractions/page.tsx" `
    "src/lib/guidance/ai-draft-boq.ts" `
    "src/lib/services/ai-draft-boq-service.ts" `
    "tests/ai-draft-boq-workflow.test.ts"

$staged = @(git diff --cached --name-only | Sort-Object)
if (Compare-Object $expectedFiles $staged) {
    Stop-Run "staged scope is not exactly the 4 intended files."
}

git diff --cached --check
if ($LASTEXITCODE -ne 0) { Stop-Run "staged diff check failed." }

git commit -m "fix: allow AI draft before measurement completion"
if ($LASTEXITCODE -ne 0) { Stop-Run "commit failed." }


Write-Host "`n=== 11. PUSH HOTFIX BRANCH ONLY ===" -ForegroundColor Cyan

git push -u origin $branch
if ($LASTEXITCODE -ne 0) { Stop-Run "push failed." }

$commit = [string](git rev-parse HEAD)
$commit = $commit.Trim()

Write-Host "`n==================================================" -ForegroundColor Green
Write-Host "AI DRAFT UNRESOLVED-MEASUREMENT HOTFIX COMPLETE" -ForegroundColor Green
Write-Host "BRANCH: $branch"
Write-Host "COMMIT: $commit"
Write-Host "FILES CHANGED: 4"
Write-Host "FOCUSED TESTS: PASS"
Write-Host "ESLINT: PASS"
Write-Host "TYPECHECK: PASS"
Write-Host "MAIN: UNTOUCHED"
Write-Host "PROTECTED AREAS: UNTOUCHED"
Write-Host "==================================================" -ForegroundColor Green
Write-Host ""
Write-Host "STOP HERE. Do not merge yet."
