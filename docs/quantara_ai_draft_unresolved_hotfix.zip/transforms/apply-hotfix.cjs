const fs = require("fs");
const path = require("path");

const wt = process.argv[2];
if (!wt) throw new Error("worktree path required");

function read(rel) {
  return fs.readFileSync(path.join(wt, rel), "utf8").replace(/\r\n/g, "\n");
}
function write(rel, text) {
  fs.writeFileSync(path.join(wt, rel), text.replace(/\n/g, "\r\n"), "utf8");
}
function replaceOnce(text, before, after, label) {
  const count = text.split(before).length - 1;
  if (count !== 1) {
    throw new Error(`${label}: expected exact anchor once, found ${count}.`);
  }
  return text.replace(before, after);
}

const guidanceRel = "src/lib/guidance/ai-draft-boq.ts";
const serviceRel = "src/lib/services/ai-draft-boq-service.ts";
const extractionRel = "src/app/projects/[projectId]/extractions/page.tsx";
const testRel = "tests/ai-draft-boq-workflow.test.ts";

let guidance = read(guidanceRel);
let service = read(serviceRel);
let extraction = read(extractionRel);
let test = read(testRel);

guidance = replaceOnce(
  guidance,
`export function isAiDraftCandidateUsable(entity: AiDraftCandidate): boolean {
  return (
    AI_DRAFT_STATUS_SET.has(entity.status.trim().toUpperCase())
    && entity.label.trim().length > 0
    && entity.quantity !== null
    && Number.isFinite(entity.quantity)
    && entity.quantity > 0
    && Boolean(entity.unit?.trim())
  );
}

export function summarizeAiDraftCandidates(entities: readonly AiDraftCandidate[]) {
  const sourceCandidates = entities.filter((entity) =>
    AI_DRAFT_STATUS_SET.has(entity.status.trim().toUpperCase()),
  );
  const eligibleCount = sourceCandidates.filter(isAiDraftCandidateUsable).length;

  return {
    eligibleCount,
    skippedCount: sourceCandidates.length - eligibleCount,
    ignoredFinalizedCount: entities.length - sourceCandidates.length,
  };
}`,
`export function isAiDraftMeasurementComplete(entity: AiDraftCandidate): boolean {
  return (
    entity.quantity !== null
    && Number.isFinite(entity.quantity)
    && entity.quantity > 0
    && Boolean(entity.unit?.trim())
  );
}

export function isAiDraftCandidateUsable(entity: AiDraftCandidate): boolean {
  return (
    AI_DRAFT_STATUS_SET.has(entity.status.trim().toUpperCase())
    && entity.label.trim().length > 0
  );
}

export function summarizeAiDraftCandidates(entities: readonly AiDraftCandidate[]) {
  const sourceCandidates = entities.filter((entity) =>
    AI_DRAFT_STATUS_SET.has(entity.status.trim().toUpperCase()),
  );
  const draftableCandidates = sourceCandidates.filter(isAiDraftCandidateUsable);

  return {
    eligibleCount: draftableCandidates.length,
    measurementIncompleteCount: draftableCandidates.filter(
      (entity) => !isAiDraftMeasurementComplete(entity),
    ).length,
    skippedCount: sourceCandidates.length - draftableCandidates.length,
    ignoredFinalizedCount: entities.length - sourceCandidates.length,
  };
}`,
  "AI Draft draftability vs measurement completeness",
);

service = replaceOnce(
  service,
`  getAiDraftExtractedEntityId,
  isAiDraftCandidateUsable,
  summarizeAiDraftCandidates,`,
`  getAiDraftExtractedEntityId,
  isAiDraftCandidateUsable,
  isAiDraftMeasurementComplete,
  summarizeAiDraftCandidates,`,
  "service measurement helper import",
);

service = replaceOnce(
  service,
`    let reviewedAddedCount = 0;
    let unreviewedAddedCount = 0;

    for (const { row, candidate } of toAdd) {`,
`    let reviewedAddedCount = 0;
    let unreviewedAddedCount = 0;
    let measurementIncompleteAddedCount = 0;

    for (const { row, candidate } of toAdd) {`,
  "service incomplete counter",
);

service = replaceOnce(
  service,
`      const quantity = new Prisma.Decimal(row.quantity!);
      const zero = new Prisma.Decimal(0);
      const marginMode = MarginMode.MARKUP;`,
`      const measurementComplete = isAiDraftMeasurementComplete(candidate);
      const quantity = new Prisma.Decimal(
        measurementComplete ? candidate.quantity! : 0,
      );
      const unit = candidate.unit?.trim() ?? "";
      if (!measurementComplete) measurementIncompleteAddedCount += 1;

      const zero = new Prisma.Decimal(0);
      const marginMode = MarginMode.MARKUP;`,
  "service unresolved measurement placeholders",
);

service = replaceOnce(
  service,
`          quantity,
          unit: row.unit!.trim(),
          unitCost: zero,`,
`          quantity,
          unit,
          unitCost: zero,`,
  "service draft item unit",
);

service = replaceOnce(
  service,
`          notes:
            "AI Draft from extracted project evidence. Professional quantity review and commercial rate selection are still required.",`,
`          notes: measurementComplete
            ? "AI Draft from extracted project evidence. Professional quantity review and commercial rate selection are still required."
            : "AI Draft from extracted project evidence. Quantity and/or unit is unresolved and must be completed in the BOQ before validation.",`,
  "service unresolved item notes",
);

service = replaceOnce(
  service,
`      const previouslyReviewed = (
        (row.status === "CONFIRMED" || row.status === "CORRECTED")
        && row.confirmedAt !== null
      );`,
`      const previouslyReviewed = (
        measurementComplete
        && (row.status === "CONFIRMED" || row.status === "CORRECTED")
        && row.confirmedAt !== null
      );`,
  "service reviewed quantity requires complete measurement",
);

service = replaceOnce(
  service,
`          quantitySnapshot: quantity,
          unitSnapshot: row.unit!.trim(),
          confirmedByUserId: previouslyReviewed ? row.confirmedByUserId : null,`,
`          quantitySnapshot: quantity,
          unitSnapshot: unit,
          confirmedByUserId: previouslyReviewed ? row.confirmedByUserId : null,`,
  "service quantity provenance unresolved unit",
);

service = replaceOnce(
  service,
`          quantity: quantity.toString(),
          unit: row.unit!.trim(),
          confidence: row.confidence.toString(),
          rateAutomaticallyApplied: false,`,
`          quantity: quantity.toString(),
          unit,
          confidence: row.confidence.toString(),
          measurementComplete,
          rateAutomaticallyApplied: false,`,
  "service AI draft audit unresolved measurement",
);

service = replaceOnce(
  service,
`        reviewedAddedCount,
        unreviewedAddedCount,
        ratesAutomaticallyApplied: false,`,
`        reviewedAddedCount,
        unreviewedAddedCount,
        measurementIncompleteAddedCount,
        ratesAutomaticallyApplied: false,`,
  "service generation audit incomplete count",
);

service = replaceOnce(
  service,
`      unreviewedAddedCount,
      reviewedAddedCount,
    };`,
`      unreviewedAddedCount,
      reviewedAddedCount,
      measurementIncompleteAddedCount,
    };`,
  "service response incomplete count",
);

service = replaceOnce(
  service,
`      const extractionWasCorrectedInBoq =
        manuallyReviewedAiQuantity && !quantityMatchesExtraction;

      if (REVIEWABLE_ENTITY_STATUSES.has(entity.status)) {`,
`      const extractionWasCorrectedInBoq =
        manuallyReviewedAiQuantity && !quantityMatchesExtraction;
      const boqMeasurementComplete =
        item.quantity.toNumber() > 0 && item.unit.trim().length > 0;

      if (manuallyReviewedAiQuantity && !boqMeasurementComplete) {
        skippedCount += 1;
        continue;
      }

      if (REVIEWABLE_ENTITY_STATUSES.has(entity.status)) {`,
  "confirmation blocks partial BOQ measurement",
);

service = replaceOnce(
  service,
`      } else if (entity.status === "CONFIRMED" || entity.status === "CORRECTED") {
        const imported = await tx.extractedEntity.updateMany({
          where: {
            id: entity.id,
            companyId: actor.companyId,
            projectId: current.projectId,
            status: { in: ["CONFIRMED", "CORRECTED"] },
          },
          data: { status: "IMPORTED" },
        });

        if (imported.count !== 1) {
          throw new ConflictError(
            "AI_DRAFT_ENTITY_IMPORT_CONFLICT",
            "A reviewed extraction changed while AI Draft quantities were being confirmed. Reload and try again.",
          );
        }

        await createAuditLog(actor.companyId, {
          entityType: "ExtractedEntity",
          entityId: entity.id,
          action: "ENTITY_IMPORTED_TO_BOQ",
          actorName: actor.fullName,
          payload: { boqId: current.id, source: "AI_DRAFT" },
        }, tx);`,
`      } else if (entity.status === "CONFIRMED" || entity.status === "CORRECTED") {
        const original = {
          label: entity.label,
          quantity: entity.quantity?.toNumber() ?? null,
          unit: entity.unit,
        };

        const imported = await tx.extractedEntity.updateMany({
          where: {
            id: entity.id,
            companyId: actor.companyId,
            projectId: current.projectId,
            status: { in: ["CONFIRMED", "CORRECTED"] },
          },
          data: {
            status: "IMPORTED",
            ...(extractionWasCorrectedInBoq
              ? {
                  quantity: item.quantity,
                  unit: item.unit,
                  correctionJson: {
                    original,
                    corrected: {
                      quantity: item.quantity.toNumber(),
                      unit: item.unit,
                    },
                    correctedByUserId: actor.userId,
                    correctedAt: now.toISOString(),
                    reason: "Completed during AI Draft BOQ review.",
                  },
                  confirmedByUserId: actor.userId,
                  confirmedAt: now,
                }
              : {}),
          },
        });

        if (imported.count !== 1) {
          throw new ConflictError(
            "AI_DRAFT_ENTITY_IMPORT_CONFLICT",
            "A reviewed extraction changed while AI Draft quantities were being confirmed. Reload and try again.",
          );
        }

        if (extractionWasCorrectedInBoq) {
          await createAuditLog(actor.companyId, {
            entityType: "ExtractedEntity",
            entityId: entity.id,
            action: "ENTITY_CORRECTED",
            actorName: actor.fullName,
            payload: {
              original,
              corrected: {
                quantity: item.quantity.toNumber(),
                unit: item.unit,
              },
              reason: "Completed during AI Draft BOQ review.",
            },
          }, tx);
        }

        await createAuditLog(actor.companyId, {
          entityType: "ExtractedEntity",
          entityId: entity.id,
          action: "ENTITY_IMPORTED_TO_BOQ",
          actorName: actor.fullName,
          payload: { boqId: current.id, source: "AI_DRAFT" },
        }, tx);`,
  "confirmed extraction completion from BOQ",
);

extraction = replaceOnce(
  extraction,
`type AiDraftGenerationResult = {
  boqId: string;
  addedCount: number;
  skippedCount: number;
  alreadyPresentCount: number;
  unreviewedAddedCount: number;
  reviewedAddedCount: number;
};`,
`type AiDraftGenerationResult = {
  boqId: string;
  addedCount: number;
  skippedCount: number;
  alreadyPresentCount: number;
  unreviewedAddedCount: number;
  reviewedAddedCount: number;
  measurementIncompleteAddedCount: number;
};`,
  "extraction result type incomplete count",
);

extraction = replaceOnce(
  extraction,
`                  Prepare the editable BOQ from {draftSummary.eligibleCount} usable extracted {draftSummary.eligibleCount === 1 ? "item" : "items"}. Review the completed table and correct only what is wrong.
                </p>
                {draftSummary.skippedCount > 0 && (
                  <p className="mt-2 text-xs font-medium text-[#D98A16] dark:text-amber-300">
                    {draftSummary.skippedCount} incomplete {draftSummary.skippedCount === 1 ? "candidate" : "candidates"} will stay in extraction review.
                  </p>
                )}`,
`                  Prepare the editable BOQ from {draftSummary.eligibleCount} extracted {draftSummary.eligibleCount === 1 ? "item" : "items"}. Review the completed table and complete or correct only what is needed.
                </p>
                {draftSummary.measurementIncompleteCount > 0 && (
                  <p className="mt-2 text-xs font-medium text-[#D98A16] dark:text-amber-300">
                    {draftSummary.measurementIncompleteCount} {draftSummary.measurementIncompleteCount === 1 ? "item has" : "items have"} an unresolved quantity and/or unit. Quantara will carry {draftSummary.measurementIncompleteCount === 1 ? "it" : "them"} into the AI Draft as clearly unresolved fields for completion in the BOQ.
                  </p>
                )}
                {draftSummary.skippedCount > 0 && (
                  <p className="mt-2 text-xs font-medium text-[#D84A4A] dark:text-rose-300">
                    {draftSummary.skippedCount} {draftSummary.skippedCount === 1 ? "candidate cannot" : "candidates cannot"} enter the draft because the item description is missing.
                  </p>
                )}`,
  "extraction fast path unresolved measurement wording",
);

test = replaceOnce(
  test,
`  getAiDraftExtractedEntityId,
  isAiDraftCandidateUsable,
  summarizeAiDraftCandidates,`,
`  getAiDraftExtractedEntityId,
  isAiDraftCandidateUsable,
  isAiDraftMeasurementComplete,
  summarizeAiDraftCandidates,`,
  "test measurement helper import",
);

test = replaceOnce(
  test,
`  it("never invents missing quantity or unit", () => {
    expect(isAiDraftCandidateUsable(candidate({ quantity: null }))).toBe(false);
    expect(isAiDraftCandidateUsable(candidate({ quantity: 0 }))).toBe(false);
    expect(isAiDraftCandidateUsable(candidate({ unit: null }))).toBe(false);
    expect(isAiDraftCandidateUsable(candidate({ unit: " " }))).toBe(false);
  });`,
`  it("allows incomplete measurements into the draft without treating them as complete", () => {
    expect(isAiDraftCandidateUsable(candidate({ quantity: null }))).toBe(true);
    expect(isAiDraftCandidateUsable(candidate({ quantity: 0 }))).toBe(true);
    expect(isAiDraftCandidateUsable(candidate({ unit: null }))).toBe(true);
    expect(isAiDraftCandidateUsable(candidate({ unit: " " }))).toBe(true);

    expect(isAiDraftMeasurementComplete(candidate({ quantity: null }))).toBe(false);
    expect(isAiDraftMeasurementComplete(candidate({ quantity: 0 }))).toBe(false);
    expect(isAiDraftMeasurementComplete(candidate({ unit: null }))).toBe(false);
    expect(isAiDraftMeasurementComplete(candidate({ unit: " " }))).toBe(false);
    expect(isAiDraftMeasurementComplete(candidate())).toBe(true);
  });`,
  "test unresolved measurements are draftable",
);

test = replaceOnce(
  test,
`  it("summarizes usable, skipped, and finalized extraction separately", () => {
    expect(summarizeAiDraftCandidates([
      candidate({ id: "usable" }),
      candidate({ id: "missing-unit", unit: null }),
      candidate({ id: "rejected", status: "REJECTED" }),
    ])).toEqual({
      eligibleCount: 1,
      skippedCount: 1,
      ignoredFinalizedCount: 1,
    });
  });`,
`  it("summarizes draftable, measurement-incomplete, skipped, and finalized extraction separately", () => {
    expect(summarizeAiDraftCandidates([
      candidate({ id: "complete" }),
      candidate({ id: "missing-unit", unit: null }),
      candidate({ id: "missing-quantity", quantity: null }),
      candidate({ id: "missing-label", label: " " }),
      candidate({ id: "rejected", status: "REJECTED" }),
    ])).toEqual({
      eligibleCount: 3,
      measurementIncompleteCount: 2,
      skippedCount: 1,
      ignoredFinalizedCount: 1,
    });
  });`,
  "test summary counts unresolved measurements",
);

test = replaceOnce(
  test,
`    expect(aiDraft).toContain("RateProvenanceSource.LEGACY_UNVERIFIED");
    expect(aiDraft).toContain("AI draft - rate selection pending");
    expect(aiDraft).toContain("ENTITY_IMPORTED_TO_BOQ");`,
`    expect(aiDraft).toContain("RateProvenanceSource.LEGACY_UNVERIFIED");
    expect(aiDraft).toContain("AI draft - rate selection pending");
    expect(aiDraft).toContain("measurementComplete ? candidate.quantity! : 0");
    expect(aiDraft).toContain('const unit = candidate.unit?.trim() ?? ""');
    expect(aiDraft).toContain("ENTITY_IMPORTED_TO_BOQ");`,
  "test unresolved placeholders and rates",
);

test = replaceOnce(
  test,
`  it("exposes all three post-extraction choices and BOQ-level confirmation", () => {`,
`  it("keeps unresolved measurements blocked from final BOQ integrity", () => {
    const boqRepository = readFileSync(
      "src/lib/repositories/boq-repository.ts",
      "utf8",
    );

    expect(boqRepository).toContain("BOQ_ITEM_INVALID_UNIT");
    expect(boqRepository).toContain("BOQ_ITEM_INVALID_QUANTITY");
    expect(boqRepository).toContain("ESTIMATE_INTEGRITY_REQUIRED");
  });

  it("exposes all three post-extraction choices and BOQ-level confirmation", () => {`,
  "test final integrity still blocks unresolved draft",
);

write(guidanceRel, guidance);
write(serviceRel, service);
write(extractionRel, extraction);
write(testRel, test);

console.log("PASS: AI Draft unresolved-measurement hotfix applied to exactly 4 files.");
