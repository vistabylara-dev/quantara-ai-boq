$ErrorActionPreference = "Stop"

function Stop-Run([string]$Message) {
    throw "STOP: $Message"
}

$root = "$env:USERPROFILE\Desktop\quantara-ai-boq"
$wt = "$root\.worktrees\ai-draft-unresolved-hotfix-20260816"
$bundle = Split-Path -Parent $MyInvocation.MyCommand.Path

$branch = "fix/ai-draft-unresolved-measurements-20260816"
$expectedHead = "2d49165731f969d17d967be4ea93a4e841c9de1b"
$expectedMain = "c61f1a3fd6ae996704e471b96cd4fe29c01872e5"

Write-Host "`n=== 1. VERIFY HOTFIX REVIEW BASE ===" -ForegroundColor Cyan

if (-not (Test-Path -LiteralPath $wt)) {
    Stop-Run "hotfix worktree not found."
}

Set-Location $wt

$currentBranch = [string](git branch --show-current)
$currentBranch = $currentBranch.Trim()
if ($currentBranch -ne $branch) {
    Stop-Run "wrong branch: $currentBranch"
}

$currentHead = [string](git rev-parse HEAD)
$currentHead = $currentHead.Trim()
if ($currentHead -ne $expectedHead) {
    Stop-Run "hotfix branch moved. Expected $expectedHead but found $currentHead."
}

$dirty = @(git status --porcelain=v1 --untracked-files=all)
if ($dirty.Count -gt 0) {
    $dirty
    Stop-Run "hotfix worktree is not clean."
}

Set-Location $root
git fetch origin main $branch
if ($LASTEXITCODE -ne 0) { Stop-Run "git fetch failed." }

$remoteMain = [string](git rev-parse origin/main)
$remoteMain = $remoteMain.Trim()
if ($remoteMain -ne $expectedMain) {
    Stop-Run "main moved. Do not apply review fix."
}

$remoteHead = [string](git rev-parse "origin/$branch")
$remoteHead = $remoteHead.Trim()
if ($remoteHead -ne $expectedHead) {
    Stop-Run "remote hotfix branch moved."
}

Set-Location $wt
Write-Host "PASS: exact hotfix commit confirmed." -ForegroundColor Green


Write-Host "`n=== 2. APPLY QUANTITY-PRESERVATION FIX ===" -ForegroundColor Cyan

$transform = Join-Path $bundle "transforms\apply-review-fix.cjs"
node $transform $wt
if ($LASTEXITCODE -ne 0) {
    Stop-Run "review fix transform failed."
}


Write-Host "`n=== 3. VERIFY EXACT 3-FILE SCOPE ===" -ForegroundColor Cyan

$expectedFiles = @(
    "src/lib/guidance/ai-draft-boq.ts",
    "src/lib/services/ai-draft-boq-service.ts",
    "tests/ai-draft-boq-workflow.test.ts"
) | Sort-Object

$changed = @(
    @(git diff --name-only)
    @(git ls-files --others --exclude-standard)
) | Where-Object { $_ } | Sort-Object -Unique

if (Compare-Object $expectedFiles $changed) {
    Write-Host "EXPECTED:" -ForegroundColor Yellow
    $expectedFiles
    Write-Host "ACTUAL:" -ForegroundColor Yellow
    $changed
    Stop-Run "unexpected file scope."
}

git diff --check
if ($LASTEXITCODE -ne 0) {
    Stop-Run "git diff --check failed."
}

Write-Host "PASS: exactly 3 intended hotfix files." -ForegroundColor Green
Write-Host "PROTECTED AREAS: UNTOUCHED" -ForegroundColor Green


Write-Host "`n=== 4. FOCUSED TESTS ===" -ForegroundColor Cyan

npx.cmd vitest run tests/ai-draft-boq-workflow.test.ts tests/extraction-review-filters.test.ts
if ($LASTEXITCODE -ne 0) { Stop-Run "focused tests failed." }


Write-Host "`n=== 5. TARGETED ESLINT ===" -ForegroundColor Cyan

npx.cmd eslint `
    --no-eslintrc `
    --config "$wt\.eslintrc.json" `
    --resolve-plugins-relative-to "$wt" `
    "src/lib/guidance/ai-draft-boq.ts" `
    "src/lib/services/ai-draft-boq-service.ts" `
    "tests/ai-draft-boq-workflow.test.ts" `
    --max-warnings=0

if ($LASTEXITCODE -ne 0) { Stop-Run "ESLint failed." }


Write-Host "`n=== 6. FULL TYPECHECK ===" -ForegroundColor Cyan

npm.cmd run typecheck
if ($LASTEXITCODE -ne 0) { Stop-Run "typecheck failed. Nothing committed." }


Write-Host "`n=== 7. COMMIT + PUSH REVIEW FIX ===" -ForegroundColor Cyan

git add -- `
    "src/lib/guidance/ai-draft-boq.ts" `
    "src/lib/services/ai-draft-boq-service.ts" `
    "tests/ai-draft-boq-workflow.test.ts"

$staged = @(git diff --cached --name-only | Sort-Object)
if (Compare-Object $expectedFiles $staged) {
    Stop-Run "staged scope incorrect."
}

git diff --cached --check
if ($LASTEXITCODE -ne 0) { Stop-Run "staged diff check failed." }

git commit -m "fix: preserve valid AI draft quantities with missing units"
if ($LASTEXITCODE -ne 0) { Stop-Run "commit failed." }

git push origin $branch
if ($LASTEXITCODE -ne 0) { Stop-Run "push failed." }

$newHead = [string](git rev-parse HEAD)
$newHead = $newHead.Trim()

Write-Host "`n==================================================" -ForegroundColor Green
Write-Host "AI DRAFT HOTFIX REVIEW FIX COMPLETE" -ForegroundColor Green
Write-Host "BRANCH: $branch"
Write-Host "NEW HEAD: $newHead"
Write-Host "FILES CHANGED IN REVIEW FIX: 3"
Write-Host "FOCUSED TESTS: PASS"
Write-Host "ESLINT: PASS"
Write-Host "TYPECHECK: PASS"
Write-Host "MAIN: UNTOUCHED"
Write-Host "PROTECTED AREAS: UNTOUCHED"
Write-Host "==================================================" -ForegroundColor Green
Write-Host ""
Write-Host "STOP HERE. Do not merge yet."
