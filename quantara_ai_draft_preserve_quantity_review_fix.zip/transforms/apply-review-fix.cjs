const fs = require("fs");
const path = require("path");

const wt = process.argv[2];
if (!wt) throw new Error("worktree path required");

function read(rel) {
  return fs.readFileSync(path.join(wt, rel), "utf8").replace(/\r\n/g, "\n");
}
function write(rel, text) {
  fs.writeFileSync(path.join(wt, rel), text.replace(/\n/g, "\r\n"), "utf8");
}
function replaceOnce(text, before, after, label) {
  const count = text.split(before).length - 1;
  if (count !== 1) {
    throw new Error(`${label}: expected exact anchor once, found ${count}.`);
  }
  return text.replace(before, after);
}

const guidanceRel = "src/lib/guidance/ai-draft-boq.ts";
const serviceRel = "src/lib/services/ai-draft-boq-service.ts";
const testRel = "tests/ai-draft-boq-workflow.test.ts";

let guidance = read(guidanceRel);
let service = read(serviceRel);
let test = read(testRel);

guidance = replaceOnce(
  guidance,
`export function isAiDraftMeasurementComplete(entity: AiDraftCandidate): boolean {
  return (
    entity.quantity !== null
    && Number.isFinite(entity.quantity)
    && entity.quantity > 0
    && Boolean(entity.unit?.trim())
  );
}

export function isAiDraftCandidateUsable(entity: AiDraftCandidate): boolean {`,
`export function getAiDraftQuantityValue(entity: AiDraftCandidate): number {
  return (
    entity.quantity !== null
    && Number.isFinite(entity.quantity)
    && entity.quantity > 0
  )
    ? entity.quantity
    : 0;
}

export function isAiDraftMeasurementComplete(entity: AiDraftCandidate): boolean {
  return (
    getAiDraftQuantityValue(entity) > 0
    && Boolean(entity.unit?.trim())
  );
}

export function isAiDraftCandidateUsable(entity: AiDraftCandidate): boolean {`,
  "add independent quantity preservation helper",
);

service = replaceOnce(
  service,
`  formatAiDraftCategory,
  getAiDraftExtractedEntityId,
  isAiDraftCandidateUsable,`,
`  formatAiDraftCategory,
  getAiDraftExtractedEntityId,
  getAiDraftQuantityValue,
  isAiDraftCandidateUsable,`,
  "service quantity helper import",
);

service = replaceOnce(
  service,
`      const measurementComplete = isAiDraftMeasurementComplete(candidate);
      const quantity = new Prisma.Decimal(
        measurementComplete ? candidate.quantity! : 0,
      );
      const unit = candidate.unit?.trim() ?? "";`,
`      const measurementComplete = isAiDraftMeasurementComplete(candidate);
      const quantity = new Prisma.Decimal(getAiDraftQuantityValue(candidate));
      const unit = candidate.unit?.trim() ?? "";`,
  "preserve valid quantity when unit is missing",
);

service = replaceOnce(
  service,
`        reviewedAddedCount: 0,
      };
    }`,
`        reviewedAddedCount: 0,
        measurementIncompleteAddedCount: 0,
      };
    }`,
  "consistent empty response",
);

test = replaceOnce(
  test,
`  formatAiDraftCategory,
  getAiDraftExtractedEntityId,
  isAiDraftCandidateUsable,`,
`  formatAiDraftCategory,
  getAiDraftExtractedEntityId,
  getAiDraftQuantityValue,
  isAiDraftCandidateUsable,`,
  "test quantity helper import",
);

test = replaceOnce(
  test,
`    expect(isAiDraftMeasurementComplete(candidate({ unit: " " }))).toBe(false);
    expect(isAiDraftMeasurementComplete(candidate())).toBe(true);
  });`,
`    expect(isAiDraftMeasurementComplete(candidate({ unit: " " }))).toBe(false);
    expect(isAiDraftMeasurementComplete(candidate())).toBe(true);

    // Preserve valid extracted evidence field-by-field.
    expect(getAiDraftQuantityValue(candidate({ quantity: 240, unit: null }))).toBe(240);
    expect(getAiDraftQuantityValue(candidate({ quantity: null, unit: "m" }))).toBe(0);
    expect(getAiDraftQuantityValue(candidate({ quantity: -5, unit: "m" }))).toBe(0);
  });`,
  "test independent quantity preservation",
);

test = replaceOnce(
  test,
`    expect(aiDraft).toContain("measurementComplete ? candidate.quantity! : 0");
    expect(aiDraft).toContain('const unit = candidate.unit?.trim() ?? ""');`,
`    expect(aiDraft).toContain("new Prisma.Decimal(getAiDraftQuantityValue(candidate))");
    expect(aiDraft).toContain('const unit = candidate.unit?.trim() ?? ""');`,
  "test source implementation",
);

write(guidanceRel, guidance);
write(serviceRel, service);
write(testRel, test);

console.log("PASS: quantity-preservation review fix applied to exactly 3 files.");
