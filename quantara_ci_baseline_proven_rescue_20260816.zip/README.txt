QUANTARA CI BASELINE — PROVEN-PATTERN RESCUE
Date: 2026-08-16

This bundle supersedes and WITHDRAWS the earlier:
  ci_baseline_repair_20260816.zip

DO NOT RUN THE OLD BUNDLE.

Pinned base:
  c61f1a3fd6ae996704e471b96cd4fe29c01872e5

Expected existing isolated worktree:
  C:\Users\PC\Desktop\quantara-ai-boq\.worktrees\ci-baseline-20260816

Expected branch:
  fix/ci-baseline-20260816

This rescue deliberately follows previously successful Quantara patterns:

1. RESTORE, DO NOT REMOVE PRODUCT FUNCTIONALITY
   - restores the existing reviewed-extraction -> BOQ CTA
   - preserves Generate Draft BOQ Now
   - preserves Review Exceptions First
   - preserves Review Everything First

2. ESTABLISHED REQUEST-CONTEXT PATTERN
   - wraps the three refund API handlers with withActorRequestContext
   - does not alter getRefundEligibility(), listOwnRefundRequests(),
     requestRefund(), or the entitlements:manage capability check

3. RETIRE ONE-TIME HTTP MIGRATION EXECUTION AFTER USE
   - removes only two historical application HTTP migration writers
   - keeps both Prisma migration.sql files untouched as authoritative history
   - does not run a migration or database command

4. PRESERVE HISTORICAL TEST COVERAGE
   - converts the old TAYQAN HTTP migration execution test into a release
     posture test: route absent; additive Prisma migration still present

5. NARROW ARABIC TEST FIX ONLY
   - allows only legitimate technical identifiers:
     TAYQAN, Quantara, Stripe, MEP, HVAC, ELV, Hardscape, Softscape
   - no dictionary or TAYQAN runtime change

6. SAFETY
   - exact 9-path scope
   - dirty primary checkout protected
   - PR #52 six implementation files protected
   - no npm install / npm ci
   - no Prisma command
   - no local database-backed test
   - no production DB write
   - no force push/reset/clean/stash
   - stops if origin/main or source shape has moved

Local validation:
  - extraction BOQ bridge
  - middleware
  - release-route integrity
  - request-context compatibility
  - TAYQAN migration release posture
  - AI Draft regression
  - i18n parity
  - targeted TAYQAN Arabic presentation gate
  - full ESLint
  - full TypeScript typecheck

Full DB-backed test suite and builds are intentionally left to GitHub CI's
isolated PostgreSQL/release job after remote audit.

Additional runner hardening:
- verifies current main already has importableEntityCount before restoring the CTA
- wraps dependency setup and validation in a single cleanup boundary, so even an
  early junction/setup failure restores any pre-existing node_modules directory
