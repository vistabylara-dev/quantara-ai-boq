Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Quantara CI baseline rescue — proven-pattern edition.
#
# PURPOSE
# Repair only the pre-existing CI baseline failures currently blocking PR #52,
# by restoring already-established product behavior and repository safety
# patterns. This script does NOT modify PR #52.
#
# HARD SAFETY
# - exact pinned base only
# - isolated worktree only
# - dirty primary checkout recorded and protected byte-for-byte at git-status level
# - no npm install / npm ci
# - no Prisma command
# - no database-backed test locally
# - no production database write
# - no Stripe/refund business-service change
# - no Prisma schema/migration-file change
# - no catalogue/entitlement change
# - no TAYQAN runtime/worker change
# - no force push / reset / clean / stash
# - STOP on any unexpected source shape or path

$root   = "$env:USERPROFILE\Desktop\quantara-ai-boq"
$wt     = "$root\.worktrees\ci-baseline-20260816"
$branch = "fix/ci-baseline-20260816"
$base   = "c61f1a3fd6ae996704e471b96cd4fe29c01872e5"

$approvedPaths = @(
    "src/app/api/admin/commerce/refunds/apply-refund-workflow-migration/route.ts",
    "src/app/api/admin/tayqan/apply-worker-brief-migration/route.ts",
    "src/app/api/commerce/refunds/eligibility/route.ts",
    "src/app/api/commerce/refunds/request/route.ts",
    "src/app/api/commerce/refunds/route.ts",
    "src/app/projects/[projectId]/extractions/page.tsx",
    "src/middleware.ts",
    "tests/tayqan-worker-brief-migration-route.test.ts",
    "tests/worker-tayqan.test.ts"
) | Sort-Object

$forbiddenExact = @(
    "prisma/schema.prisma",
    "src/lib/services/ai-draft-boq-service.ts",
    "src/lib/services/tayqan-work-order-service.ts",
    "src/lib/i18n/dictionaries/en.ts",
    "src/lib/i18n/dictionaries/ar.ts",
    "tests/ai-draft-boq-workflow.test.ts",
    "tests/tayqan-complete-workflow.test.ts"
)

$forbiddenPrefixes = @(
    "prisma/migrations/",
    "src/lib/stripe/",
    "src/app/api/webhooks/",
    "src/lib/commerce/",
    "src/lib/entitlements/",
    "src/lib/catalogue/",
    "src/lib/services/refund",
    "src/lib/services/stripe",
    "src/lib/services/commerce",
    "src/lib/services/industry-package",
    "src/lib/services/master-catalogue",
    "src/lib/worker/",
    "src/app/projects/[projectId]/tayqan/",
    "src/components/tayqan/"
)

function Stop-Now([string]$Message) {
    throw "STOP: $Message"
}

function Git-Capture([string]$Directory, [string[]]$Arguments) {
    $output = & git -C $Directory @Arguments
    if ($LASTEXITCODE -ne 0) {
        Stop-Now "git failed in ${Directory}: git $($Arguments -join ' ')"
    }
    return (($output | Out-String).Trim())
}

function Git-Run([string]$Directory, [string[]]$Arguments) {
    & git -C $Directory @Arguments
    if ($LASTEXITCODE -ne 0) {
        Stop-Now "git failed in ${Directory}: git $($Arguments -join ' ')"
    }
}

function Read-Normalized([string]$Path) {
    return [IO.File]::ReadAllText($Path).Replace("`r`n", "`n")
}

function Write-Utf8NoBom([string]$Path, [string]$Content) {
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    [IO.File]::WriteAllText($Path, $Content.Replace("`r`n", "`n"), $utf8)
}

function Replace-ExactlyOnce(
    [string]$Content,
    [string]$Old,
    [string]$New,
    [string]$Label
) {
    $oldNorm = $Old.Replace("`r`n", "`n")
    $newNorm = $New.Replace("`r`n", "`n")

    $first = $Content.IndexOf($oldNorm, [StringComparison]::Ordinal)
    if ($first -lt 0) {
        Stop-Now "expected anchor not found for $Label; refusing to guess."
    }

    $second = $Content.IndexOf(
        $oldNorm,
        $first + $oldNorm.Length,
        [StringComparison]::Ordinal
    )
    if ($second -ge 0) {
        Stop-Now "anchor for $Label occurs more than once; refusing ambiguous edit."
    }

    return (
        $Content.Substring(0, $first) +
        $newNorm +
        $Content.Substring($first + $oldNorm.Length)
    )
}

function Relative-RepoPath([string]$FullName) {
    return $FullName.Substring($wt.Length + 1).Replace("\", "/")
}

function Assert-SameSet(
    [string[]]$Expected,
    [string[]]$Actual,
    [string]$Label
) {
    $expectedSorted = @(
        $Expected |
        Where-Object { $_ -and $_.Trim() } |
        ForEach-Object { $_.Trim() } |
        Sort-Object -Unique
    )
    $actualSorted = @(
        $Actual |
        Where-Object { $_ -and $_.Trim() } |
        ForEach-Object { $_.Trim() } |
        Sort-Object -Unique
    )

    $delta = @(Compare-Object -ReferenceObject $expectedSorted -DifferenceObject $actualSorted)

    if ($delta.Count -gt 0) {
        Write-Host "`nExpected:" -ForegroundColor Yellow
        $expectedSorted | ForEach-Object { Write-Host "  $_" }
        Write-Host "Actual:" -ForegroundColor Yellow
        $actualSorted | ForEach-Object { Write-Host "  $_" }
        Stop-Now "$Label scope mismatch."
    }
}

function Assert-RootProtected(
    [string]$ExpectedBranch,
    [string]$ExpectedHead,
    [string]$ExpectedStatus
) {
    $branchNow = Git-Capture $root @("branch", "--show-current")
    $headNow   = Git-Capture $root @("rev-parse", "HEAD")
    $statusNow = Git-Capture $root @("status", "--porcelain=v1", "--untracked-files=all")

    if (
        $branchNow -ne $ExpectedBranch -or
        $headNow -ne $ExpectedHead -or
        $statusNow -ne $ExpectedStatus
    ) {
        Stop-Now "dirty primary checkout changed during this run. Nothing will be pushed."
    }
}

function Assert-ProtectedPathsUnchanged {
    $changed = @(
        git -C $wt diff --name-only $base -- |
        Where-Object { $_ -and $_.Trim() } |
        ForEach-Object { $_.Trim() }
    )
    if ($LASTEXITCODE -ne 0) {
        Stop-Now "could not inspect protected paths."
    }

    foreach ($path in $changed) {
        if ($forbiddenExact -contains $path) {
            Stop-Now "protected exact path changed: $path"
        }
        foreach ($prefix in $forbiddenPrefixes) {
            if ($path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
                Stop-Now "protected path changed: $path"
            }
        }
    }
}

function Invoke-Checked([string]$Label, [scriptblock]$Command) {
    Write-Host "`n=== $Label ===" -ForegroundColor Cyan
    & $Command
    if ($LASTEXITCODE -ne 0) {
        Stop-Now "$Label failed with exit code $LASTEXITCODE."
    }
}

Write-Host "`n=== QUANTARA PROVEN-PATTERN CI BASELINE RESCUE ===" -ForegroundColor Cyan

# ---------------------------------------------------------------------------
# 1. Protect dirty primary checkout + pin isolated worktree/base
# ---------------------------------------------------------------------------

if (-not (Test-Path -LiteralPath $root)) {
    Stop-Now "repository root missing: $root"
}
if (-not (Test-Path -LiteralPath $wt)) {
    Stop-Now "isolated CI baseline worktree missing: $wt"
}

$rootBranchBefore = Git-Capture $root @("branch", "--show-current")
$rootHeadBefore   = Git-Capture $root @("rev-parse", "HEAD")
$rootStatusBefore = Git-Capture $root @("status", "--porcelain=v1", "--untracked-files=all")

$wtBranch = Git-Capture $wt @("branch", "--show-current")
$wtHead   = Git-Capture $wt @("rev-parse", "HEAD")
$wtStatus = @(git -C $wt status --porcelain=v1 --untracked-files=all)

if ($wtBranch -ne $branch) {
    Stop-Now "wrong isolated branch. Expected $branch, got $wtBranch"
}
if ($wtHead -ne $base) {
    Stop-Now "isolated worktree HEAD changed. Expected $base, got $wtHead"
}
if ($wtStatus.Count -gt 0) {
    $wtStatus | ForEach-Object { Write-Host $_ -ForegroundColor Yellow }
    Stop-Now "isolated worktree is not clean. Refusing to overwrite partial work."
}

Git-Run $wt @("fetch", "origin")
$originMain = Git-Capture $wt @("rev-parse", "origin/main")
if ($originMain -ne $base) {
    Stop-Now "origin/main moved from pinned base $base to $originMain. Re-review required."
}

$remoteRepair = (& git -C $wt ls-remote --heads origin "refs/heads/$branch" | Out-String).Trim()
if ($LASTEXITCODE -ne 0) {
    Stop-Now "could not inspect remote repair branch."
}
if ($remoteRepair) {
    Stop-Now "remote $branch already exists. Refusing to overwrite it."
}

Assert-RootProtected $rootBranchBefore $rootHeadBefore $rootStatusBefore

Write-Host "PASS: dirty primary checkout recorded and protected." -ForegroundColor Green
Write-Host "PASS: isolated branch/base clean and exact." -ForegroundColor Green
Write-Host "PASS: origin/main still pinned at $base." -ForegroundColor Green

# ---------------------------------------------------------------------------
# 2. Prove the current failure shape before changing anything
# ---------------------------------------------------------------------------

Write-Host "`n=== PROVE CURRENT FAILURE SHAPE ===" -ForegroundColor Cyan

$expectedUnwrappedActorRoutes = @(
    "src/app/api/commerce/refunds/eligibility/route.ts",
    "src/app/api/commerce/refunds/request/route.ts",
    "src/app/api/commerce/refunds/route.ts"
) | Sort-Object

$unwrappedActorRoutes = @(
    Get-ChildItem -LiteralPath "$wt\src\app\api" -Recurse -Filter "route.ts" -File |
    ForEach-Object {
        $source = Read-Normalized $_.FullName
        if (
            $source.Contains("setActorContext(") -and
            -not $source.Contains("withActorRequestContext")
        ) {
            Relative-RepoPath $_.FullName
        }
    }
) | Sort-Object

Assert-SameSet $expectedUnwrappedActorRoutes $unwrappedActorRoutes "unwrapped actor-context routes"

$expectedHttpMigrationWriters = @(
    "src/app/api/admin/commerce/refunds/apply-refund-workflow-migration/route.ts",
    "src/app/api/admin/tayqan/apply-worker-brief-migration/route.ts"
) | Sort-Object

$httpMigrationWriters = @(
    Get-ChildItem -LiteralPath "$wt\src\app\api" -Recurse -Filter "route.ts" -File |
    ForEach-Object {
        $source = Read-Normalized $_.FullName
        $hasDdl = $source -match '\b(?:CREATE|ALTER|DROP)\s+(?:TABLE|INDEX|TYPE|FUNCTION|TRIGGER)\b'
        $writesMigrationHistory = $source -match 'INSERT\s+INTO\s+"_prisma_migrations"'
        if ($hasDdl -or $writesMigrationHistory) {
            Relative-RepoPath $_.FullName
        }
    }
) | Sort-Object

Assert-SameSet $expectedHttpMigrationWriters $httpMigrationWriters "HTTP schema/migration writers"

$middlewarePath = Join-Path $wt "src\middleware.ts"
$middlewareBefore = Read-Normalized $middlewarePath
if ($middlewareBefore.Contains('if (pathname === "/login" && hasSessionCookie)')) {
    Stop-Now "middleware login redirect already exists; baseline shape changed."
}
if (-not $middlewareBefore.Contains('const hasSessionCookie = Boolean(request.cookies.get(SESSION_COOKIE_NAME)?.value);')) {
    Stop-Now "middleware session-cookie anchor changed."
}

$extractionPath = Join-Path $wt "src\app\projects\[projectId]\extractions\page.tsx"
$extractionBefore = Read-Normalized $extractionPath
$requiredAiDraftMarkers = @(
    "Generate Draft BOQ Now",
    "Review Exceptions First",
    "Review Everything First",
    "disabled={isGeneratingDraft || draftSummary.eligibleCount === 0}",
    "/extractions/generate-draft-boq",
    "importableEntityCount"
)
foreach ($marker in $requiredAiDraftMarkers) {
    if (-not $extractionBefore.Contains($marker)) {
        Stop-Now "AI Draft baseline marker missing: $marker"
    }
}
if ($extractionBefore.Contains("/boq?action=import-reviewed")) {
    Stop-Now "reviewed-import CTA already exists; baseline shape changed."
}
$refundMigrationRoute = Join-Path $wt "src\app\api\admin\commerce\refunds\apply-refund-workflow-migration\route.ts"
$tayqanMigrationRoute = Join-Path $wt "src\app\api\admin\tayqan\apply-worker-brief-migration\route.ts"
$tayqanMigrationTest  = Join-Path $wt "tests\tayqan-worker-brief-migration-route.test.ts"

if (-not (Test-Path -LiteralPath $refundMigrationRoute)) {
    Stop-Now "expected historical refund HTTP migration writer missing."
}
if (-not (Test-Path -LiteralPath $tayqanMigrationRoute)) {
    Stop-Now "expected historical TAYQAN HTTP migration writer missing."
}
if (-not (Test-Path -LiteralPath $tayqanMigrationTest)) {
    Stop-Now "expected TAYQAN migration-route test missing."
}

$refundMigrationSource = Read-Normalized $refundMigrationRoute
foreach ($marker in @(
    'const MIGRATION_NAME = "20260814105935_refund_workflow";',
    'CREATE TABLE IF NOT EXISTS "RefundRequest"',
    'INSERT INTO "_prisma_migrations"'
)) {
    if (-not $refundMigrationSource.Contains($marker)) {
        Stop-Now "refund migration writer does not match reviewed historical route: missing $marker"
    }
}

$tayqanMigrationSource = Read-Normalized $tayqanMigrationRoute
foreach ($marker in @(
    'const MIGRATION_NAME = "20260814172326_tayqan_1_worker_run_brief";',
    'ALTER TABLE "WorkerRun"',
    'INSERT INTO "_prisma_migrations"'
)) {
    if (-not $tayqanMigrationSource.Contains($marker)) {
        Stop-Now "TAYQAN migration writer does not match reviewed historical route: missing $marker"
    }
}

# No product code may call either historical HTTP migration endpoint.
$productRouteCallers = @(
    Get-ChildItem -LiteralPath "$wt\src" -Recurse -File -Include "*.ts","*.tsx" |
    Where-Object {
        $_.FullName -ne $refundMigrationRoute -and
        $_.FullName -ne $tayqanMigrationRoute
    } |
    ForEach-Object {
        $source = Read-Normalized $_.FullName
        if (
            $source.Contains("/api/admin/commerce/refunds/apply-refund-workflow-migration") -or
            $source.Contains("/api/admin/tayqan/apply-worker-brief-migration")
        ) {
            Relative-RepoPath $_.FullName
        }
    }
)
if ($productRouteCallers.Count -gt 0) {
    $productRouteCallers | ForEach-Object { Write-Host $_ -ForegroundColor Red }
    Stop-Now "a product source file still calls a historical migration endpoint."
}

# Refund writer should have no dedicated test dependency. TAYQAN has exactly one,
# which this rescue converts from an execution-route test to a release-posture test.
$refundMigrationTestRefs = @(
    Get-ChildItem -LiteralPath "$wt\tests" -Recurse -File -Include "*.ts","*.tsx" |
    Where-Object {
        (Read-Normalized $_.FullName).Contains("apply-refund-workflow-migration")
    } |
    ForEach-Object { Relative-RepoPath $_.FullName }
)
if ($refundMigrationTestRefs.Count -gt 0) {
    $refundMigrationTestRefs | ForEach-Object { Write-Host $_ -ForegroundColor Red }
    Stop-Now "unexpected test dependency on retired refund HTTP migration route."
}

$tayqanMigrationTestRefs = @(
    Get-ChildItem -LiteralPath "$wt\tests" -Recurse -File -Include "*.ts","*.tsx" |
    Where-Object {
        (Read-Normalized $_.FullName).Contains("apply-worker-brief-migration")
    } |
    ForEach-Object { Relative-RepoPath $_.FullName }
)
Assert-SameSet @("tests/tayqan-worker-brief-migration-route.test.ts") $tayqanMigrationTestRefs "TAYQAN migration-route test dependency"

$refundMigrationFile = Join-Path $wt "prisma\migrations\20260814105935_refund_workflow\migration.sql"
$tayqanMigrationFile = Join-Path $wt "prisma\migrations\20260814172326_tayqan_1_worker_run_brief\migration.sql"

if (-not (Test-Path -LiteralPath $refundMigrationFile)) {
    Stop-Now "authoritative refund Prisma migration history missing."
}
if (-not (Test-Path -LiteralPath $tayqanMigrationFile)) {
    Stop-Now "authoritative TAYQAN Prisma migration history missing."
}

Write-Host "PASS: exactly 3 unwrapped refund request-context routes identified." -ForegroundColor Green
Write-Host "PASS: exactly 2 historical HTTP migration writers identified." -ForegroundColor Green
Write-Host "PASS: no product caller depends on either historical migration endpoint." -ForegroundColor Green
Write-Host "PASS: authoritative Prisma migration history exists and will remain untouched." -ForegroundColor Green
Write-Host "PASS: AI Draft fast path is present before rescue." -ForegroundColor Green

# ---------------------------------------------------------------------------
# 3. Restore reviewed extraction -> BOQ CTA ALONGSIDE AI Draft
# ---------------------------------------------------------------------------

Write-Host "`n=== RESTORE REVIEWED BOQ PATH ALONGSIDE AI DRAFT ===" -ForegroundColor Cyan

$extraction = Read-Normalized $extractionPath

$extractionOld = @'
            </div>

            <p className="mt-4 text-xs leading-5 text-[#7B879C] dark:text-[#7F8DA6]">
              AI Draft quantities remain professionally unconfirmed until you explicitly confirm them from the BOQ. Rates remain unselected until you use your purchased package, catalogue, company library, or manual pricing workflow.
            </p>
'@

$extractionNew = @'
            </div>

            {reviewSummary.complete && (
              <div className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-emerald-300 bg-emerald-50 p-4 dark:border-emerald-400/20 dark:bg-emerald-400/5">
                <div>
                  <div className="text-sm font-black text-emerald-900 dark:text-emerald-200">Review complete</div>
                  <div className="mt-1 text-xs font-bold text-emerald-800 dark:text-emerald-300">
                    {importableEntityCount.toLocaleString()} reviewed items are ready for the governed BOQ import path.
                  </div>
                </div>
                <Link
                  href={
                    importableEntityCount > 0
                      ? `/projects/${encodedProjectId}/boq?action=import-reviewed`
                      : `/projects/${encodedProjectId}/boq`
                  }
                  className="inline-flex min-h-11 items-center justify-center rounded-lg bg-emerald-700 px-4 py-2 text-sm font-black text-white hover:bg-emerald-800"
                >
                  Continue to BOQ
                </Link>
              </div>
            )}

            <p className="mt-4 text-xs leading-5 text-[#7B879C] dark:text-[#7F8DA6]">
              AI Draft quantities remain professionally unconfirmed until you explicitly confirm them from the BOQ. Rates remain unselected until you use your purchased package, catalogue, company library, or manual pricing workflow.
            </p>
'@

$extraction = Replace-ExactlyOnce $extraction $extractionOld $extractionNew "reviewed extraction BOQ CTA"
Write-Utf8NoBom $extractionPath $extraction

foreach ($marker in @(
    "/boq?action=import-reviewed",
    "Generate Draft BOQ Now",
    "Review Exceptions First",
    "Review Everything First",
    "disabled={isGeneratingDraft || draftSummary.eligibleCount === 0}"
)) {
    if (-not (Read-Normalized $extractionPath).Contains($marker)) {
        Stop-Now "post-edit extraction marker missing: $marker"
    }
}

Write-Host "PASS: reviewed BOQ path restored WITHOUT removing AI Draft." -ForegroundColor Green

# ---------------------------------------------------------------------------
# 4. Restore already-documented signed-in /login redirect behavior
# ---------------------------------------------------------------------------

Write-Host "`n=== RESTORE MIDDLEWARE LOGIN REDIRECT CONTRACT ===" -ForegroundColor Cyan

$middleware = Read-Normalized $middlewarePath
$middlewareOld = '  const hasSessionCookie = Boolean(request.cookies.get(SESSION_COOKIE_NAME)?.value);'
$middlewareNew = @'
  const hasSessionCookie = Boolean(request.cookies.get(SESSION_COOKIE_NAME)?.value);

  if (pathname === "/login" && hasSessionCookie) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }
'@

$middleware = Replace-ExactlyOnce $middleware $middlewareOld $middlewareNew "signed-in login redirect"
Write-Utf8NoBom $middlewarePath $middleware

Write-Host "PASS: middleware behavior restored; auth/session verification boundary unchanged." -ForegroundColor Green

# ---------------------------------------------------------------------------
# 5. Wrap the 3 refund API handlers in the established actor request context.
#    Business calls/capabilities remain byte-for-byte as markers.
# ---------------------------------------------------------------------------

Write-Host "`n=== WRAP REFUND ROUTES — BUSINESS LOGIC UNCHANGED ===" -ForegroundColor Cyan

function Wrap-RefundRoute(
    [string]$RelativePath,
    [string]$Verb,
    [string[]]$RequiredBusinessMarkers
) {
    $path = Join-Path $wt $RelativePath
    $source = Read-Normalized $path

    foreach ($marker in $RequiredBusinessMarkers) {
        if (-not $source.Contains($marker)) {
            Stop-Now "$RelativePath business marker changed: $marker"
        }
    }

    if ($source.Contains("withActorRequestContext")) {
        Stop-Now "$RelativePath already wrapped unexpectedly."
    }

    $source = Replace-ExactlyOnce `
        $source `
        'import { setActorContext } from "@/lib/auth/request-context";' `
        'import { setActorContext, withActorRequestContext } from "@/lib/auth/request-context";' `
        "$RelativePath request-context import"

    $declarationOld = "export async function ${Verb}("
    $declarationNew = "async function ${Verb}Handler("
    $source = Replace-ExactlyOnce `
        $source `
        $declarationOld `
        $declarationNew `
        "$RelativePath handler declaration"

    $source = $source.TrimEnd() + "`n`nexport const $Verb = withActorRequestContext(${Verb}Handler);`n"

    foreach ($marker in $RequiredBusinessMarkers) {
        if (-not $source.Contains($marker)) {
            Stop-Now "$RelativePath business marker was lost during wrapper edit: $marker"
        }
    }

    Write-Utf8NoBom $path $source
}

Wrap-RefundRoute `
    "src/app/api/commerce/refunds/eligibility/route.ts" `
    "GET" `
    @(
        'const actor = await getCurrentActor();',
        'setActorContext(actor);',
        'return apiSuccess(await getRefundEligibility(actor));'
    )

Wrap-RefundRoute `
    "src/app/api/commerce/refunds/route.ts" `
    "GET" `
    @(
        'const actor = await getCurrentActor();',
        'setActorContext(actor);',
        'return apiSuccess(await listOwnRefundRequests(actor));'
    )

Wrap-RefundRoute `
    "src/app/api/commerce/refunds/request/route.ts" `
    "POST" `
    @(
        'const actor = await getCurrentActor();',
        'setActorContext(actor);',
        'requireCapability(actor, "entitlements:manage");',
        'const input = await parseJsonBody(request, refundRequestSchema);',
        'const result = await requestRefund(actor, input);',
        'return apiSuccess(result, 201);'
    )

Write-Host "PASS: all 3 refund handlers wrapped using established request-context pattern." -ForegroundColor Green
Write-Host "PASS: refund eligibility/list/request service calls and capability gate preserved." -ForegroundColor Green

# ---------------------------------------------------------------------------
# 6. Retire only the two historical one-time HTTP migration writers.
#    Migration files remain untouched as authoritative history.
# ---------------------------------------------------------------------------

Write-Host "`n=== RETIRE HISTORICAL HTTP MIGRATION WRITERS ===" -ForegroundColor Cyan

Remove-Item -LiteralPath $refundMigrationRoute
Remove-Item -LiteralPath $tayqanMigrationRoute

if (Test-Path -LiteralPath $refundMigrationRoute) {
    Stop-Now "refund HTTP migration writer was not removed."
}
if (Test-Path -LiteralPath $tayqanMigrationRoute) {
    Stop-Now "TAYQAN HTTP migration writer was not removed."
}
if (-not (Test-Path -LiteralPath $refundMigrationFile)) {
    Stop-Now "refund Prisma migration history disappeared."
}
if (-not (Test-Path -LiteralPath $tayqanMigrationFile)) {
    Stop-Now "TAYQAN Prisma migration history disappeared."
}

Write-Host "PASS: obsolete HTTP execution capability removed." -ForegroundColor Green
Write-Host "PASS: both authoritative Prisma migration files remain untouched." -ForegroundColor Green

# ---------------------------------------------------------------------------
# 7. Convert the obsolete TAYQAN HTTP-writer test into release-posture proof.
# ---------------------------------------------------------------------------

Write-Host "`n=== PRESERVE TAYQAN MIGRATION HISTORY TEST COVERAGE ===" -ForegroundColor Cyan

$tayqanTestBefore = Read-Normalized $tayqanMigrationTest
if (-not $tayqanTestBefore.Contains('POST /api/admin/tayqan/apply-worker-brief-migration')) {
    Stop-Now "TAYQAN migration test no longer matches the historical HTTP-writer suite."
}
if (-not $tayqanTestBefore.Contains('20260814172326_tayqan_1_worker_run_brief')) {
    Stop-Now "TAYQAN migration test historical migration marker missing."
}

$tayqanMigrationReleaseTest = @'
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const repoRoot = path.resolve(import.meta.dirname, "..");
const retiredRoutePath = path.join(
  repoRoot,
  "src/app/api/admin/tayqan/apply-worker-brief-migration/route.ts",
);
const migrationPath = path.join(
  repoRoot,
  "prisma/migrations/20260814172326_tayqan_1_worker_run_brief/migration.sql",
);

describe("TAYQAN worker brief migration release posture", () => {
  it("does not expose the historical one-time migration writer over application HTTP", () => {
    expect(existsSync(retiredRoutePath)).toBe(false);
  });

  it("keeps the authoritative additive Prisma migration in repository history", () => {
    expect(existsSync(migrationPath)).toBe(true);

    const sql = readFileSync(migrationPath, "utf8");
    const executableSql = sql
      .split(/\r?\n/)
      .filter((line) => !line.trimStart().startsWith("--"))
      .join("\n");

    expect(executableSql).toContain('ALTER TABLE "WorkerRun"');
    expect(executableSql).toContain('"assignmentObjective" TEXT');
    expect(executableSql).toContain('"specialInstructions" TEXT');
    expect(executableSql).not.toMatch(/\b(?:DROP|DELETE|TRUNCATE)\b/i);
  });
});
'@

Write-Utf8NoBom $tayqanMigrationTest $tayqanMigrationReleaseTest

Write-Host "PASS: test now protects release posture + historical additive migration." -ForegroundColor Green

# ---------------------------------------------------------------------------
# 8. Fix only the Arabic test's legitimate technical-identifier allow-list.
#    No dictionary, screen, worker, or service change.
# ---------------------------------------------------------------------------

Write-Host "`n=== NARROW TAYQAN ARABIC TEST ALLOW-LIST ===" -ForegroundColor Cyan

$workerTestPath = Join-Path $wt "tests\worker-tayqan.test.ts"
$workerTest = Read-Normalized $workerTestPath

$workerTest = Replace-ExactlyOnce `
    $workerTest `
    '    const LATIN_PROSE = /[A-Za-z]{2,}/;' `
@'
    const LATIN_PROSE = /[A-Za-z]{2,}/;
    const ALLOWED_LATIN_IDENTIFIERS = [
      "TAYQAN",
      "Quantara",
      "Stripe",
      "MEP",
      "HVAC",
      "ELV",
      "Hardscape",
      "Softscape",
    ] as const;
'@ `
    "TAYQAN technical identifier allow-list"

$workerOld = @'
        // Strip the brand name and {vars} interpolation placeholders (e.g.
        // "{count}", "{number}") before checking for stray English prose —
        // those are template syntax, not untranslated presentation text.
        const withoutBrandAndVars = node.replace(/TAYQAN/g, "").replace(/\{\w+\}/g, "");
        if (LATIN_PROSE.test(withoutBrandAndVars)) offenders.push(`${path} = ${JSON.stringify(node)}`);
'@

$workerNew = @'
        // Strip approved brand/technical identifiers and {vars} interpolation
        // placeholders before checking for stray English prose. The allow-list
        // is intentionally narrow so genuine untranslated English still fails.
        const withoutVars = node.replace(/\{\w+\}/g, "");
        const withoutAllowedIdentifiers = ALLOWED_LATIN_IDENTIFIERS.reduce(
          (value, identifier) => value.split(identifier).join(""),
          withoutVars,
        );
        if (LATIN_PROSE.test(withoutAllowedIdentifiers)) offenders.push(`${path} = ${JSON.stringify(node)}`);
'@

$workerTest = Replace-ExactlyOnce $workerTest $workerOld $workerNew "TAYQAN Arabic prose gate"
Write-Utf8NoBom $workerTestPath $workerTest

Write-Host "PASS: only legitimate technical identifiers allowed by test." -ForegroundColor Green
Write-Host "PASS: Arabic dictionaries and TAYQAN runtime remain untouched." -ForegroundColor Green

# ---------------------------------------------------------------------------
# 9. Hard static safety gates BEFORE executing tests.
# ---------------------------------------------------------------------------

Write-Host "`n=== HARD STATIC SAFETY GATES ===" -ForegroundColor Cyan

$changed = @(
    git -C $wt diff --name-only |
    Where-Object { $_ -and $_.Trim() } |
    ForEach-Object { $_.Trim() }
)
if ($LASTEXITCODE -ne 0) {
    Stop-Now "could not inspect rescue diff."
}

Assert-SameSet $approvedPaths $changed "rescue changed-file"
Assert-ProtectedPathsUnchanged
Assert-RootProtected $rootBranchBefore $rootHeadBefore $rootStatusBefore

# Request-context scan must now be fully clean.
$remainingUnwrapped = @(
    Get-ChildItem -LiteralPath "$wt\src\app\api" -Recurse -Filter "route.ts" -File |
    ForEach-Object {
        $source = Read-Normalized $_.FullName
        if (
            $source.Contains("setActorContext(") -and
            -not $source.Contains("withActorRequestContext")
        ) {
            Relative-RepoPath $_.FullName
        }
    }
)
if ($remainingUnwrapped.Count -gt 0) {
    $remainingUnwrapped | ForEach-Object { Write-Host $_ -ForegroundColor Red }
    Stop-Now "unwrapped actor-context route remains."
}

# Release-integrity scan must now be fully clean.
$remainingHttpWriters = @(
    Get-ChildItem -LiteralPath "$wt\src\app\api" -Recurse -Filter "route.ts" -File |
    ForEach-Object {
        $source = Read-Normalized $_.FullName
        $hasDdl = $source -match '\b(?:CREATE|ALTER|DROP)\s+(?:TABLE|INDEX|TYPE|FUNCTION|TRIGGER)\b'
        $writesMigrationHistory = $source -match 'INSERT\s+INTO\s+"_prisma_migrations"'
        if ($hasDdl -or $writesMigrationHistory) {
            Relative-RepoPath $_.FullName
        }
    }
)
if ($remainingHttpWriters.Count -gt 0) {
    $remainingHttpWriters | ForEach-Object { Write-Host $_ -ForegroundColor Red }
    Stop-Now "application HTTP schema/migration writer remains."
}

Git-Run $wt @("diff", "--check")

Write-Host "PASS: exact 9-path scope (7 modified + 2 retired routes)." -ForegroundColor Green
Write-Host "PASS: zero unwrapped actor-context routes remain." -ForegroundColor Green
Write-Host "PASS: zero application API DDL/migration-history writers remain." -ForegroundColor Green
Write-Host "PASS: PR #52 six-file implementation untouched." -ForegroundColor Green
Write-Host "PASS: Prisma/schema/migration history untouched." -ForegroundColor Green
Write-Host "PASS: Stripe/refund business services untouched." -ForegroundColor Green
Write-Host "PASS: catalogue/entitlements/TAYQAN runtime untouched." -ForegroundColor Green

# ---------------------------------------------------------------------------
# 10. Reuse an already-installed dependency tree only if it EXACTLY matches
#     current package-lock. Never npm install / npm ci.
# ---------------------------------------------------------------------------

Write-Host "`n=== VERIFY EXISTING DEPENDENCIES — NO INSTALL ===" -ForegroundColor Cyan

$dependencyCandidates = @(
    "$root\.worktrees\ai-draft-boq-20260816\node_modules",
    "$root\node_modules"
)

$verifyJs = @'
const fs = require("fs");
const path = require("path");

const wt = process.argv[1];
const nm = process.argv[2];

try {
  const pkg = JSON.parse(fs.readFileSync(path.join(wt, "package.json"), "utf8"));
  const lock = JSON.parse(fs.readFileSync(path.join(wt, "package-lock.json"), "utf8"));

  const names = [...new Set([
    ...Object.keys(pkg.dependencies || {}),
    ...Object.keys(pkg.devDependencies || {})
  ])].sort();

  for (const name of names) {
    const expected = lock.packages?.[`node_modules/${name}`]?.version;
    const installedFile = path.join(nm, name, "package.json");

    if (!expected || !fs.existsSync(installedFile)) {
      console.error(`MISSING:${name}`);
      process.exit(2);
    }

    const installed = JSON.parse(fs.readFileSync(installedFile, "utf8")).version;
    if (installed !== expected) {
      console.error(`VERSION_MISMATCH:${name}:${installed}:${expected}`);
      process.exit(3);
    }
  }

  console.log(`MATCH:${names.length} top-level dependencies`);
  process.exit(0);
} catch (error) {
  console.error(error?.stack || String(error));
  process.exit(4);
}
'@

$dependencySource = $null
foreach ($candidate in $dependencyCandidates) {
    if (-not (Test-Path -LiteralPath $candidate)) {
        continue
    }

    Write-Host "Checking dependency tree: $candidate"
    & node -e $verifyJs $wt $candidate

    if ($LASTEXITCODE -eq 0) {
        $dependencySource = $candidate
        break
    }
}

if (-not $dependencySource) {
    Stop-Now "no already-installed dependency tree exactly matches package-lock. No install was attempted."
}

Write-Host "PASS: exact dependency tree found: $dependencySource" -ForegroundColor Green

# ---------------------------------------------------------------------------
# 11. Temporary node_modules junction with preservation/restoration.
# ---------------------------------------------------------------------------

$nm = Join-Path $wt "node_modules"
$backup = Join-Path $env:TEMP "quantara-ci-baseline-node_modules-$PID"
$createdJunction = $false
$movedExistingDirectory = $false
$validationFailure = $null

try {
    if (Test-Path -LiteralPath $backup) {
        Stop-Now "temporary node_modules backup path already exists: $backup"
    }

    if (Test-Path -LiteralPath $nm) {
        $nmItem = Get-Item -LiteralPath $nm -Force

        if ($nmItem.LinkType) {
            Stop-Now "worktree node_modules is already a link/junction. Refusing to replace an unknown link."
        }

        if (-not $nmItem.PSIsContainer) {
            Stop-Now "worktree node_modules exists but is not a directory."
        }

        Move-Item -LiteralPath $nm -Destination $backup -ErrorAction Stop
        $movedExistingDirectory = $true
        Write-Host "Preserved existing local node_modules directory at temporary backup." -ForegroundColor Yellow
    }

    New-Item -ItemType Junction -Path $nm -Target $dependencySource -ErrorAction Stop | Out-Null
    $createdJunction = $true

    if (-not (Test-Path -LiteralPath "$nm\vitest\package.json")) {
        Stop-Now "temporary dependency junction did not expose Vitest."
    }
    if (-not (Test-Path -LiteralPath "$nm\next\dist\bin\next")) {
        Stop-Now "temporary dependency junction did not expose Next."
    }
    if (-not (Test-Path -LiteralPath "$nm\typescript\bin\tsc")) {
        Stop-Now "temporary dependency junction did not expose TypeScript."
    }

    Write-Host "PASS: temporary exact dependency junction ready." -ForegroundColor Green

    # -----------------------------------------------------------------------
    # 12. Proven non-destructive validation.
    #     Full DB-backed suite remains GitHub CI's isolated-Postgres responsibility.
    # -----------------------------------------------------------------------

    Push-Location $wt
    try {
        $vitest = "$nm\.bin\vitest.cmd"

        Invoke-Checked "Focused CI regression gates + AI Draft regression" {
            & $vitest run `
                tests/extraction-boq-ui-bridge.test.ts `
                tests/middleware.test.ts `
                tests/release-route-integrity.test.ts `
                tests/request-context-cloudflare-compat.test.ts `
                tests/tayqan-worker-brief-migration-route.test.ts `
                tests/ai-draft-boq-workflow.test.ts `
                tests/i18n-dictionary-parity.test.ts
        }

        Invoke-Checked "TAYQAN Arabic presentation gate only" {
            & $vitest run `
                tests/worker-tayqan.test.ts `
                -t "the Arabic TAYQAN screen introduces no English-only presentation strings beyond the TAYQAN brand/technical identifiers"
        }

        Invoke-Checked "Full ESLint" {
            & npm.cmd run lint --silent
        }

        Invoke-Checked "Full TypeScript typecheck" {
            & npm.cmd run typecheck --silent
        }
    }
    finally {
        Pop-Location
    }
}
catch {
    $validationFailure = $_
}
finally {
    # Restore node_modules state no matter where setup/validation failed.
    if ($createdJunction -and (Test-Path -LiteralPath $nm)) {
        $linkItem = Get-Item -LiteralPath $nm -Force

        if ($linkItem.LinkType -eq "Junction") {
            cmd /c "rmdir `"$nm`"" | Out-Null
        }
        else {
            throw "STOP: node_modules ceased being the temporary junction; it was NOT deleted."
        }
    }

    if ($createdJunction -and (Test-Path -LiteralPath $nm)) {
        throw "STOP: temporary node_modules junction could not be removed."
    }

    if ($movedExistingDirectory) {
        if (-not (Test-Path -LiteralPath $backup)) {
            throw "STOP: preserved original node_modules directory disappeared."
        }
        if (Test-Path -LiteralPath $nm) {
            throw "STOP: cannot restore original node_modules because the destination is occupied."
        }
        Move-Item -LiteralPath $backup -Destination $nm -ErrorAction Stop
    }
}

if ($validationFailure) {
    throw $validationFailure
}

Write-Host "`nPASS: focused regression tests." -ForegroundColor Green
Write-Host "PASS: TAYQAN Arabic presentation gate." -ForegroundColor Green
Write-Host "PASS: full ESLint." -ForegroundColor Green
Write-Host "PASS: full TypeScript typecheck." -ForegroundColor Green
Write-Host "PASS: original node_modules state restored." -ForegroundColor Green
Write-Host "LOCAL DATABASE COMMANDS: NONE" -ForegroundColor Green
Write-Host "Full DB-backed suite will run only in GitHub CI isolated PostgreSQL." -ForegroundColor Green

# ---------------------------------------------------------------------------
# 13. Re-check all safety gates after tooling.
# ---------------------------------------------------------------------------

Write-Host "`n=== FINAL PRE-COMMIT SAFETY GATES ===" -ForegroundColor Cyan

$changedAfterTests = @(
    git -C $wt diff --name-only |
    Where-Object { $_ -and $_.Trim() } |
    ForEach-Object { $_.Trim() }
)
if ($LASTEXITCODE -ne 0) {
    Stop-Now "could not inspect post-test diff."
}

Assert-SameSet $approvedPaths $changedAfterTests "post-test changed-file"
Assert-ProtectedPathsUnchanged
Assert-RootProtected $rootBranchBefore $rootHeadBefore $rootStatusBefore
Git-Run $wt @("diff", "--check")

Git-Run $wt @("fetch", "origin")
$originMainBeforeCommit = Git-Capture $wt @("rev-parse", "origin/main")
if ($originMainBeforeCommit -ne $base) {
    Stop-Now "origin/main moved during validation. Nothing will be committed."
}

$remoteRepairBeforeCommit = (& git -C $wt ls-remote --heads origin "refs/heads/$branch" | Out-String).Trim()
if ($LASTEXITCODE -ne 0) {
    Stop-Now "could not re-check remote repair branch."
}
if ($remoteRepairBeforeCommit) {
    Stop-Now "remote repair branch appeared during validation. Nothing will be pushed."
}

Write-Host "PASS: scope/protected areas/main pin reverified after tooling." -ForegroundColor Green

# ---------------------------------------------------------------------------
# 14. Stage exactly 9 approved paths, commit, push feature branch only.
# ---------------------------------------------------------------------------

Write-Host "`n=== STAGE EXACTLY 9 APPROVED PATHS ===" -ForegroundColor Cyan

foreach ($path in $approvedPaths) {
    & git -C $wt add -A -- $path
    if ($LASTEXITCODE -ne 0) {
        Stop-Now "failed to stage approved path: $path"
    }
}

$staged = @(
    git -C $wt diff --cached --name-only |
    Where-Object { $_ -and $_.Trim() } |
    ForEach-Object { $_.Trim() }
)
if ($LASTEXITCODE -ne 0) {
    Stop-Now "could not inspect staged files."
}

Assert-SameSet $approvedPaths $staged "staged"
Git-Run $wt @("diff", "--cached", "--check")
Assert-RootProtected $rootBranchBefore $rootHeadBefore $rootStatusBefore

Write-Host "`nStaged paths:" -ForegroundColor Green
$staged | Sort-Object | ForEach-Object { Write-Host "  $_" }

Write-Host "`n=== COMMIT ===" -ForegroundColor Cyan
Git-Run $wt @("commit", "-m", "fix: restore proven release integrity gates")
$newHead = Git-Capture $wt @("rev-parse", "HEAD")

# Final pin before push.
Git-Run $wt @("fetch", "origin")
$originMainBeforePush = Git-Capture $wt @("rev-parse", "origin/main")
if ($originMainBeforePush -ne $base) {
    Stop-Now "origin/main moved immediately before push. Local commit is preserved; nothing was pushed."
}

$remoteRepairBeforePush = (& git -C $wt ls-remote --heads origin "refs/heads/$branch" | Out-String).Trim()
if ($LASTEXITCODE -ne 0) {
    Stop-Now "could not perform final remote-branch guard."
}
if ($remoteRepairBeforePush) {
    Stop-Now "remote repair branch appeared immediately before push. Local commit preserved; nothing was pushed."
}

Assert-RootProtected $rootBranchBefore $rootHeadBefore $rootStatusBefore

Write-Host "`n=== PUSH BASELINE REPAIR BRANCH ONLY — NEVER MAIN ===" -ForegroundColor Cyan
Git-Run $wt @("push", "-u", "origin", $branch)

$statusAfter = @(git -C $wt status --porcelain=v1 --untracked-files=all)
if ($statusAfter.Count -gt 0) {
    $statusAfter | ForEach-Object { Write-Host $_ -ForegroundColor Yellow }
    Stop-Now "isolated worktree is not clean after push."
}

Assert-RootProtected $rootBranchBefore $rootHeadBefore $rootStatusBefore

Write-Host "`n==================================================" -ForegroundColor Green
Write-Host "QUANTARA PROVEN CI BASELINE RESCUE PUSHED" -ForegroundColor Green
Write-Host "Branch: $branch" -ForegroundColor Green
Write-Host "Base:   $base" -ForegroundColor Green
Write-Host "Head:   $newHead" -ForegroundColor Green
Write-Host "Paths:  9 exact paths (7 modified, 2 historical HTTP writers retired)" -ForegroundColor Green
Write-Host "Reviewed extraction -> BOQ path: RESTORED" -ForegroundColor Green
Write-Host "AI Draft path: PRESERVED" -ForegroundColor Green
Write-Host "Refund business logic: UNCHANGED" -ForegroundColor Green
Write-Host "TAYQAN runtime/worker: UNCHANGED" -ForegroundColor Green
Write-Host "PR #52 implementation files: UNCHANGED" -ForegroundColor Green
Write-Host "Prisma schema/migration files: UNCHANGED" -ForegroundColor Green
Write-Host "Stripe provider/webhook/services: UNCHANGED" -ForegroundColor Green
Write-Host "Catalogue/entitlements: UNCHANGED" -ForegroundColor Green
Write-Host "Production DB writes: NONE" -ForegroundColor Green
Write-Host "Local DB commands: NONE" -ForegroundColor Green
Write-Host "npm install / npm ci: NOT RUN" -ForegroundColor Green
Write-Host "Prisma command: NOT RUN" -ForegroundColor Green
Write-Host "Focused regression tests: PASS" -ForegroundColor Green
Write-Host "Full ESLint: PASS" -ForegroundColor Green
Write-Host "Full Typecheck: PASS" -ForegroundColor Green
Write-Host "Dirty primary checkout: UNTOUCHED" -ForegroundColor Green
Write-Host "==================================================" -ForegroundColor Green
Write-Host "`nSTOP HERE. DO NOT MERGE. Send this block back for remote diff audit." -ForegroundColor Yellow
