QUANTARA PHASE 2B — AI DRAFT BOQ REVIEW PATH

Purpose
-------
Adds three choices after extraction:
1. Generate Draft BOQ Now
2. Review Exceptions First
3. Review Everything First

Safety
------
- Based only on production main ef9f27e80e5aabb25930c4e0d39aa6dffffa6766.
- Uses an isolated Git worktree and feature branch.
- Does not touch Prisma schema, migrations, production database, TAYQAN/robot,
  extraction engine, package/catalogue entitlements, catalogue data, or Stripe.
- AI Draft does not professionally approve extraction automatically.
- AI Draft does not invent commercial rates.
- Unreviewed quantity and rate provenance stay unverified until explicit review.
- Existing final BOQ lock/verification rules remain unchanged.

Run
---
Open PowerShell inside this extracted folder and run:

    powershell -ExecutionPolicy Bypass -File .\apply.ps1

The script will:
- verify exact origin/main
- create isolated worktree feat/ai-draft-boq-20260816
- make exactly 7 intended file changes
- run focused tests
- run targeted ESLint
- run full typecheck
- re-check main has not moved
- commit and push the feature branch

It does NOT merge anything.

When the final green block appears, send that block back to ChatGPT for GitHub PR review.
