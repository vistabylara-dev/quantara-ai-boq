$ErrorActionPreference = "Stop"

$bundleRoot = $PSScriptRoot
$root = "$env:USERPROFILE\Desktop\quantara-ai-boq"
$expectedMain = "ef9f27e80e5aabb25930c4e0d39aa6dffffa6766"
$branch = "feat/ai-draft-boq-20260816"
$wt = "$root\.worktrees\ai-draft-boq-20260816"
$trustedWt = "$root\.worktrees\extraction-review-filters-20260816"

function Stop-Run([string]$Message) {
    throw "STOP: $Message"
}

Write-Host "`n=== 1. VERIFY EXACT PRODUCTION MAIN ===" -ForegroundColor Cyan

if (-not (Test-Path -LiteralPath "$root\.git")) {
    Stop-Run "Quantara repository not found at $root"
}

Set-Location $root

git fetch origin main
if ($LASTEXITCODE -ne 0) { Stop-Run "git fetch origin main failed." }

$remoteMain = (git rev-parse origin/main).Trim()
Write-Host "origin/main: $remoteMain"

if ($remoteMain -ne $expectedMain) {
    Stop-Run "origin/main moved. Expected $expectedMain but found $remoteMain. Do not use this bundle on a different base."
}

if (Test-Path -LiteralPath $wt) {
    Stop-Run "isolated target worktree already exists: $wt"
}

if ((git branch --list $branch).Trim()) {
    Stop-Run "feature branch already exists: $branch"
}

Write-Host "PASS: exact production base confirmed." -ForegroundColor Green
Write-Host "ROOT DIRTY WORK WILL NOT BE MODIFIED." -ForegroundColor Green


Write-Host "`n=== 2. CREATE ISOLATED WORKTREE ===" -ForegroundColor Cyan

git worktree add -b $branch $wt $expectedMain
if ($LASTEXITCODE -ne 0) { Stop-Run "worktree creation failed." }

Set-Location $wt

if ((git rev-parse HEAD).Trim() -ne $expectedMain) {
    Stop-Run "isolated worktree is not pinned to expected main."
}
if ((git branch --show-current).Trim() -ne $branch) {
    Stop-Run "isolated worktree is on the wrong branch."
}

Write-Host "PASS: isolated worktree created." -ForegroundColor Green


Write-Host "`n=== 3. DEPENDENCIES — REUSE ONLY IF IDENTICAL ===" -ForegroundColor Cyan

$reuseDependencies = $false

if (
    (Test-Path -LiteralPath "$trustedWt\node_modules") -and
    (Test-Path -LiteralPath "$trustedWt\package-lock.json") -and
    (Test-Path -LiteralPath "$trustedWt\prisma\schema.prisma")
) {
    $newLock = (Get-FileHash -LiteralPath "$wt\package-lock.json" -Algorithm SHA256).Hash
    $trustedLock = (Get-FileHash -LiteralPath "$trustedWt\package-lock.json" -Algorithm SHA256).Hash
    $newSchema = (Get-FileHash -LiteralPath "$wt\prisma\schema.prisma" -Algorithm SHA256).Hash
    $trustedSchema = (Get-FileHash -LiteralPath "$trustedWt\prisma\schema.prisma" -Algorithm SHA256).Hash

    if ($newLock -eq $trustedLock -and $newSchema -eq $trustedSchema) {
        cmd /c "mklink /J `"$wt\node_modules`" `"$trustedWt\node_modules`""
        if ($LASTEXITCODE -eq 0) {
            $reuseDependencies = $true
            Write-Host "PASS: reused the previously verified isolated dependency tree." -ForegroundColor Green
        }
    }
}

if (-not $reuseDependencies) {
    Write-Host "No identical reusable dependency tree found. Installing inside THIS worktree only." -ForegroundColor Yellow
    npm.cmd ci --ignore-scripts --no-audit --no-fund
    if ($LASTEXITCODE -ne 0) { Stop-Run "npm ci failed." }

    # Code generation only. This URL is deliberately non-routable and no DB command is executed.
    $env:DATABASE_URL = "postgresql://codegen:codegen@127.0.0.1:1/quantara_codegen"
    npx.cmd prisma generate --schema prisma/schema.prisma
    if ($LASTEXITCODE -ne 0) { Stop-Run "prisma generate failed." }
}


Write-Host "`n=== 4. VERIFY + TRANSFORM EXISTING UI FILES ===" -ForegroundColor Cyan

$transformScript = Join-Path $bundleRoot "transforms\apply-transform.cjs"
if (-not (Test-Path -LiteralPath $transformScript)) {
    Stop-Run "bundle transform script is missing."
}

node $transformScript $wt
if ($LASTEXITCODE -ne 0) {
    Stop-Run "UI transform failed. No transform file is written unless every pinned-main anchor matches."
}


Write-Host "`n=== 5. COPY NEW AI DRAFT FILES ===" -ForegroundColor Cyan

$relativeNewFiles = @(
    "src\lib\guidance\ai-draft-boq.ts",
    "src\lib\services\ai-draft-boq-service.ts",
    "src\app\api\projects\[projectId]\extractions\generate-draft-boq\route.ts",
    "src\app\api\boqs\[boqId]\ai-draft\confirm-quantities\route.ts",
    "tests\ai-draft-boq-workflow.test.ts"
)

foreach ($relative in $relativeNewFiles) {
    $source = Join-Path (Join-Path $bundleRoot "files") $relative
    $destination = Join-Path $wt $relative
    if (-not (Test-Path -LiteralPath $source)) {
        Stop-Run "bundle source file missing: $relative"
    }
    if (Test-Path -LiteralPath $destination) {
        Stop-Run "expected new repository file already exists: $relative"
    }
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destination) | Out-Null
    Copy-Item -LiteralPath $source -Destination $destination
}

Write-Host "PASS: AI Draft files copied." -ForegroundColor Green


Write-Host "`n=== 6. EXACT FILE SCOPE + PROTECTED AREA CHECK ===" -ForegroundColor Cyan

$expectedFiles = @(
    "src/app/api/boqs/[boqId]/ai-draft/confirm-quantities/route.ts",
    "src/app/api/projects/[projectId]/extractions/generate-draft-boq/route.ts",
    "src/app/projects/[projectId]/boq/page.tsx",
    "src/app/projects/[projectId]/extractions/page.tsx",
    "src/lib/guidance/ai-draft-boq.ts",
    "src/lib/services/ai-draft-boq-service.ts",
    "tests/ai-draft-boq-workflow.test.ts"
) | Sort-Object

$changed = @(
    git status --porcelain=v1 --untracked-files=all |
    ForEach-Object { $_.Substring(3).Trim('"') } |
    Sort-Object
)

$comparison = Compare-Object $expectedFiles $changed
if ($comparison) {
    Write-Host "EXPECTED:" -ForegroundColor Yellow
    $expectedFiles
    Write-Host "ACTUAL:" -ForegroundColor Yellow
    $changed
    Stop-Run "unexpected file scope."
}

$protectedPatterns = @(
    "^prisma/",
    "^src/lib/db/",
    "^src/lib/worker/",
    "^src/app/projects/\[projectId\]/tayqan/",
    "^src/lib/services/industry-package",
    "^src/lib/services/master-catalogue",
    "^src/lib/entitlements/",
    "^src/lib/stripe/",
    "^src/app/api/stripe/"
)

foreach ($file in $changed) {
    foreach ($pattern in $protectedPatterns) {
        if ($file -match $pattern) {
            Stop-Run "protected file changed: $file"
        }
    }
}

git diff --check
if ($LASTEXITCODE -ne 0) { Stop-Run "git diff --check failed." }

Write-Host "PASS: exactly 7 intended files." -ForegroundColor Green
Write-Host "DATABASE: NO" -ForegroundColor Green
Write-Host "PRISMA/SCHEMA/MIGRATIONS: NO" -ForegroundColor Green
Write-Host "TAYQAN/ROBOT: NO" -ForegroundColor Green
Write-Host "EXTRACTION ENGINE: NO" -ForegroundColor Green
Write-Host "PACKAGE/CATALOGUE ENTITLEMENTS: NO" -ForegroundColor Green
Write-Host "STRIPE: NO" -ForegroundColor Green


Write-Host "`n=== 7. FOCUSED TESTS ===" -ForegroundColor Cyan

npx.cmd vitest run `
    tests/ai-draft-boq-workflow.test.ts `
    tests/extraction-review-filters.test.ts

if ($LASTEXITCODE -ne 0) { Stop-Run "focused tests failed." }


Write-Host "`n=== 8. TARGETED ESLINT ===" -ForegroundColor Cyan

npx.cmd eslint `
    --no-eslintrc `
    --config "$wt\.eslintrc.json" `
    --resolve-plugins-relative-to "$wt" `
    "src/app/api/boqs/[boqId]/ai-draft/confirm-quantities/route.ts" `
    "src/app/api/projects/[projectId]/extractions/generate-draft-boq/route.ts" `
    "src/app/projects/[projectId]/boq/page.tsx" `
    "src/app/projects/[projectId]/extractions/page.tsx" `
    "src/lib/guidance/ai-draft-boq.ts" `
    "src/lib/services/ai-draft-boq-service.ts" `
    "tests/ai-draft-boq-workflow.test.ts" `
    --max-warnings=0

if ($LASTEXITCODE -ne 0) { Stop-Run "ESLint failed." }


Write-Host "`n=== 9. FULL TYPECHECK ===" -ForegroundColor Cyan

npm.cmd run typecheck
if ($LASTEXITCODE -ne 0) {
    Stop-Run "typecheck failed. Nothing will be committed."
}


Write-Host "`n=== 10. RE-CHECK MAIN HAS NOT MOVED ===" -ForegroundColor Cyan

Set-Location $root
git fetch origin main
if ($LASTEXITCODE -ne 0) { Stop-Run "final git fetch failed." }
$finalRemoteMain = (git rev-parse origin/main).Trim()
if ($finalRemoteMain -ne $expectedMain) {
    Set-Location $wt
    Stop-Run "main changed while this work was being validated. Changes remain isolated and UNCOMMITTED for rebase/review."
}
Set-Location $wt
Write-Host "PASS: main is still the exact pinned base." -ForegroundColor Green


Write-Host "`n=== 11. STAGE EXACT FILES + COMMIT ===" -ForegroundColor Cyan

git add -- `
    "src/app/api/boqs/[boqId]/ai-draft/confirm-quantities/route.ts" `
    "src/app/api/projects/[projectId]/extractions/generate-draft-boq/route.ts" `
    "src/app/projects/[projectId]/boq/page.tsx" `
    "src/app/projects/[projectId]/extractions/page.tsx" `
    "src/lib/guidance/ai-draft-boq.ts" `
    "src/lib/services/ai-draft-boq-service.ts" `
    "tests/ai-draft-boq-workflow.test.ts"

$staged = @(git diff --cached --name-only | Sort-Object)
if (Compare-Object $expectedFiles $staged) {
    Stop-Run "staged scope is not exactly the 7 intended files."
}

git diff --cached --check
if ($LASTEXITCODE -ne 0) { Stop-Run "staged diff check failed." }

git commit -m "feat: add direct AI draft BOQ review path"
if ($LASTEXITCODE -ne 0) { Stop-Run "commit failed." }


Write-Host "`n=== 12. PUSH FEATURE BRANCH ONLY ===" -ForegroundColor Cyan

git push -u origin $branch
if ($LASTEXITCODE -ne 0) { Stop-Run "push failed." }

$commit = (git rev-parse HEAD).Trim()

Write-Host "`n==================================================" -ForegroundColor Green
Write-Host "AI DRAFT BOQ PHASE 2B COMPLETE" -ForegroundColor Green
Write-Host "BRANCH: $branch"
Write-Host "COMMIT: $commit"
Write-Host "FOCUSED TESTS: PASS"
Write-Host "ESLINT: PASS"
Write-Host "TYPECHECK: PASS"
Write-Host "FILES CHANGED: 7"
Write-Host "MAIN: UNTOUCHED"
Write-Host "DATABASE/PRISMA/MIGRATIONS: UNTOUCHED"
Write-Host "TAYQAN/ROBOT: UNTOUCHED"
Write-Host "PACKAGE/CATALOGUE/STRIPE: UNTOUCHED"
Write-Host "==================================================" -ForegroundColor Green
Write-Host ""
Write-Host "CREATE PR — DO NOT MERGE YET:" -ForegroundColor Cyan
Write-Host "https://github.com/vistabylara-dev/quantara-ai-boq/pull/new/$branch"
