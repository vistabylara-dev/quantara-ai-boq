import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import {
  chooseAiDraftSection,
  formatAiDraftCategory,
  isAiDraftCandidateUsable,
  summarizeAiDraftCandidates,
  type AiDraftCandidate,
} from "../src/lib/guidance/ai-draft-boq";

function candidate(overrides: Partial<AiDraftCandidate> = {}): AiDraftCandidate {
  return {
    id: "entity-1",
    entityType: "BOQ_ITEM",
    label: "Chilled water pipe 100mm",
    quantity: 240,
    unit: "m",
    confidence: 96,
    sourceText: "HVAC chilled water schedule",
    status: "EXTRACTED",
    ...overrides,
  };
}

describe("AI Draft BOQ workflow", () => {
  it("allows usable unreviewed or reviewed extraction into an AI Draft", () => {
    expect(isAiDraftCandidateUsable(candidate({ status: "EXTRACTED" }))).toBe(true);
    expect(isAiDraftCandidateUsable(candidate({ status: "NEEDS_REVIEW" }))).toBe(true);
    expect(isAiDraftCandidateUsable(candidate({ status: "CONFIRMED" }))).toBe(true);
    expect(isAiDraftCandidateUsable(candidate({ status: "CORRECTED" }))).toBe(true);
  });

  it("never invents missing quantity or unit to make a draft candidate usable", () => {
    expect(isAiDraftCandidateUsable(candidate({ quantity: null }))).toBe(false);
    expect(isAiDraftCandidateUsable(candidate({ quantity: 0 }))).toBe(false);
    expect(isAiDraftCandidateUsable(candidate({ unit: null }))).toBe(false);
    expect(isAiDraftCandidateUsable(candidate({ unit: " " }))).toBe(false);
  });

  it("keeps rejected and imported extraction out of new AI Draft generation", () => {
    expect(isAiDraftCandidateUsable(candidate({ status: "REJECTED" }))).toBe(false);
    expect(isAiDraftCandidateUsable(candidate({ status: "IMPORTED" }))).toBe(false);
  });

  it("summarizes usable, skipped, and finalized extraction separately", () => {
    const summary = summarizeAiDraftCandidates([
      candidate({ id: "usable" }),
      candidate({ id: "missing-unit", unit: null }),
      candidate({ id: "rejected", status: "REJECTED" }),
    ]);

    expect(summary).toEqual({
      eligibleCount: 1,
      skippedCount: 1,
      ignoredFinalizedCount: 1,
    });
  });

  it("uses the project BOQ section when the extracted evidence matches it", () => {
    const sectionId = chooseAiDraftSection(
      [
        { id: "hvac", code: "HVAC", title: "HVAC Works", description: "Chilled water and air conditioning" },
        { id: "electrical", code: "ELEC", title: "Electrical Works", description: "Power and lighting" },
      ],
      candidate(),
    );

    expect(sectionId).toBe("hvac");
  });

  it("falls back instead of forcing an unrelated business section", () => {
    const sectionId = chooseAiDraftSection(
      [
        { id: "electrical", code: "ELEC", title: "Electrical Works", description: "Power and lighting" },
      ],
      candidate({ label: "Ceramic wall tile", entityType: "FINISH", sourceText: "Bathroom tile schedule" }),
    );

    expect(sectionId).toBeNull();
    expect(formatAiDraftCategory("MEP_ITEM")).toBe("Mep Item");
  });

  it("keeps the existing reviewed-import rule and makes AI Draft rates explicitly unverified", () => {
    const reviewedImportSource = readFileSync(
      "src/lib/services/extraction-to-boq-service.ts",
      "utf8",
    );
    const aiDraftSource = readFileSync(
      "src/lib/services/ai-draft-boq-service.ts",
      "utf8",
    );

    expect(reviewedImportSource).toContain(
      "Only confirmed or corrected entities may be imported to a BOQ.",
    );
    expect(aiDraftSource).toContain("RateProvenanceSource.LEGACY_UNVERIFIED");
    expect(aiDraftSource).toContain("AI draft - rate selection pending");
    expect(aiDraftSource).toContain("sourceType: BoqItemSourceType.IMPORT");
  });

  it("exposes all three post-extraction choices and BOQ-level quantity confirmation", () => {
    const extractionPage = readFileSync(
      "src/app/projects/[projectId]/extractions/page.tsx",
      "utf8",
    );
    const boqPage = readFileSync(
      "src/app/projects/[projectId]/boq/page.tsx",
      "utf8",
    );

    expect(extractionPage).toContain("Generate Draft BOQ Now");
    expect(extractionPage).toContain("Review Exceptions First");
    expect(extractionPage).toContain("Review Everything First");
    expect(boqPage).toContain("Confirm Remaining Draft Quantities");
  });
});
