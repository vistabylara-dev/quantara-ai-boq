const fs = require("node:fs");
const path = require("node:path");

const root = process.argv[2];
if (!root) throw new Error("STOP: worktree path argument is required.");

const extractionPath = path.join(root, "src", "app", "projects", "[projectId]", "extractions", "page.tsx");
const boqPath = path.join(root, "src", "app", "projects", "[projectId]", "boq", "page.tsx");

function load(file) {
  const original = fs.readFileSync(file, "utf8");
  return { eol: original.includes("\r\n") ? "\r\n" : "\n", text: original.replace(/\r\n/g, "\n") };
}

function countOf(text, needle) {
  return text.split(needle).length - 1;
}

function replaceOnce(text, before, after, name) {
  const count = countOf(text, before);
  if (count !== 1) {
    throw new Error(`STOP: ${name} expected exactly once but found ${count}. NOTHING WRITTEN.`);
  }
  return text.replace(before, after);
}

const extraction = load(extractionPath);
const boq = load(boqPath);
let extractionNext = extraction.text;
let boqNext = boq.text;

// ---------------------------------------------------------------------------
// Extraction page — add AI Draft choice without changing review business rules.
// ---------------------------------------------------------------------------
extractionNext = replaceOnce(
  extractionNext,
`} from "@/lib/guidance/extraction-review-filters";\nimport { GuideTip } from "@/components/guidance/guide-tip";`,
`} from "@/lib/guidance/extraction-review-filters";\nimport { summarizeAiDraftCandidates } from "@/lib/guidance/ai-draft-boq";\nimport { GuideTip } from "@/components/guidance/guide-tip";`,
  "AI Draft helper import",
);

extractionNext = replaceOnce(
  extractionNext,
`type PendingAction = {\n  entityId: string;\n  action: "confirm" | "correct" | "reject";\n};\n\nconst EXTRACTION_STATUS_TONE`,
`type PendingAction = {\n  entityId: string;\n  action: "confirm" | "correct" | "reject";\n};\n\ntype AiDraftGenerationResult = {\n  boqId: string;\n  addedCount: number;\n  skippedCount: number;\n  alreadyPresentCount: number;\n  unreviewedAddedCount: number;\n  reviewedAddedCount: number;\n};\n\nconst EXTRACTION_STATUS_TONE`,
  "AI Draft result type",
);

extractionNext = replaceOnce(
  extractionNext,
`  const [formError, setFormError] = useState<string | null>(null);\n  const [filters, setFilters] = useState<ExtractionReviewFilters>({ ...DEFAULT_EXTRACTION_REVIEW_FILTERS });\n\n  const encodedProjectId`,
`  const [formError, setFormError] = useState<string | null>(null);\n  const [filters, setFilters] = useState<ExtractionReviewFilters>({ ...DEFAULT_EXTRACTION_REVIEW_FILTERS });\n  const [exceptionsOnly, setExceptionsOnly] = useState(false);\n  const [isGeneratingDraft, setIsGeneratingDraft] = useState(false);\n\n  const encodedProjectId`,
  "AI Draft page state",
);

extractionNext = replaceOnce(
  extractionNext,
`  const importableEntityCount = useMemo(\n    () => entities.filter(\n      (entity) => entity.status === "CONFIRMED" || entity.status === "CORRECTED",\n    ).length,\n    [entities],\n  );\n\n  const filteredEntities = useMemo(\n    () => filterExtractionReviewEntities(entities, filters),\n    [entities, filters],\n  );`,
`  const draftSummary = useMemo(\n    () => summarizeAiDraftCandidates(entities),\n    [entities],\n  );\n\n  const filteredEntities = useMemo(() => {\n    const filtered = filterExtractionReviewEntities(entities, filters);\n    if (!exceptionsOnly) return filtered;\n    return filtered.filter(\n      (entity) =>\n        isReviewableExtractionStatus(entity.status)\n        && getExtractionReviewPriority(entity) !== "SAFE",\n    );\n  }, [entities, exceptionsOnly, filters]);`,
  "AI Draft summary and exceptions view",
);

extractionNext = replaceOnce(
  extractionNext,
`  const hasActiveFilters = Object.entries(filters).some(\n    ([key, value]) => key === "search" ? Boolean(value.trim()) : value !== "ALL",\n  );`,
`  const hasActiveFilters = exceptionsOnly || Object.entries(filters).some(\n    ([key, value]) => key === "search" ? Boolean(value.trim()) : value !== "ALL",\n  );`,
  "active filter state",
);

extractionNext = replaceOnce(
  extractionNext,
`  function openRejection(entityId: string) {\n    setRejectingId(entityId);\n    setCorrectingId(null);\n    setRejectionReason("");\n    setCorrectionDraft({ label: "", quantity: "", unit: "", reason: "" });\n    setFormError(null);\n    setActionError(null);\n  }\n\n  if (isLoading) {`,
`  function openRejection(entityId: string) {\n    setRejectingId(entityId);\n    setCorrectingId(null);\n    setRejectionReason("");\n    setCorrectionDraft({ label: "", quantity: "", unit: "", reason: "" });\n    setFormError(null);\n    setActionError(null);\n  }\n\n  function focusReviewItems() {\n    requestAnimationFrame(() => {\n      const reviewItems = document.getElementById("extraction-review-items");\n      reviewItems?.scrollIntoView({ behavior: "smooth", block: "start" });\n      reviewItems?.focus({ preventScroll: true });\n    });\n  }\n\n  function reviewExceptionsFirst() {\n    setFilters({ ...DEFAULT_EXTRACTION_REVIEW_FILTERS });\n    setExceptionsOnly(true);\n    focusReviewItems();\n  }\n\n  function reviewEverythingFirst() {\n    setFilters({ ...DEFAULT_EXTRACTION_REVIEW_FILTERS });\n    setExceptionsOnly(false);\n    focusReviewItems();\n  }\n\n  const generateDraftBoq = useCallback(async () => {\n    if (isGeneratingDraft || draftSummary.eligibleCount === 0) return;\n    setIsGeneratingDraft(true);\n    setActionError(null);\n    setActionMessage(null);\n    try {\n      const result = await apiClient.post<AiDraftGenerationResult>(\n        \`/api/projects/\${encodedProjectId}/extractions/generate-draft-boq\`,\n        {},\n      );\n      const query = new URLSearchParams({\n        aiDraft: "1",\n        added: String(result.addedCount),\n        skipped: String(result.skippedCount),\n        existing: String(result.alreadyPresentCount),\n      });\n      window.location.assign(\`/projects/\${encodedProjectId}/boq?\${query.toString()}\`);\n    } catch (error) {\n      setActionError(\n        error instanceof ApiClientError\n          ? error.message\n          : "The AI Draft BOQ could not be prepared. Try again.",\n      );\n    } finally {\n      setIsGeneratingDraft(false);\n    }\n  }, [draftSummary.eligibleCount, encodedProjectId, isGeneratingDraft]);\n\n  if (isLoading) {`,
  "AI Draft interaction handlers",
);

extractionNext = replaceOnce(
  extractionNext,
`          Quantara presents source-linked candidates for professional review. Nothing on this page is confirmed or added to a BOQ automatically.`,
`          Quantara presents source-linked candidates for professional review. Nothing is professionally confirmed automatically. You can review first, or prepare an editable AI Draft BOQ and perform the professional review in the completed BOQ table.`,
  "AI Draft intro copy",
);

const oldNextStep = `        <div className="mt-6 flex flex-col gap-4 rounded-2xl border border-[#009FE3]/30 bg-[#009FE3]/5 p-5 dark:border-[#21C7F3]/30 dark:bg-[#21C7F3]/5 sm:flex-row sm:items-center sm:justify-between">\n          <div>\n            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#0077B6] dark:text-[#21C7F3]">What should I do next?</p>\n            <p className="mt-2 text-sm font-medium text-[#0B1630] dark:text-white">\n              {reviewSummary.total === 0\n                ? "Review your project sources and process supported files to continue."\n                : reviewSummary.needsAttention > 0\n                  ? \`Next step: Review the remaining \${reviewSummary.needsAttention} extracted \${reviewSummary.needsAttention === 1 ? "item" : "items"}.\`\n                  : "Extraction review complete. Continue to the BOQ workflow."}\n            </p>\n          </div>\n          {(reviewSummary.total === 0 || reviewSummary.complete) && (\n            <Link\n              href={\n                reviewSummary.complete\n                  ? importableEntityCount > 0\n                    ? \`/projects/\${encodedProjectId}/boq?action=import-reviewed\`\n                    : \`/projects/\${encodedProjectId}/boq\`\n                  : \`/projects/\${encodedProjectId}/files\`\n              }\n              className="inline-flex shrink-0 justify-center rounded-2xl bg-[#009FE3] px-4 py-2 text-sm font-semibold text-white hover:opacity-90 dark:bg-[#21C7F3] dark:text-[#040A16]"\n            >\n              {reviewSummary.complete ? "Continue to BOQ" : "Review Project Sources"}\n            </Link>\n          )}\n        </div>`;

const newNextStep = `        {reviewSummary.total === 0 ? (\n          <div className="mt-6 flex flex-col gap-4 rounded-2xl border border-[#009FE3]/30 bg-[#009FE3]/5 p-5 dark:border-[#21C7F3]/30 dark:bg-[#21C7F3]/5 sm:flex-row sm:items-center sm:justify-between">\n            <div>\n              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#0077B6] dark:text-[#21C7F3]">What should I do next?</p>\n              <p className="mt-2 text-sm font-medium text-[#0B1630] dark:text-white">\n                Review your project sources and process supported files to continue.\n              </p>\n            </div>\n            <Link\n              href={\`/projects/\${encodedProjectId}/files\`}\n              className="inline-flex shrink-0 justify-center rounded-2xl bg-[#009FE3] px-4 py-2 text-sm font-semibold text-white hover:opacity-90 dark:bg-[#21C7F3] dark:text-[#040A16]"\n            >\n              Review Project Sources\n            </Link>\n          </div>\n        ) : (\n          <div className="mt-6 rounded-3xl border border-[#009FE3]/30 bg-[#009FE3]/5 p-5 dark:border-[#21C7F3]/30 dark:bg-[#21C7F3]/5">\n            <div>\n              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#0077B6] dark:text-[#21C7F3]">Choose how you want to continue</p>\n              <h3 className="mt-2 text-xl font-semibold text-[#0B1630] dark:text-white">Review where it is fastest for you</h3>\n              <p className="mt-2 max-w-4xl text-sm leading-6 text-[#536078] dark:text-[#B8C4D8]">\n                Quantara can prepare the editable BOQ now, or you can review extracted information first. The AI Draft path never approves extraction and never invents commercial rates.\n              </p>\n            </div>\n\n            <div className="mt-5 grid gap-3 lg:grid-cols-3">\n              <div className="flex flex-col rounded-2xl border border-[#009FE3]/40 bg-white p-5 dark:border-[#21C7F3]/40 dark:bg-[#0B1426]">\n                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#0077B6] dark:text-[#21C7F3]">Fastest path</p>\n                <h4 className="mt-2 font-semibold text-[#0B1630] dark:text-white">Generate Draft BOQ Now</h4>\n                <p className="mt-2 flex-1 text-sm leading-6 text-[#536078] dark:text-[#B8C4D8]">\n                  Prepare the editable BOQ from {draftSummary.eligibleCount} usable extracted {draftSummary.eligibleCount === 1 ? "item" : "items"}. Review the completed table and correct only what is wrong.\n                </p>\n                {draftSummary.skippedCount > 0 && (\n                  <p className="mt-2 text-xs font-medium text-[#D98A16] dark:text-amber-300">\n                    {draftSummary.skippedCount} incomplete {draftSummary.skippedCount === 1 ? "candidate" : "candidates"} will stay in extraction review.\n                  </p>\n                )}\n                <button\n                  type="button"\n                  onClick={() => void generateDraftBoq()}\n                  disabled={isGeneratingDraft || draftSummary.eligibleCount === 0}\n                  className="mt-4 rounded-xl bg-[#009FE3] px-4 py-2.5 text-sm font-semibold text-white transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40 dark:bg-[#21C7F3] dark:text-[#040A16]"\n                >\n                  {isGeneratingDraft ? "Preparing AI Draft..." : "Generate Draft BOQ Now"}\n                </button>\n              </div>\n\n              <div className="flex flex-col rounded-2xl border border-[#D98A16]/30 bg-white p-5 dark:border-amber-400/20 dark:bg-[#0B1426]">\n                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#D98A16] dark:text-amber-300">Exception review</p>\n                <h4 className="mt-2 font-semibold text-[#0B1630] dark:text-white">Review Exceptions First</h4>\n                <p className="mt-2 flex-1 text-sm leading-6 text-[#536078] dark:text-[#B8C4D8]">\n                  Focus only on {priorityCounts.CRITICAL + priorityCounts.REVIEW} critical or recommended-review {priorityCounts.CRITICAL + priorityCounts.REVIEW === 1 ? "item" : "items"} before preparing the BOQ.\n                </p>\n                <button\n                  type="button"\n                  onClick={reviewExceptionsFirst}\n                  disabled={priorityCounts.CRITICAL + priorityCounts.REVIEW === 0}\n                  className="mt-4 rounded-xl border border-[#D98A16] px-4 py-2.5 text-sm font-semibold text-[#D98A16] transition hover:bg-[#D98A16]/5 disabled:cursor-not-allowed disabled:opacity-40 dark:text-amber-300"\n                >\n                  Review Exceptions\n                </button>\n              </div>\n\n              <div className="flex flex-col rounded-2xl border border-[#D9E2EC] bg-white p-5 dark:border-[#1E2A42] dark:bg-[#0B1426]">\n                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#7B879C] dark:text-[#7F8DA6]">Full professional review</p>\n                <h4 className="mt-2 font-semibold text-[#0B1630] dark:text-white">Review Everything First</h4>\n                <p className="mt-2 flex-1 text-sm leading-6 text-[#536078] dark:text-[#B8C4D8]">\n                  Keep the existing detailed workflow and confirm, correct, or reject every extracted candidate before BOQ preparation.\n                </p>\n                <button\n                  type="button"\n                  onClick={reviewEverythingFirst}\n                  className="mt-4 rounded-xl border border-[#D9E2EC] px-4 py-2.5 text-sm font-semibold text-[#536078] transition hover:bg-[#EEF3F8] dark:border-[#1E2A42] dark:text-[#B8C4D8] dark:hover:bg-[#111D33]"\n                >\n                  Review All Extracted Data\n                </button>\n              </div>\n            </div>\n\n            <p className="mt-4 text-xs leading-5 text-[#7B879C] dark:text-[#7F8DA6]">\n              AI Draft quantities remain professionally unconfirmed until you explicitly confirm them from the BOQ. Rates remain unselected until you use your package, catalogue, company library, or manual pricing workflow.\n            </p>\n          </div>\n        )}`;

extractionNext = replaceOnce(extractionNext, oldNextStep, newNextStep, "three-way post-extraction choice");

const resetAnchor = `onClick={() => setFilters({ ...DEFAULT_EXTRACTION_REVIEW_FILTERS })}`;
const resetCount = countOf(extractionNext, resetAnchor);
if (resetCount !== 2) {
  throw new Error(`STOP: reset-filter anchors expected exactly 2 but found ${resetCount}. NOTHING WRITTEN.`);
}
extractionNext = extractionNext.split(resetAnchor).join(
  `onClick={() => { setFilters({ ...DEFAULT_EXTRACTION_REVIEW_FILTERS }); setExceptionsOnly(false); }}`,
);

// ---------------------------------------------------------------------------
// BOQ page — show AI Draft review mode and explicit bulk quantity confirmation.
// ---------------------------------------------------------------------------
boqNext = replaceOnce(
  boqNext,
`type PendingAction = "save" | "create" | "revision" | "lock" | null;\n\nconst WORKFLOW_FACT_TRANSLATION_KEYS`,
`type PendingAction = "save" | "create" | "revision" | "lock" | null;\n\ntype AiDraftConfirmationResult = {\n  confirmedCount: number;\n  skippedCount: number;\n  remainingCount: number;\n};\n\nconst WORKFLOW_FACT_TRANSLATION_KEYS`,
  "AI Draft confirmation result type",
);

boqNext = replaceOnce(
  boqNext,
`  const [validationWarningCount, setValidationWarningCount] = useState<number | null>(null);\n  const [validationPreviewError, setValidationPreviewError] = useState<string | null>(null);\n  const handledActionSignatureRef`,
`  const [validationWarningCount, setValidationWarningCount] = useState<number | null>(null);\n  const [validationPreviewError, setValidationPreviewError] = useState<string | null>(null);\n  const [isConfirmingAiDraft, setIsConfirmingAiDraft] = useState(false);\n  const [aiDraftMessage, setAiDraftMessage] = useState<string | null>(null);\n  const handledActionSignatureRef`,
  "AI Draft BOQ state",
);

boqNext = replaceOnce(
  boqNext,
`  const activeRevision = useMemo(() => activeBoq ?? revisions[0] ?? null, [activeBoq, revisions]);\n\n  const activeRevisionId = activeRevision?.id ?? null;\n\n  useEffect(() => {`,
`  const activeRevision = useMemo(() => activeBoq ?? revisions[0] ?? null, [activeBoq, revisions]);\n\n  const activeRevisionId = activeRevision?.id ?? null;\n  const aiDraftMode = searchParams.get("aiDraft") === "1";\n  const aiDraftAddedCount = Number(searchParams.get("added") ?? "0") || 0;\n  const aiDraftSkippedCount = Number(searchParams.get("skipped") ?? "0") || 0;\n  const aiDraftExistingCount = Number(searchParams.get("existing") ?? "0") || 0;\n\n  const confirmRemainingAiDraftQuantities = useCallback(async () => {\n    if (!activeRevision || isReadOnlyBOQ(activeRevision) || isConfirmingAiDraft) return;\n    if (hasUnsavedChanges) {\n      setActionError(t("boqEditor.saveBeforeAddingOrImporting"));\n      return;\n    }\n\n    setIsConfirmingAiDraft(true);\n    setActionError(null);\n    setAiDraftMessage(null);\n    try {\n      const result = await apiClient.post<AiDraftConfirmationResult>(\n        \`/api/boqs/\${encodeURIComponent(activeRevision.id)}/ai-draft/confirm-quantities\`,\n        {},\n      );\n      setAiDraftMessage(\n        result.confirmedCount > 0\n          ? \`\${result.confirmedCount} AI Draft \${result.confirmedCount === 1 ? "quantity was" : "quantities were"} professionally confirmed. \${result.remainingCount} remain for review.\`\n          : "No additional AI Draft quantities were confirmed. Review any remaining exceptions before finalizing.",\n      );\n      await loadWorkspace();\n    } catch (error) {\n      setActionError(getLocalizedApiErrorMessage(error, t, locale));\n    } finally {\n      setIsConfirmingAiDraft(false);\n    }\n  }, [activeRevision, hasUnsavedChanges, isConfirmingAiDraft, loadWorkspace, locale, t]);\n\n  useEffect(() => {`,
  "AI Draft BOQ query and confirmation handler",
);

boqNext = replaceOnce(
  boqNext,
`      {workflowFactsWarning ? (`,
`      {aiDraftMode && activeRevision && !isReadOnly && (\n        <section className="rounded-[28px] border border-blue-500/40 bg-blue-500/10 p-5 text-slate-200">\n          <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">\n            <div className="max-w-3xl">\n              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-blue-300">AI Draft BOQ</p>\n              <h3 className="mt-2 text-xl font-semibold text-white">Review the completed BOQ instead of approving extraction one item at a time</h3>\n              <p className="mt-2 text-sm leading-6 text-slate-300">\n                Quantara added {aiDraftAddedCount} extracted {aiDraftAddedCount === 1 ? "item" : "items"} to this editable draft.\n                {aiDraftExistingCount > 0 ? \` \${aiDraftExistingCount} extracted \${aiDraftExistingCount === 1 ? "item was" : "items were"} already present and were not duplicated.\` : ""}\n                {aiDraftSkippedCount > 0 ? \` \${aiDraftSkippedCount} incomplete \${aiDraftSkippedCount === 1 ? "candidate still needs" : "candidates still need"} extraction review.\` : ""}\n              </p>\n              <p className="mt-2 text-xs leading-5 text-slate-400">\n                Quantities from unreviewed extraction remain unconfirmed until you approve them here. Quantara does not invent rates: use your purchased packages, catalogue/company library, or manual pricing before final validation.\n              </p>\n            </div>\n            <div className="flex shrink-0 flex-wrap gap-2">\n              <button\n                type="button"\n                onClick={() => {\n                  const editor = document.getElementById("boq-editor-section");\n                  editor?.scrollIntoView({ behavior: "smooth", block: "start" });\n                  editor?.focus({ preventScroll: true });\n                }}\n                className="rounded-xl border border-slate-600 px-4 py-2 text-sm font-semibold text-slate-200 hover:bg-slate-800"\n              >\n                Review BOQ\n              </button>\n              <button\n                type="button"\n                onClick={() => void confirmRemainingAiDraftQuantities()}\n                disabled={isConfirmingAiDraft || hasUnsavedChanges}\n                title={hasUnsavedChanges ? "Save the BOQ before confirming AI Draft quantities." : ""}\n                className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-50"\n              >\n                {isConfirmingAiDraft ? "Confirming..." : "Confirm Remaining Draft Quantities"}\n              </button>\n              {aiDraftSkippedCount > 0 && (\n                <button\n                  type="button"\n                  onClick={() => router.push(\`/projects/\${encodeURIComponent(params.projectId)}/extractions\`)}\n                  className="rounded-xl border border-amber-600/70 px-4 py-2 text-sm font-semibold text-amber-200 hover:bg-amber-950/30"\n                >\n                  Review {aiDraftSkippedCount} Extraction {aiDraftSkippedCount === 1 ? "Exception" : "Exceptions"}\n                </button>\n              )}\n            </div>\n          </div>\n          {aiDraftMessage && (\n            <p role="status" className="mt-4 rounded-xl border border-emerald-700/60 bg-emerald-950/30 px-4 py-3 text-sm text-emerald-200">\n              {aiDraftMessage}\n            </p>\n          )}\n        </section>\n      )}\n\n      {workflowFactsWarning ? (`,
  "AI Draft BOQ review banner",
);

// All anchors are proven before any write occurs.
fs.writeFileSync(extractionPath, extractionNext.replace(/\n/g, extraction.eol), "utf8");
fs.writeFileSync(boqPath, boqNext.replace(/\n/g, boq.eol), "utf8");
console.log("PASS: existing extraction and BOQ pages transformed safely.");
