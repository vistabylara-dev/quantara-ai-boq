$ErrorActionPreference = "Stop"

function Stop-Run([string]$Message) {
    throw "STOP: $Message"
}

$root = "$env:USERPROFILE\Desktop\quantara-ai-boq"
$wt = "$root\.worktrees\ai-draft-boq-20260816"
$trustedWt = "$root\.worktrees\extraction-review-filters-20260816"
$bundle = Split-Path -Parent $MyInvocation.MyCommand.Path

$expectedMain = "ef9f27e80e5aabb25930c4e0d39aa6dffffa6766"
$expectedBranch = "feat/ai-draft-boq-20260816"

Write-Host "`n=== 1. VERIFY EXISTING CLEAN PHASE 2B WORKTREE ===" -ForegroundColor Cyan

if (-not (Test-Path -LiteralPath $root)) {
    Stop-Run "main repository folder not found."
}
if (-not (Test-Path -LiteralPath $wt)) {
    Stop-Run "Phase 2B worktree not found."
}

Set-Location $root
git fetch origin main
if ($LASTEXITCODE -ne 0) { Stop-Run "git fetch failed." }

$remoteMain = [string](git rev-parse origin/main)
$remoteMain = $remoteMain.Trim()
if ($remoteMain -ne $expectedMain) {
    Stop-Run "origin/main moved. Expected $expectedMain but found $remoteMain."
}

Set-Location $wt

$currentBranch = [string](git branch --show-current)
$currentBranch = $currentBranch.Trim()
if ($currentBranch -ne $expectedBranch) {
    Stop-Run "wrong worktree branch: $currentBranch"
}

$currentHead = [string](git rev-parse HEAD)
$currentHead = $currentHead.Trim()
if ($currentHead -ne $expectedMain) {
    Stop-Run "Phase 2B worktree HEAD is not the pinned production base."
}

$preExistingChanges = @(git status --porcelain=v1 --untracked-files=all)
if ($preExistingChanges.Count -gt 0) {
    Write-Host ($preExistingChanges -join "`n") -ForegroundColor Yellow
    Stop-Run "Phase 2B worktree is not clean before applying the bundle."
}

Write-Host "PASS: clean isolated worktree at exact production main." -ForegroundColor Green


Write-Host "`n=== 2. DEPENDENCIES ===" -ForegroundColor Cyan

if (-not (Test-Path -LiteralPath "$wt\node_modules")) {
    $reused = $false

    if (
        (Test-Path -LiteralPath "$trustedWt\node_modules") -and
        (Test-Path -LiteralPath "$trustedWt\package-lock.json") -and
        (Test-Path -LiteralPath "$trustedWt\prisma\schema.prisma")
    ) {
        $newLock = (Get-FileHash -LiteralPath "$wt\package-lock.json" -Algorithm SHA256).Hash
        $trustedLock = (Get-FileHash -LiteralPath "$trustedWt\package-lock.json" -Algorithm SHA256).Hash
        $newSchema = (Get-FileHash -LiteralPath "$wt\prisma\schema.prisma" -Algorithm SHA256).Hash
        $trustedSchema = (Get-FileHash -LiteralPath "$trustedWt\prisma\schema.prisma" -Algorithm SHA256).Hash

        if (($newLock -eq $trustedLock) -and ($newSchema -eq $trustedSchema)) {
            try {
                New-Item -ItemType Junction -Path "$wt\node_modules" -Target "$trustedWt\node_modules" -ErrorAction Stop | Out-Null
                $reused = $true
                Write-Host "PASS: reused verified dependency tree from the previous isolated worktree." -ForegroundColor Green
            } catch {
                Write-Host "Dependency junction reuse failed; using isolated npm ci instead." -ForegroundColor Yellow
            }
        }
    }

    if (-not $reused) {
        npm.cmd ci --ignore-scripts --no-audit --no-fund
        if ($LASTEXITCODE -ne 0) { Stop-Run "npm ci failed." }

        $env:DATABASE_URL = "postgresql://codegen:codegen@127.0.0.1:1/quantara_codegen"
        npx.cmd prisma generate --schema prisma/schema.prisma
        if ($LASTEXITCODE -ne 0) { Stop-Run "prisma generate failed." }
    }
} else {
    Write-Host "PASS: node_modules already available in the isolated worktree." -ForegroundColor Green
}


Write-Host "`n=== 3. APPLY EXACT UI TRANSFORMS ===" -ForegroundColor Cyan

$transform = Join-Path $bundle "transforms\apply-transform.cjs"
if (-not (Test-Path -LiteralPath $transform)) {
    Stop-Run "bundle transform file missing."
}

node $transform $wt
if ($LASTEXITCODE -ne 0) {
    Stop-Run "UI transform failed."
}


Write-Host "`n=== 4. COPY NEW AI DRAFT FILES ===" -ForegroundColor Cyan

$newFiles = @(
    "src\lib\guidance\ai-draft-boq.ts",
    "src\lib\services\ai-draft-boq-service.ts",
    "src\app\api\projects\[projectId]\extractions\generate-draft-boq\route.ts",
    "src\app\api\boqs\[boqId]\ai-draft\confirm-quantities\route.ts",
    "tests\ai-draft-boq-workflow.test.ts"
)

foreach ($relative in $newFiles) {
    $source = Join-Path (Join-Path $bundle "files") $relative
    $target = Join-Path $wt $relative

    if (-not (Test-Path -LiteralPath $source)) {
        Stop-Run "bundle source file missing: $relative"
    }
    if (Test-Path -LiteralPath $target) {
        Stop-Run "expected new repository file already exists: $relative"
    }

    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
    Copy-Item -LiteralPath $source -Destination $target
}

Write-Host "PASS: new AI Draft files copied." -ForegroundColor Green


Write-Host "`n=== 5. EXACT FILE SCOPE + PROTECTED AREAS ===" -ForegroundColor Cyan

$expectedFiles = @(
    "src/app/api/boqs/[boqId]/ai-draft/confirm-quantities/route.ts",
    "src/app/api/projects/[projectId]/extractions/generate-draft-boq/route.ts",
    "src/app/projects/[projectId]/boq/page.tsx",
    "src/app/projects/[projectId]/extractions/page.tsx",
    "src/lib/guidance/ai-draft-boq.ts",
    "src/lib/services/ai-draft-boq-service.ts",
    "tests/ai-draft-boq-workflow.test.ts"
) | Sort-Object

$changed = @(
    @(git diff --name-only)
    @(git ls-files --others --exclude-standard)
) | Where-Object { $_ } | Sort-Object -Unique

$scopeDiff = Compare-Object $expectedFiles $changed
if ($scopeDiff) {
    Write-Host "EXPECTED:" -ForegroundColor Yellow
    $expectedFiles
    Write-Host "ACTUAL:" -ForegroundColor Yellow
    $changed
    Stop-Run "unexpected file scope."
}

$protectedPatterns = @(
    "^prisma/",
    "^src/lib/db/",
    "^src/lib/worker/",
    "^src/app/projects/\[projectId\]/tayqan/",
    "^src/lib/services/industry-package",
    "^src/lib/services/master-catalogue",
    "^src/lib/entitlements/",
    "^src/lib/stripe/",
    "^src/app/api/stripe/"
)

foreach ($file in $changed) {
    foreach ($pattern in $protectedPatterns) {
        if ($file -match $pattern) {
            Stop-Run "protected file changed: $file"
        }
    }
}

git diff --check
if ($LASTEXITCODE -ne 0) { Stop-Run "git diff --check failed." }

Write-Host "PASS: exactly 7 intended files." -ForegroundColor Green
Write-Host "DATABASE: NO" -ForegroundColor Green
Write-Host "PRISMA/SCHEMA/MIGRATIONS: NO" -ForegroundColor Green
Write-Host "TAYQAN/ROBOT: NO" -ForegroundColor Green
Write-Host "EXTRACTION ENGINE: NO" -ForegroundColor Green
Write-Host "PACKAGE/CATALOGUE ENTITLEMENTS: NO" -ForegroundColor Green
Write-Host "STRIPE: NO" -ForegroundColor Green


Write-Host "`n=== 6. FOCUSED TESTS ===" -ForegroundColor Cyan

npx.cmd vitest run tests/ai-draft-boq-workflow.test.ts tests/extraction-review-filters.test.ts
if ($LASTEXITCODE -ne 0) { Stop-Run "focused tests failed." }


Write-Host "`n=== 7. TARGETED ESLINT ===" -ForegroundColor Cyan

npx.cmd eslint `
    --no-eslintrc `
    --config "$wt\.eslintrc.json" `
    --resolve-plugins-relative-to "$wt" `
    "src/app/api/boqs/[boqId]/ai-draft/confirm-quantities/route.ts" `
    "src/app/api/projects/[projectId]/extractions/generate-draft-boq/route.ts" `
    "src/app/projects/[projectId]/boq/page.tsx" `
    "src/app/projects/[projectId]/extractions/page.tsx" `
    "src/lib/guidance/ai-draft-boq.ts" `
    "src/lib/services/ai-draft-boq-service.ts" `
    "tests/ai-draft-boq-workflow.test.ts" `
    --max-warnings=0

if ($LASTEXITCODE -ne 0) { Stop-Run "ESLint failed." }


Write-Host "`n=== 8. FULL TYPECHECK ===" -ForegroundColor Cyan

npm.cmd run typecheck
if ($LASTEXITCODE -ne 0) {
    Stop-Run "typecheck failed. Nothing will be committed."
}


Write-Host "`n=== 9. RE-CHECK MAIN HAS NOT MOVED ===" -ForegroundColor Cyan

Set-Location $root
git fetch origin main
if ($LASTEXITCODE -ne 0) { Stop-Run "final git fetch failed." }

$finalMain = [string](git rev-parse origin/main)
$finalMain = $finalMain.Trim()
if ($finalMain -ne $expectedMain) {
    Set-Location $wt
    Stop-Run "main changed while validating. Changes remain isolated and uncommitted."
}

Set-Location $wt
Write-Host "PASS: main is still the exact pinned base." -ForegroundColor Green


Write-Host "`n=== 10. STAGE EXACT FILES + COMMIT ===" -ForegroundColor Cyan

git add -- `
    "src/app/api/boqs/[boqId]/ai-draft/confirm-quantities/route.ts" `
    "src/app/api/projects/[projectId]/extractions/generate-draft-boq/route.ts" `
    "src/app/projects/[projectId]/boq/page.tsx" `
    "src/app/projects/[projectId]/extractions/page.tsx" `
    "src/lib/guidance/ai-draft-boq.ts" `
    "src/lib/services/ai-draft-boq-service.ts" `
    "tests/ai-draft-boq-workflow.test.ts"

$staged = @(git diff --cached --name-only | Sort-Object)
if (Compare-Object $expectedFiles $staged) {
    Stop-Run "staged scope is not exactly the 7 intended files."
}

git diff --cached --check
if ($LASTEXITCODE -ne 0) { Stop-Run "staged diff check failed." }

git commit -m "feat: add direct AI draft BOQ review path"
if ($LASTEXITCODE -ne 0) { Stop-Run "commit failed." }


Write-Host "`n=== 11. PUSH FEATURE BRANCH ONLY ===" -ForegroundColor Cyan

git push -u origin $expectedBranch
if ($LASTEXITCODE -ne 0) { Stop-Run "push failed." }

$commit = [string](git rev-parse HEAD)
$commit = $commit.Trim()

Write-Host "`n==================================================" -ForegroundColor Green
Write-Host "AI DRAFT BOQ PHASE 2B COMPLETE" -ForegroundColor Green
Write-Host "BRANCH: $expectedBranch"
Write-Host "COMMIT: $commit"
Write-Host "FOCUSED TESTS: PASS"
Write-Host "ESLINT: PASS"
Write-Host "TYPECHECK: PASS"
Write-Host "FILES CHANGED: 7"
Write-Host "MAIN: UNTOUCHED"
Write-Host "DATABASE/PRISMA/MIGRATIONS: UNTOUCHED"
Write-Host "TAYQAN/ROBOT: UNTOUCHED"
Write-Host "PACKAGE/CATALOGUE/STRIPE: UNTOUCHED"
Write-Host "==================================================" -ForegroundColor Green
Write-Host ""
Write-Host "STOP HERE. Do not merge yet."
