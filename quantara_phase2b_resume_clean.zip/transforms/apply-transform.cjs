const fs = require("fs");
const path = require("path");

const wt = process.argv[2];
if (!wt) throw new Error("worktree path is required");

function read(rel) {
  return fs.readFileSync(path.join(wt, rel), "utf8").replace(/\r\n/g, "\n");
}

function write(rel, text) {
  fs.writeFileSync(path.join(wt, rel), text.replace(/\n/g, "\r\n"), "utf8");
}

function replaceOnce(text, before, after, label) {
  const count = text.split(before).length - 1;
  if (count !== 1) {
    throw new Error(`${label}: expected exact anchor once, found ${count}. No files written.`);
  }
  return text.replace(before, after);
}

const extractionRel = "src/app/projects/[projectId]/extractions/page.tsx";
const boqRel = "src/app/projects/[projectId]/boq/page.tsx";

let extraction = read(extractionRel);
let boq = read(boqRel);

const originalExtraction = extraction;
const originalBoq = boq;

try {
  extraction = replaceOnce(
    extraction,
`  type ExtractionReviewFilters,
} from "@/lib/guidance/extraction-review-filters";
import { GuideTip } from "@/components/guidance/guide-tip";`,
`  type ExtractionReviewFilters,
} from "@/lib/guidance/extraction-review-filters";
import { summarizeAiDraftCandidates } from "@/lib/guidance/ai-draft-boq";
import { GuideTip } from "@/components/guidance/guide-tip";`,
    "extraction helper import",
  );

  extraction = replaceOnce(
    extraction,
`type PendingAction = {
  entityId: string;
  action: "confirm" | "correct" | "reject";
};

const EXTRACTION_STATUS_TONE`,
`type PendingAction = {
  entityId: string;
  action: "confirm" | "correct" | "reject";
};

type AiDraftGenerationResult = {
  boqId: string;
  addedCount: number;
  skippedCount: number;
  alreadyPresentCount: number;
  unreviewedAddedCount: number;
  reviewedAddedCount: number;
};

const EXTRACTION_STATUS_TONE`,
    "extraction draft response type",
  );

  extraction = replaceOnce(
    extraction,
`  const [formError, setFormError] = useState<string | null>(null);
  const [filters, setFilters] = useState<ExtractionReviewFilters>({ ...DEFAULT_EXTRACTION_REVIEW_FILTERS });

  const encodedProjectId`,
`  const [formError, setFormError] = useState<string | null>(null);
  const [filters, setFilters] = useState<ExtractionReviewFilters>({ ...DEFAULT_EXTRACTION_REVIEW_FILTERS });
  const [exceptionsOnly, setExceptionsOnly] = useState(false);
  const [isGeneratingDraft, setIsGeneratingDraft] = useState(false);

  const encodedProjectId`,
    "extraction draft state",
  );

  extraction = replaceOnce(
    extraction,
`  const importableEntityCount = useMemo(
    () => entities.filter(
      (entity) => entity.status === "CONFIRMED" || entity.status === "CORRECTED",
    ).length,
    [entities],
  );

  const filteredEntities = useMemo(
    () => filterExtractionReviewEntities(entities, filters),
    [entities, filters],
  );`,
`  const importableEntityCount = useMemo(
    () => entities.filter(
      (entity) => entity.status === "CONFIRMED" || entity.status === "CORRECTED",
    ).length,
    [entities],
  );

  const draftSummary = useMemo(
    () => summarizeAiDraftCandidates(entities),
    [entities],
  );

  const filteredEntities = useMemo(() => {
    const filtered = filterExtractionReviewEntities(entities, filters);
    if (!exceptionsOnly) return filtered;
    return filtered.filter(
      (entity) =>
        isReviewableExtractionStatus(entity.status)
        && getExtractionReviewPriority(entity) !== "SAFE",
    );
  }, [entities, exceptionsOnly, filters]);`,
    "extraction summary and exception view",
  );

  extraction = replaceOnce(
    extraction,
`  const hasActiveFilters = Object.entries(filters).some(
    ([key, value]) => key === "search" ? Boolean(value.trim()) : value !== "ALL",
  );`,
`  const hasActiveFilters = exceptionsOnly || Object.entries(filters).some(
    ([key, value]) => key === "search" ? Boolean(value.trim()) : value !== "ALL",
  );`,
    "extraction active filters",
  );

  extraction = replaceOnce(
    extraction,
`  function openRejection(entityId: string) {
    setRejectingId(entityId);
    setCorrectingId(null);
    setRejectionReason("");
    setCorrectionDraft({ label: "", quantity: "", unit: "", reason: "" });
    setFormError(null);
    setActionError(null);
  }

  if (isLoading) {`,
`  function openRejection(entityId: string) {
    setRejectingId(entityId);
    setCorrectingId(null);
    setRejectionReason("");
    setCorrectionDraft({ label: "", quantity: "", unit: "", reason: "" });
    setFormError(null);
    setActionError(null);
  }

  function focusReviewItems() {
    requestAnimationFrame(() => {
      const reviewItems = document.getElementById("extraction-review-items");
      reviewItems?.scrollIntoView({ behavior: "smooth", block: "start" });
      reviewItems?.focus({ preventScroll: true });
    });
  }

  function reviewExceptionsFirst() {
    setFilters({ ...DEFAULT_EXTRACTION_REVIEW_FILTERS });
    setExceptionsOnly(true);
    focusReviewItems();
  }

  function reviewEverythingFirst() {
    setFilters({ ...DEFAULT_EXTRACTION_REVIEW_FILTERS });
    setExceptionsOnly(false);
    focusReviewItems();
  }

  async function generateDraftBoq() {
    if (isGeneratingDraft || draftSummary.eligibleCount === 0) return;
    setIsGeneratingDraft(true);
    setActionError(null);
    setActionMessage(null);

    try {
      const result = await apiClient.post<AiDraftGenerationResult>(
        \`/api/projects/\${encodedProjectId}/extractions/generate-draft-boq\`,
        {},
      );
      const query = new URLSearchParams({
        aiDraft: "1",
        added: String(result.addedCount),
        skipped: String(result.skippedCount),
        existing: String(result.alreadyPresentCount),
      });
      window.location.assign(\`/projects/\${encodedProjectId}/boq?\${query.toString()}\`);
    } catch (error) {
      setActionError(
        error instanceof ApiClientError
          ? error.message
          : "The AI Draft BOQ could not be prepared. Try again.",
      );
    } finally {
      setIsGeneratingDraft(false);
    }
  }

  if (isLoading) {`,
    "extraction draft actions",
  );

  extraction = replaceOnce(
    extraction,
`          Quantara presents source-linked candidates for professional review. Nothing on this page is confirmed or added to a BOQ automatically.`,
`          Quantara presents source-linked candidates for professional review. Nothing is professionally confirmed automatically. You can review first, or prepare an editable AI Draft BOQ and perform the professional review in the completed BOQ table.`,
    "extraction intro",
  );

  extraction = replaceOnce(
    extraction,
`        <div className="mt-6 flex flex-col gap-4 rounded-2xl border border-[#009FE3]/30 bg-[#009FE3]/5 p-5 dark:border-[#21C7F3]/30 dark:bg-[#21C7F3]/5 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#0077B6] dark:text-[#21C7F3]">What should I do next?</p>
            <p className="mt-2 text-sm font-medium text-[#0B1630] dark:text-white">
              {reviewSummary.total === 0
                ? "Review your project sources and process supported files to continue."
                : reviewSummary.needsAttention > 0
                  ? \`Next step: Review the remaining \${reviewSummary.needsAttention} extracted \${reviewSummary.needsAttention === 1 ? "item" : "items"}.\`
                  : "Extraction review complete. Continue to the BOQ workflow."}
            </p>
          </div>
          {(reviewSummary.total === 0 || reviewSummary.complete) && (
            <Link
              href={
                reviewSummary.complete
                  ? importableEntityCount > 0
                    ? \`/projects/\${encodedProjectId}/boq?action=import-reviewed\`
                    : \`/projects/\${encodedProjectId}/boq\`
                  : \`/projects/\${encodedProjectId}/files\`
              }
              className="inline-flex shrink-0 justify-center rounded-2xl bg-[#009FE3] px-4 py-2 text-sm font-semibold text-white hover:opacity-90 dark:bg-[#21C7F3] dark:text-[#040A16]"
            >
              {reviewSummary.complete ? "Continue to BOQ" : "Review Project Sources"}
            </Link>
          )}
        </div>`,
`        {reviewSummary.total === 0 ? (
          <div className="mt-6 flex flex-col gap-4 rounded-2xl border border-[#009FE3]/30 bg-[#009FE3]/5 p-5 dark:border-[#21C7F3]/30 dark:bg-[#21C7F3]/5 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#0077B6] dark:text-[#21C7F3]">What should I do next?</p>
              <p className="mt-2 text-sm font-medium text-[#0B1630] dark:text-white">
                Review your project sources and process supported files to continue.
              </p>
            </div>
            <Link
              href={\`/projects/\${encodedProjectId}/files\`}
              className="inline-flex shrink-0 justify-center rounded-2xl bg-[#009FE3] px-4 py-2 text-sm font-semibold text-white hover:opacity-90 dark:bg-[#21C7F3] dark:text-[#040A16]"
            >
              Review Project Sources
            </Link>
          </div>
        ) : (
          <div className="mt-6 rounded-3xl border border-[#009FE3]/30 bg-[#009FE3]/5 p-5 dark:border-[#21C7F3]/30 dark:bg-[#21C7F3]/5">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#0077B6] dark:text-[#21C7F3]">Choose how you want to continue</p>
            <h3 className="mt-2 text-xl font-semibold text-[#0B1630] dark:text-white">Review where it is fastest for you</h3>
            <p className="mt-2 max-w-4xl text-sm leading-6 text-[#536078] dark:text-[#B8C4D8]">
              Quantara can prepare the editable BOQ now, or you can review extracted information first. The AI Draft path never approves extraction silently and never invents commercial rates.
            </p>

            <div className="mt-5 grid gap-3 lg:grid-cols-3">
              <div className="flex flex-col rounded-2xl border border-[#009FE3]/40 bg-white p-5 dark:border-[#21C7F3]/40 dark:bg-[#0B1426]">
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#0077B6] dark:text-[#21C7F3]">Fastest path</p>
                <h4 className="mt-2 font-semibold text-[#0B1630] dark:text-white">Generate Draft BOQ Now</h4>
                <p className="mt-2 flex-1 text-sm leading-6 text-[#536078] dark:text-[#B8C4D8]">
                  Prepare the editable BOQ from {draftSummary.eligibleCount} usable extracted {draftSummary.eligibleCount === 1 ? "item" : "items"}. Review the completed table and correct only what is wrong.
                </p>
                {draftSummary.skippedCount > 0 && (
                  <p className="mt-2 text-xs font-medium text-[#D98A16] dark:text-amber-300">
                    {draftSummary.skippedCount} incomplete {draftSummary.skippedCount === 1 ? "candidate" : "candidates"} will stay in extraction review.
                  </p>
                )}
                <button
                  type="button"
                  onClick={() => void generateDraftBoq()}
                  disabled={isGeneratingDraft || draftSummary.eligibleCount === 0}
                  className="mt-4 rounded-xl bg-[#009FE3] px-4 py-2.5 text-sm font-semibold text-white transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40 dark:bg-[#21C7F3] dark:text-[#040A16]"
                >
                  {isGeneratingDraft ? "Preparing AI Draft..." : "Generate Draft BOQ Now"}
                </button>
              </div>

              <div className="flex flex-col rounded-2xl border border-[#D98A16]/30 bg-white p-5 dark:border-amber-400/20 dark:bg-[#0B1426]">
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#D98A16] dark:text-amber-300">Exception review</p>
                <h4 className="mt-2 font-semibold text-[#0B1630] dark:text-white">Review Exceptions First</h4>
                <p className="mt-2 flex-1 text-sm leading-6 text-[#536078] dark:text-[#B8C4D8]">
                  Focus only on {priorityCounts.CRITICAL + priorityCounts.REVIEW} critical or recommended-review {priorityCounts.CRITICAL + priorityCounts.REVIEW === 1 ? "item" : "items"} before preparing the BOQ.
                </p>
                <button
                  type="button"
                  onClick={reviewExceptionsFirst}
                  disabled={priorityCounts.CRITICAL + priorityCounts.REVIEW === 0}
                  className="mt-4 rounded-xl border border-[#D98A16] px-4 py-2.5 text-sm font-semibold text-[#D98A16] transition hover:bg-[#D98A16]/5 disabled:cursor-not-allowed disabled:opacity-40 dark:text-amber-300"
                >
                  Review Exceptions
                </button>
              </div>

              <div className="flex flex-col rounded-2xl border border-[#D9E2EC] bg-white p-5 dark:border-[#1E2A42] dark:bg-[#0B1426]">
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#7B879C] dark:text-[#7F8DA6]">Full professional review</p>
                <h4 className="mt-2 font-semibold text-[#0B1630] dark:text-white">Review Everything First</h4>
                <p className="mt-2 flex-1 text-sm leading-6 text-[#536078] dark:text-[#B8C4D8]">
                  Keep the existing detailed workflow and confirm, correct, or reject every extracted candidate before BOQ preparation.
                </p>
                <button
                  type="button"
                  onClick={reviewEverythingFirst}
                  className="mt-4 rounded-xl border border-[#D9E2EC] px-4 py-2.5 text-sm font-semibold text-[#536078] transition hover:bg-[#EEF3F8] dark:border-[#1E2A42] dark:text-[#B8C4D8] dark:hover:bg-[#111D33]"
                >
                  Review All Extracted Data
                </button>
              </div>
            </div>

            <p className="mt-4 text-xs leading-5 text-[#7B879C] dark:text-[#7F8DA6]">
              AI Draft quantities remain professionally unconfirmed until you explicitly confirm them from the BOQ. Rates remain unselected until you use your purchased package, catalogue, company library, or manual pricing workflow.
            </p>
          </div>
        )}`,
    "extraction journey panel",
  );

  extraction = replaceOnce(
    extraction,
`              onClick={() => setFilters({ ...DEFAULT_EXTRACTION_REVIEW_FILTERS })}
              className="rounded-2xl border border-[#D9E2EC] px-4 py-2 text-sm font-semibold text-[#536078] disabled:cursor-not-allowed disabled:opacity-40 dark:border-[#1E2A42] dark:text-[#B8C4D8]"`,
`              onClick={() => {
                setFilters({ ...DEFAULT_EXTRACTION_REVIEW_FILTERS });
                setExceptionsOnly(false);
              }}
              className="rounded-2xl border border-[#D9E2EC] px-4 py-2 text-sm font-semibold text-[#536078] disabled:cursor-not-allowed disabled:opacity-40 dark:border-[#1E2A42] dark:text-[#B8C4D8]"`,
    "extraction reset filters",
  );

  boq = replaceOnce(
    boq,
`type PendingAction = "save" | "create" | "revision" | "lock" | null;

const WORKFLOW_FACT_TRANSLATION_KEYS`,
`type PendingAction = "save" | "create" | "revision" | "lock" | null;

type AiDraftConfirmationResult = {
  confirmedCount: number;
  skippedCount: number;
  remainingCount: number;
};

const WORKFLOW_FACT_TRANSLATION_KEYS`,
    "BOQ draft response type",
  );

  boq = replaceOnce(
    boq,
`  const [validationWarningCount, setValidationWarningCount] = useState<number | null>(null);
  const [validationPreviewError, setValidationPreviewError] = useState<string | null>(null);
  const handledActionSignatureRef`,
`  const [validationWarningCount, setValidationWarningCount] = useState<number | null>(null);
  const [validationPreviewError, setValidationPreviewError] = useState<string | null>(null);
  const [isConfirmingAiDraft, setIsConfirmingAiDraft] = useState(false);
  const [aiDraftMessage, setAiDraftMessage] = useState<string | null>(null);
  const handledActionSignatureRef`,
    "BOQ draft state",
  );

  boq = replaceOnce(
    boq,
`  const activeRevision = useMemo(() => activeBoq ?? revisions[0] ?? null, [activeBoq, revisions]);

  const activeRevisionId = activeRevision?.id ?? null;

  useEffect(() => {`,
`  const activeRevision = useMemo(() => activeBoq ?? revisions[0] ?? null, [activeBoq, revisions]);

  const activeRevisionId = activeRevision?.id ?? null;
  const aiDraftMode = searchParams.get("aiDraft") === "1";
  const aiDraftAddedCount = Number(searchParams.get("added") ?? "0") || 0;
  const aiDraftSkippedCount = Number(searchParams.get("skipped") ?? "0") || 0;
  const aiDraftExistingCount = Number(searchParams.get("existing") ?? "0") || 0;
  const hasAiDraftItems = useMemo(
    () => Boolean(activeRevision?.sections.some(
      (section) => section.items.some(
        (item) => item.notes?.includes("AI Draft from extracted project evidence"),
      ),
    )),
    [activeRevision],
  );
  const showAiDraftReview = aiDraftMode || hasAiDraftItems;

  const confirmRemainingAiDraftQuantities = useCallback(async () => {
    if (!activeRevision || isReadOnlyBOQ(activeRevision) || isConfirmingAiDraft) return;
    if (hasUnsavedChanges) {
      setActionError(t("boqEditor.saveBeforeAddingOrImporting"));
      return;
    }

    setIsConfirmingAiDraft(true);
    setActionError(null);
    setAiDraftMessage(null);
    try {
      const result = await apiClient.post<AiDraftConfirmationResult>(
        \`/api/boqs/\${encodeURIComponent(activeRevision.id)}/ai-draft/confirm-quantities\`,
        {},
      );
      setAiDraftMessage(
        result.confirmedCount > 0
          ? \`\${result.confirmedCount} AI Draft \${result.confirmedCount === 1 ? "quantity was" : "quantities were"} professionally confirmed. \${result.remainingCount} remain for review.\`
          : "No additional AI Draft quantities were confirmed. Review any remaining exceptions before finalizing.",
      );
      await loadWorkspace();
    } catch (error) {
      setActionError(getLocalizedApiErrorMessage(error, t, locale));
    } finally {
      setIsConfirmingAiDraft(false);
    }
  }, [activeRevision, hasUnsavedChanges, isConfirmingAiDraft, loadWorkspace, locale, t]);

  useEffect(() => {`,
    "BOQ draft confirmation handler",
  );

  boq = replaceOnce(
    boq,
`      {workflowFactsWarning ? (`,
`      {showAiDraftReview && activeRevision && !isReadOnly && (
        <section className="rounded-[28px] border border-blue-500/40 bg-blue-500/10 p-5 text-slate-200">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
            <div className="max-w-3xl">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-blue-300">AI Draft BOQ</p>
              <h3 className="mt-2 text-xl font-semibold text-white">Review the completed BOQ instead of approving extraction one item at a time</h3>
              <p className="mt-2 text-sm leading-6 text-slate-300">
                {aiDraftMode
                  ? \`Quantara added \${aiDraftAddedCount} extracted \${aiDraftAddedCount === 1 ? "item" : "items"} to this editable draft.\`
                  : "This editable BOQ contains AI Draft items from extracted project evidence."}
                {aiDraftMode && aiDraftExistingCount > 0 ? \` \${aiDraftExistingCount} extracted \${aiDraftExistingCount === 1 ? "item was" : "items were"} already present and were not duplicated.\` : ""}
                {aiDraftMode && aiDraftSkippedCount > 0 ? \` \${aiDraftSkippedCount} incomplete \${aiDraftSkippedCount === 1 ? "candidate still needs" : "candidates still need"} extraction review.\` : ""}
              </p>
              <p className="mt-2 text-xs leading-5 text-slate-400">
                Unchanged AI Draft quantities stay unconfirmed until you approve them here. Any quantity you edit follows the existing manual confirmation path. Quantara does not invent rates: use your purchased packages, catalogue/company library, or manual pricing before final validation.
              </p>
            </div>
            <div className="flex shrink-0 flex-wrap gap-2">
              <button
                type="button"
                onClick={() => {
                  const editor = document.getElementById("boq-editor-section");
                  editor?.scrollIntoView({ behavior: "smooth", block: "start" });
                  editor?.focus({ preventScroll: true });
                }}
                className="rounded-xl border border-slate-600 px-4 py-2 text-sm font-semibold text-slate-200 hover:bg-slate-800"
              >
                Review BOQ
              </button>
              <button
                type="button"
                onClick={() => void confirmRemainingAiDraftQuantities()}
                disabled={isConfirmingAiDraft || hasUnsavedChanges}
                title={hasUnsavedChanges ? "Save the BOQ before confirming AI Draft quantities." : ""}
                className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isConfirmingAiDraft ? "Confirming..." : "Confirm Remaining Draft Quantities"}
              </button>
              {aiDraftMode && aiDraftSkippedCount > 0 && (
                <button
                  type="button"
                  onClick={() => router.push(\`/projects/\${encodeURIComponent(params.projectId)}/extractions\`)}
                  className="rounded-xl border border-amber-600/70 px-4 py-2 text-sm font-semibold text-amber-200 hover:bg-amber-950/30"
                >
                  Review {aiDraftSkippedCount} Extraction {aiDraftSkippedCount === 1 ? "Exception" : "Exceptions"}
                </button>
              )}
            </div>
          </div>
          {aiDraftMessage && (
            <p role="status" className="mt-4 rounded-xl border border-emerald-700/60 bg-emerald-950/30 px-4 py-3 text-sm text-emerald-200">
              {aiDraftMessage}
            </p>
          )}
        </section>
      )}

      {workflowFactsWarning ? (`,
    "BOQ draft banner",
  );
} catch (error) {
  // Guarantee the transform is all-or-nothing for the two existing UI files.
  if (fs.existsSync(path.join(wt, extractionRel))) {
    fs.writeFileSync(path.join(wt, extractionRel), originalExtraction.replace(/\n/g, "\r\n"), "utf8");
  }
  if (fs.existsSync(path.join(wt, boqRel))) {
    fs.writeFileSync(path.join(wt, boqRel), originalBoq.replace(/\n/g, "\r\n"), "utf8");
  }
  throw error;
}

write(extractionRel, extraction);
write(boqRel, boq);
console.log("PASS: exact pinned-main UI transforms applied.");
