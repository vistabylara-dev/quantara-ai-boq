const fs = require("fs");
const path = require("path");

const wt = process.argv[2];
if (!wt) throw new Error("worktree path required");

function read(rel) {
  return fs.readFileSync(path.join(wt, rel), "utf8").replace(/\r\n/g, "\n");
}
function write(rel, text) {
  fs.writeFileSync(path.join(wt, rel), text.replace(/\n/g, "\r\n"), "utf8");
}
function replaceOnce(text, before, after, label) {
  const count = text.split(before).length - 1;
  if (count !== 1) {
    throw new Error(`${label}: expected exact anchor once, found ${count}.`);
  }
  return text.replace(before, after);
}

const helperRel = "src/lib/guidance/ai-draft-boq.ts";
const serviceRel = "src/lib/services/ai-draft-boq-service.ts";
const testRel = "tests/ai-draft-boq-workflow.test.ts";

let helper = read(helperRel);
let service = read(serviceRel);
let test = read(testRel);

helper = replaceOnce(
  helper,
`export function isAiDraftCandidateUsable(entity: AiDraftCandidate): boolean {`,
`export function getAiDraftExtractedEntityId(
  sourceReference: string | null | undefined,
): string | null {
  const match = sourceReference?.match(
    /EXTRACTED_ENTITY:([0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})/i,
  );
  return match?.[1] ?? null;
}

export function isAiDraftCandidateUsable(entity: AiDraftCandidate): boolean {`,
  "add AI Draft extraction marker parser",
);

service = replaceOnce(
  service,
`  chooseAiDraftSection,
  formatAiDraftCategory,
  isAiDraftCandidateUsable,`,
`  chooseAiDraftSection,
  formatAiDraftCategory,
  getAiDraftExtractedEntityId,
  isAiDraftCandidateUsable,`,
  "import extraction marker parser",
);

service = replaceOnce(
  service,
`    const alreadyPresentIds = new Set(
      currentItems
        .map((item) => item.quantityProvenance?.extractedEntityId)
        .filter((value): value is string => Boolean(value)),
    );`,
`    const alreadyPresentIds = new Set(
      currentItems
        .map((item) =>
          item.quantityProvenance?.extractedEntityId
          ?? getAiDraftExtractedEntityId(item.sourceReference),
        )
        .filter((value): value is string => Boolean(value)),
    );`,
  "prevent AI Draft duplicates after BOQ edits",
);

const oldConfirm = `export async function confirmAiDraftQuantities(actor: CurrentActor, boqId: string) {
  requireCapability(actor, "verification:manage");

  return prisma.$transaction(async (tx) => {
    const current = await getBOQRecord(actor.companyId, boqId, tx);
    assertAiDraftEditable(current);

    const pendingItems = current.sections
      .flatMap((section) => section.items)
      .filter((item) =>
        item.quantityProvenance?.sourceType === QuantityProvenanceSource.LEGACY_UNVERIFIED
        && Boolean(item.quantityProvenance.extractedEntityId),
      );

    if (pendingItems.length === 0) {
      return { confirmedCount: 0, skippedCount: 0, remainingCount: 0 };
    }

    const entityIds = pendingItems
      .map((item) => item.quantityProvenance?.extractedEntityId)
      .filter((value): value is string => Boolean(value));

    const entities = await tx.extractedEntity.findMany({
      where: {
        id: { in: entityIds },
        companyId: actor.companyId,
        projectId: current.projectId,
      },
    });
    const entityById = new Map(entities.map((entity) => [entity.id, entity]));

    const now = new Date();
    let confirmedCount = 0;
    let skippedCount = 0;

    for (const item of pendingItems) {
      const provenance = item.quantityProvenance;
      const entityId = provenance?.extractedEntityId;
      const entity = entityId ? entityById.get(entityId) : null;

      if (
        !provenance
        || !entity
        || entity.quantity === null
        || !entity.quantity.equals(item.quantity)
        || (entity.unit ?? "").trim() !== item.unit.trim()
      ) {
        skippedCount += 1;
        continue;
      }

      if (REVIEWABLE_ENTITY_STATUSES.has(entity.status)) {
        const claimedEntity = await tx.extractedEntity.updateMany({
          where: {
            id: entity.id,
            companyId: actor.companyId,
            projectId: current.projectId,
            status: { in: ["EXTRACTED", "NEEDS_REVIEW"] },
          },
          data: {
            status: "IMPORTED",
            confirmedByUserId: actor.userId,
            confirmedAt: now,
          },
        });
        if (claimedEntity.count !== 1) {
          throw new ConflictError(
            "AI_DRAFT_ENTITY_CONFIRMATION_CONFLICT",
            "An extracted item changed while AI Draft quantities were being confirmed. Reload and try again.",
          );
        }

        await createAuditLog(actor.companyId, {
          entityType: "ExtractedEntity",
          entityId: entity.id,
          action: "ENTITY_CONFIRMED",
          actorName: actor.fullName,
          payload: { source: "AI_DRAFT_BOQ_REVIEW" },
        }, tx);
        await createAuditLog(actor.companyId, {
          entityType: "ExtractedEntity",
          entityId: entity.id,
          action: "ENTITY_IMPORTED_TO_BOQ",
          actorName: actor.fullName,
          payload: { boqId: current.id, source: "AI_DRAFT" },
        }, tx);
      } else if (entity.status === "CONFIRMED" || entity.status === "CORRECTED") {
        const imported = await tx.extractedEntity.updateMany({
          where: {
            id: entity.id,
            companyId: actor.companyId,
            projectId: current.projectId,
            status: { in: ["CONFIRMED", "CORRECTED"] },
          },
          data: { status: "IMPORTED" },
        });
        if (imported.count !== 1) {
          throw new ConflictError(
            "AI_DRAFT_ENTITY_IMPORT_CONFLICT",
            "A reviewed extraction changed while AI Draft quantities were being confirmed. Reload and try again.",
          );
        }

        await createAuditLog(actor.companyId, {
          entityType: "ExtractedEntity",
          entityId: entity.id,
          action: "ENTITY_IMPORTED_TO_BOQ",
          actorName: actor.fullName,
          payload: { boqId: current.id, source: "AI_DRAFT" },
        }, tx);
      } else if (!REVIEWED_ENTITY_STATUSES.has(entity.status)) {
        skippedCount += 1;
        continue;
      }

      const claimedProvenance = await tx.bOQItemQuantityProvenance.updateMany({
        where: {
          id: provenance.id,
          companyId: actor.companyId,
          boqItemId: item.id,
          sourceType: QuantityProvenanceSource.LEGACY_UNVERIFIED,
        },
        data: {
          sourceType: QuantityProvenanceSource.REVIEWED_EXTRACTION,
          quantitySnapshot: item.quantity,
          unitSnapshot: item.unit,
          confirmedByUserId: actor.userId,
          confirmedByName: actor.fullName,
          confirmedAt: now,
        },
      });

      if (claimedProvenance.count !== 1) {
        throw new ConflictError(
          "AI_DRAFT_CONFIRMATION_CONFLICT",
          "The AI Draft changed while quantities were being confirmed. Reload and try again.",
        );
      }

      confirmedCount += 1;
    }

    await createAuditLog(actor.companyId, {
      entityType: "BOQ",
      entityId: current.id,
      action: "AI_DRAFT_QUANTITIES_CONFIRMED",
      actorName: actor.fullName,
      payload: {
        confirmedCount,
        skippedCount,
        remainingCount: pendingItems.length - confirmedCount,
      },
    }, tx);

    return {
      confirmedCount,
      skippedCount,
      remainingCount: pendingItems.length - confirmedCount,
    };
  }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
}`;

const newConfirm = `export async function confirmAiDraftQuantities(actor: CurrentActor, boqId: string) {
  requireCapability(actor, "verification:manage");

  return prisma.$transaction(async (tx) => {
    const current = await getBOQRecord(actor.companyId, boqId, tx);
    assertAiDraftEditable(current);

    const linkedItems = current.sections
      .flatMap((section) => section.items)
      .flatMap((item) => {
        const provenance = item.quantityProvenance;
        const extractedEntityId =
          provenance?.extractedEntityId
          ?? getAiDraftExtractedEntityId(item.sourceReference);

        if (!provenance || !extractedEntityId) return [];

        const unreviewedAiQuantity =
          provenance.sourceType === QuantityProvenanceSource.LEGACY_UNVERIFIED;
        const manuallyReviewedAiQuantity =
          provenance.sourceType === QuantityProvenanceSource.MANUAL_CONFIRMED
          && provenance.confirmedAt !== null
          && getAiDraftExtractedEntityId(item.sourceReference) !== null;

        if (!unreviewedAiQuantity && !manuallyReviewedAiQuantity) return [];

        return [{
          item,
          provenance,
          extractedEntityId,
          manuallyReviewedAiQuantity,
        }];
      });

    if (linkedItems.length === 0) {
      return { confirmedCount: 0, skippedCount: 0, remainingCount: 0 };
    }

    const entityIds = linkedItems.map((entry) => entry.extractedEntityId);

    const entities = await tx.extractedEntity.findMany({
      where: {
        id: { in: entityIds },
        companyId: actor.companyId,
        projectId: current.projectId,
      },
    });
    const entityById = new Map(entities.map((entity) => [entity.id, entity]));

    const now = new Date();
    let confirmedCount = 0;
    let skippedCount = 0;

    for (const {
      item,
      provenance,
      extractedEntityId,
      manuallyReviewedAiQuantity,
    } of linkedItems) {
      const entity = entityById.get(extractedEntityId);

      if (!entity) {
        skippedCount += 1;
        continue;
      }

      if (entity.status === "IMPORTED") {
        confirmedCount += 1;
        continue;
      }

      const quantityMatchesExtraction =
        entity.quantity !== null
        && entity.quantity.equals(item.quantity)
        && (entity.unit ?? "").trim() === item.unit.trim();

      if (!manuallyReviewedAiQuantity && !quantityMatchesExtraction) {
        skippedCount += 1;
        continue;
      }

      const extractionWasCorrectedInBoq =
        manuallyReviewedAiQuantity && !quantityMatchesExtraction;

      if (REVIEWABLE_ENTITY_STATUSES.has(entity.status)) {
        const original = {
          label: entity.label,
          quantity: entity.quantity?.toNumber() ?? null,
          unit: entity.unit,
        };

        const claimedEntity = await tx.extractedEntity.updateMany({
          where: {
            id: entity.id,
            companyId: actor.companyId,
            projectId: current.projectId,
            status: { in: ["EXTRACTED", "NEEDS_REVIEW"] },
          },
          data: {
            status: "IMPORTED",
            ...(extractionWasCorrectedInBoq
              ? {
                  quantity: item.quantity,
                  unit: item.unit,
                  correctionJson: {
                    original,
                    corrected: {
                      quantity: item.quantity.toNumber(),
                      unit: item.unit,
                    },
                    correctedByUserId: actor.userId,
                    correctedAt: now.toISOString(),
                    reason: "Corrected during AI Draft BOQ review.",
                  },
                }
              : {}),
            confirmedByUserId: actor.userId,
            confirmedAt: now,
          },
        });

        if (claimedEntity.count !== 1) {
          throw new ConflictError(
            "AI_DRAFT_ENTITY_CONFIRMATION_CONFLICT",
            "An extracted item changed while AI Draft quantities were being confirmed. Reload and try again.",
          );
        }

        await createAuditLog(actor.companyId, {
          entityType: "ExtractedEntity",
          entityId: entity.id,
          action: extractionWasCorrectedInBoq ? "ENTITY_CORRECTED" : "ENTITY_CONFIRMED",
          actorName: actor.fullName,
          payload: extractionWasCorrectedInBoq
            ? {
                original,
                corrected: {
                  quantity: item.quantity.toNumber(),
                  unit: item.unit,
                },
                reason: "Corrected during AI Draft BOQ review.",
              }
            : { source: "AI_DRAFT_BOQ_REVIEW" },
        }, tx);

        await createAuditLog(actor.companyId, {
          entityType: "ExtractedEntity",
          entityId: entity.id,
          action: "ENTITY_IMPORTED_TO_BOQ",
          actorName: actor.fullName,
          payload: { boqId: current.id, source: "AI_DRAFT" },
        }, tx);
      } else if (entity.status === "CONFIRMED" || entity.status === "CORRECTED") {
        const imported = await tx.extractedEntity.updateMany({
          where: {
            id: entity.id,
            companyId: actor.companyId,
            projectId: current.projectId,
            status: { in: ["CONFIRMED", "CORRECTED"] },
          },
          data: { status: "IMPORTED" },
        });

        if (imported.count !== 1) {
          throw new ConflictError(
            "AI_DRAFT_ENTITY_IMPORT_CONFLICT",
            "A reviewed extraction changed while AI Draft quantities were being confirmed. Reload and try again.",
          );
        }

        await createAuditLog(actor.companyId, {
          entityType: "ExtractedEntity",
          entityId: entity.id,
          action: "ENTITY_IMPORTED_TO_BOQ",
          actorName: actor.fullName,
          payload: { boqId: current.id, source: "AI_DRAFT" },
        }, tx);
      } else if (!REVIEWED_ENTITY_STATUSES.has(entity.status)) {
        skippedCount += 1;
        continue;
      }

      if (provenance.sourceType === QuantityProvenanceSource.LEGACY_UNVERIFIED) {
        const claimedProvenance = await tx.bOQItemQuantityProvenance.updateMany({
          where: {
            id: provenance.id,
            companyId: actor.companyId,
            boqItemId: item.id,
            sourceType: QuantityProvenanceSource.LEGACY_UNVERIFIED,
          },
          data: {
            sourceType: QuantityProvenanceSource.REVIEWED_EXTRACTION,
            quantitySnapshot: item.quantity,
            unitSnapshot: item.unit,
            confirmedByUserId: actor.userId,
            confirmedByName: actor.fullName,
            confirmedAt: now,
          },
        });

        if (claimedProvenance.count !== 1) {
          throw new ConflictError(
            "AI_DRAFT_CONFIRMATION_CONFLICT",
            "The AI Draft changed while quantities were being confirmed. Reload and try again.",
          );
        }
      }

      confirmedCount += 1;
    }

    await createAuditLog(actor.companyId, {
      entityType: "BOQ",
      entityId: current.id,
      action: "AI_DRAFT_QUANTITIES_CONFIRMED",
      actorName: actor.fullName,
      payload: {
        confirmedCount,
        skippedCount,
        remainingCount: linkedItems.length - confirmedCount,
      },
    }, tx);

    return {
      confirmedCount,
      skippedCount,
      remainingCount: linkedItems.length - confirmedCount,
    };
  }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
}`;

service = replaceOnce(
  service,
  oldConfirm,
  newConfirm,
  "replace AI Draft quantity confirmation flow",
);

test = replaceOnce(
  test,
`  chooseAiDraftSection,
  formatAiDraftCategory,
  isAiDraftCandidateUsable,`,
`  chooseAiDraftSection,
  formatAiDraftCategory,
  getAiDraftExtractedEntityId,
  isAiDraftCandidateUsable,`,
  "test parser import",
);

test = replaceOnce(
  test,
`  it("uses a matching project BOQ section", () => {`,
`  it("keeps the extraction link recoverable after BOQ quantity provenance becomes manual", () => {
    const entityId = "123e4567-e89b-42d3-a456-426614174000";

    expect(getAiDraftExtractedEntityId(
      \`DWG-A12 | EXTRACTED_ENTITY:\${entityId}\`,
    )).toBe(entityId);

    expect(getAiDraftExtractedEntityId("DWG-A12")).toBeNull();
  });

  it("uses a matching project BOQ section", () => {`,
  "add extraction marker parser test",
);

write(helperRel, helper);
write(serviceRel, service);
write(testRel, test);
console.log("PASS: Phase 2B review fix applied to exactly 3 files.");
