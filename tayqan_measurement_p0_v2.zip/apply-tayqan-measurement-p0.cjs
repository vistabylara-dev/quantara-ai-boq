const fs = require("node:fs");
const path = require("node:path");

const root = process.argv[2];
const packageDir = process.argv[3] || __dirname;
if (!root) throw new Error("Usage: node apply-tayqan-measurement-p0.cjs <worktree> [packageDir]");

function target(relative) {
  return path.join(root, ...relative.split("/"));
}

function read(relative) {
  return fs.readFileSync(target(relative), "utf8");
}

function write(relative, content) {
  const file = target(relative);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, content, "utf8");
}

function replaceOnce(content, needle, replacement, label) {
  const first = content.indexOf(needle);
  if (first < 0) throw new Error(`Patch anchor not found: ${label}`);
  if (content.indexOf(needle, first + needle.length) >= 0) {
    throw new Error(`Patch anchor is not unique: ${label}`);
  }
  return content.slice(0, first) + replacement + content.slice(first + needle.length);
}

const newFiles = [
  ["tayqan-measurement-contract.ts", "src/lib/tayqan/tayqan-measurement-contract.ts"],
  ["tayqan-measurement-reasoner.ts", "src/lib/tayqan/tayqan-measurement-reasoner.ts"],
  ["openai-tayqan-measurement-reasoner.ts", "src/lib/tayqan/openai-tayqan-measurement-reasoner.ts"],
  ["tayqan-measurement-service.ts", "src/lib/services/tayqan-measurement-service.ts"],
  ["tayqan-measurement-contract.test.ts", "tests/tayqan-measurement-contract.test.ts"],
];

for (const [sourceName, relativeTarget] of newFiles) {
  const destination = target(relativeTarget);
  if (fs.existsSync(destination)) {
    throw new Error(`Refusing to overwrite existing file: ${relativeTarget}`);
  }
  write(relativeTarget, fs.readFileSync(path.join(packageDir, sourceName), "utf8"));
}

let draft = read("src/lib/services/ai-draft-boq-service.ts");
draft = replaceOnce(
  draft,
  'import { getProjectRecord } from "@/lib/repositories/project-repository";\n',
  'import { getProjectRecord } from "@/lib/repositories/project-repository";\nimport { TAYQAN_MEASUREMENT_CALCULATED_BY_PREFIX } from "@/lib/tayqan/tayqan-measurement-contract";\n',
  "AI Draft measurement import",
);

draft = replaceOnce(
  draft,
  `export type AiDraftGenerationOptions = {\n  targetBoqId?: string;\n  projectFileIds?: readonly string[];\n};`,
  `export type AiDraftGenerationOptions = {\n  targetBoqId?: string;\n  projectFileIds?: readonly string[];\n  /** Default preserves the existing self-service AI Draft behavior. TAYQAN opts in explicitly. */\n  quantityMode?: "EXTRACTION_ONLY" | "TAYQAN_MEASUREMENT_PROPOSAL";\n};`,
  "AI Draft options",
);

draft = replaceOnce(
  draft,
  `    const candidates = rows.map(toCandidate);\n    const summary = summarizeAiDraftCandidates(candidates);`,
  `    const tayqanMeasurements = options.quantityMode === "TAYQAN_MEASUREMENT_PROPOSAL"\n      && rows.length > 0\n      ? await tx.quantityCalculation.findMany({\n          where: {\n            companyId: actor.companyId,\n            projectId: project.id,\n            extractedEntityId: { in: rows.map((row) => row.id) },\n            calculatedBy: { startsWith: TAYQAN_MEASUREMENT_CALCULATED_BY_PREFIX },\n            status: { not: "REJECTED" },\n          },\n          orderBy: { updatedAt: "desc" },\n        })\n      : [];\n\n    const tayqanMeasurementByEntityId = new Map<string, (typeof tayqanMeasurements)[number]>();\n    for (const measurement of tayqanMeasurements) {\n      if (measurement.extractedEntityId && !tayqanMeasurementByEntityId.has(measurement.extractedEntityId)) {\n        tayqanMeasurementByEntityId.set(measurement.extractedEntityId, measurement);\n      }\n    }\n\n    const rowsForDraft = rows.map((row) => {\n      const measurement = tayqanMeasurementByEntityId.get(row.id);\n      if (!measurement) return row;\n      return {\n        ...row,\n        quantity: measurement.resultValue,\n        unit: measurement.resultUnit,\n        confidence: new Prisma.Decimal(Math.min(\n          row.confidence.toNumber(),\n          measurement.confidence.toNumber(),\n        )),\n      };\n    });\n\n    const candidates = rowsForDraft.map(toCandidate);\n    const summary = summarizeAiDraftCandidates(candidates);`,
  "AI Draft measurement proposal selection",
);

draft = replaceOnce(
  draft,
  `    const toAdd = rows\n      .map((row) => ({ row, candidate: toCandidate(row) }))`,
  `    const toAdd = rowsForDraft\n      .map((row) => ({ row, candidate: toCandidate(row) }))`,
  "AI Draft measured rows",
);

draft = replaceOnce(
  draft,
  `    for (const { row, candidate } of toAdd) {\n      const matchedSectionId = chooseAiDraftSection(businessSections, candidate);`,
  `    for (const { row, candidate } of toAdd) {\n      const tayqanMeasurement = tayqanMeasurementByEntityId.get(row.id) ?? null;\n      const matchedSectionId = chooseAiDraftSection(businessSections, candidate);`,
  "AI Draft loop measurement lookup",
);

draft = replaceOnce(
  draft,
  `          notes: measurementComplete\n            ? "AI Draft from extracted project evidence. Professional quantity review and commercial rate selection are still required."\n            : "AI Draft from extracted project evidence. Quantity and/or unit is unresolved and must be completed in the BOQ before validation.",`,
  `          notes: tayqanMeasurement\n            ? "TAYQAN measured this draft quantity from project drawing evidence using the deterministic quantity engine. Professional review is still required; unit price is intentionally left for the engineer."\n            : measurementComplete\n              ? "AI Draft from extracted project evidence. Professional quantity review and commercial rate selection are still required."\n              : "AI Draft from extracted project evidence. Quantity and/or unit is unresolved and must be completed in the BOQ before validation.",`,
  "AI Draft TAYQAN notes",
);

draft = replaceOnce(
  draft,
  `      const previouslyReviewed = (\n        measurementComplete\n        && (row.status === "CONFIRMED" || row.status === "CORRECTED")\n        && row.confirmedAt !== null\n      );`,
  `      const tayqanMeasurementConfirmed = Boolean(\n        tayqanMeasurement\n        && tayqanMeasurement.status === "CONFIRMED"\n        && tayqanMeasurement.confirmedAt !== null\n      );\n      const previouslyReviewed = (\n        !tayqanMeasurement\n        && measurementComplete\n        && (row.status === "CONFIRMED" || row.status === "CORRECTED")\n        && row.confirmedAt !== null\n      );`,
  "AI Draft prevent fake confirmation",
);

draft = replaceOnce(
  draft,
  `          extractedEntityId: row.id,\n          projectFileId: row.projectFileId,\n          quantitySnapshot: quantity,`,
  `          extractedEntityId: row.id,\n          quantityCalculationId: tayqanMeasurement?.id ?? null,\n          projectFileId: row.projectFileId,\n          quantitySnapshot: quantity,`,
  "AI Draft calculation provenance",
);

draft = replaceOnce(
  draft,
  `          sourceType: previouslyReviewed\n            ? QuantityProvenanceSource.REVIEWED_EXTRACTION\n            : QuantityProvenanceSource.LEGACY_UNVERIFIED,`,
  `          sourceType: tayqanMeasurementConfirmed\n            ? QuantityProvenanceSource.CONFIRMED_CALCULATION\n            : previouslyReviewed\n              ? QuantityProvenanceSource.REVIEWED_EXTRACTION\n              : QuantityProvenanceSource.LEGACY_UNVERIFIED,`,
  "AI Draft confirmed TAYQAN source type",
);

draft = replaceOnce(
  draft,
  `          confirmedByUserId: previouslyReviewed ? row.confirmedByUserId : null,`,
  `          confirmedByUserId: tayqanMeasurementConfirmed\n            ? tayqanMeasurement?.confirmedByUserId ?? null\n            : previouslyReviewed\n              ? row.confirmedByUserId\n              : null,`,
  "AI Draft TAYQAN confirmer",
);

draft = replaceOnce(
  draft,
  `          confirmedByName: previouslyReviewed\n            ? "Previously reviewed extraction"\n            : "AI draft - professional review pending",`,
  `          confirmedByName: tayqanMeasurementConfirmed\n            ? "Confirmed TAYQAN calculation"\n            : previouslyReviewed\n              ? "Previously reviewed extraction"\n              : tayqanMeasurement\n                ? "TAYQAN measurement - professional review pending"\n                : "AI draft - professional review pending",`,
  "AI Draft TAYQAN provenance label",
);

draft = replaceOnce(
  draft,
  `          confirmedAt: previouslyReviewed ? row.confirmedAt : null,`,
  `          confirmedAt: tayqanMeasurementConfirmed\n            ? tayqanMeasurement?.confirmedAt ?? null\n            : previouslyReviewed\n              ? row.confirmedAt\n              : null,`,
  "AI Draft TAYQAN confirmedAt",
);

draft = replaceOnce(
  draft,
  `          rateAutomaticallyApplied: false,`,
  `          rateAutomaticallyApplied: false,\n          tayqanMeasurementCalculationId: tayqanMeasurement?.id ?? null,`,
  "AI Draft audit measurement id",
);
write("src/lib/services/ai-draft-boq-service.ts", draft);

let workOrder = read("src/lib/services/tayqan-work-order-service.ts");
workOrder = replaceOnce(
  workOrder,
  'import { generateAiDraftBoq } from "@/lib/services/ai-draft-boq-service";\n',
  'import { generateAiDraftBoq } from "@/lib/services/ai-draft-boq-service";\nimport { prepareTayqanMeasurementProposals } from "@/lib/services/tayqan-measurement-service";\n',
  "TAYQAN measurement service import",
);

workOrder = replaceOnce(
  workOrder,
  `  aiDraft?: {\n    boqId: string;\n    addedCount: number;\n    skippedCount: number;\n    alreadyPresentCount: number;\n    unreviewedAddedCount: number;\n    reviewedAddedCount: number;\n  };`,
  `  aiDraft?: {\n    boqId: string;\n    addedCount: number;\n    skippedCount: number;\n    alreadyPresentCount: number;\n    unreviewedAddedCount: number;\n    reviewedAddedCount: number;\n  };\n\n  /** Additive TAYQAN measurement checkpoint; stored in existing progressJson, never schema. */\n  tayqanMeasurement?: {\n    measuredSubjectCount: number;\n    createdCalculationCount: number;\n    reusedCalculationCount: number;\n    exceptionCount: number;\n    provider: string;\n    model: string;\n  };`,
  "TAYQAN WorkProgress measurement summary",
);

workOrder = replaceOnce(
  workOrder,
  `  if (usesDraftFirstWorkflow(order)) {\n    return prepareTayqanAiDraft(\n      actor,\n      projectSlug,\n      order,\n    );\n  }`,
  `  if (usesDraftFirstWorkflow(order)) {\n    let measuredOrder = order;\n    const progress = parseProgress(order.progressJson);\n\n    if (!progress.tayqanMeasurement) {\n      const measurement = await prepareTayqanMeasurementProposals(\n        actor,\n        projectSlug,\n        {\n          projectId: order.projectId,\n          sourceFileIds: sourceFileIdsFromProgress(order),\n        },\n      );\n\n      await updateOrder(\n        actor,\n        order.id,\n        {\n          progressJson: jsonObject({\n            ...progress,\n            tayqanMeasurement: {\n              measuredSubjectCount: measurement.measuredSubjectCount,\n              createdCalculationCount: measurement.createdCalculationCount,\n              reusedCalculationCount: measurement.reusedCalculationCount,\n              exceptionCount: measurement.exceptionCount,\n              provider: measurement.provider,\n              model: measurement.model,\n            },\n          }),\n          lastAdvancedAt: new Date(),\n        },\n        "TAYQAN_MEASUREMENT_COMPLETE",\n        {\n          measuredSubjectCount: measurement.measuredSubjectCount,\n          createdCalculationCount: measurement.createdCalculationCount,\n          reusedCalculationCount: measurement.reusedCalculationCount,\n          exceptionCount: measurement.exceptionCount,\n        },\n      );\n\n      await persistConversationStatus(\n        actor.companyId,\n        order.intakeSessionId,\n        "tayqan.hire.workflow.measurementComplete",\n        { count: measurement.measuredSubjectCount },\n      );\n\n      measuredOrder = await loadOrder(actor.companyId, order.id);\n    }\n\n    return prepareTayqanAiDraft(\n      actor,\n      projectSlug,\n      measuredOrder,\n    );\n  }`,
  "TAYQAN source processing measurement bridge",
);

workOrder = replaceOnce(
  workOrder,
  `        targetBoqId: boqId,\n        projectFileIds: selectedSourceFileIds,`,
  `        targetBoqId: boqId,\n        projectFileIds: selectedSourceFileIds,\n        quantityMode: "TAYQAN_MEASUREMENT_PROPOSAL",`,
  "TAYQAN AI Draft quantity mode",
);
write("src/lib/services/tayqan-work-order-service.ts", workOrder);

// i18n: add one status key in both dictionaries. We deliberately preserve all existing wording/keys.
for (const dictionary of ["src/lib/i18n/dictionaries/en.ts", "src/lib/i18n/dictionaries/ar.ts"]) {
  let text = read(dictionary);
  const isArabic = dictionary.endsWith("ar.ts");
  const anchor = isArabic
    ? '        sourceProcessing: "أعالج {count} من مهام المصادر المتبقية، وسأعيد استخدام أي معالجة مكتملة بدل إنشائها مرة أخرى.",'
    : '        sourceProcessing: "I’m processing {count} remaining source task(s). I will reuse any completed processing rather than create it again.",';
  const inserted = isArabic
    ? `${anchor}\n        measurementComplete: "اكتملت قياسات TAYQAN المستندة إلى أدلة الرسومات لعدد {count} من بنود النطاق القابلة للقياس. أقوم الآن بتجميع مسودة جدول الكميات، وتبقى أسعار الوحدات للإدخال والمراجعة المهنية.",`
    : `${anchor}\n        measurementComplete: "TAYQAN completed evidence-backed drawing measurements for {count} measurable scope item(s). I am assembling the Draft BOQ now; unit prices remain for professional input.",`;
  text = replaceOnce(text, anchor, inserted, `${dictionary} measurementComplete i18n`);
  write(dictionary, text);
}

console.log("TAYQAN measurement P0 patch applied successfully.");
