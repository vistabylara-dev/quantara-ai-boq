param(
    [string]$Repo = "$env:USERPROFILE\Desktop\quantara-ai-boq",
    [string]$Worktree = "$env:USERPROFILE\Desktop\quantara-ai-boq\.worktrees\tayqan-measurement-p0-20260817"
)

$ErrorActionPreference = "Stop"
$ExpectedBase = "50de95e451bc8874de99e6973d571b2567888ea6"
$Branch = "feat/tayqan-measurement-intelligence-p0-20260817"
$PackageDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "=== TAYQAN MEASUREMENT P0 — PROTECTED INSTALL ===" -ForegroundColor Cyan

if (-not (Test-Path (Join-Path $Repo ".git"))) {
    throw "STOP: Repo not found at $Repo"
}

Set-Location $Repo

git fetch origin main
if ($LASTEXITCODE -ne 0) { throw "STOP: git fetch failed." }

$originMain = (git rev-parse origin/main).Trim()
if ($originMain -ne $ExpectedBase) {
    throw "STOP: origin/main moved. Expected $ExpectedBase but found $originMain. Do not apply an old patch to a new baseline."
}

if (Test-Path $Worktree) {
    throw "STOP: Target worktree already exists: $Worktree. Nothing was changed."
}

Write-Host "Creating isolated worktree at exact audited base..." -ForegroundColor Yellow
git worktree add -b $Branch $Worktree $ExpectedBase
if ($LASTEXITCODE -ne 0) { throw "STOP: Could not create isolated worktree." }

Set-Location $Worktree

$protectedPatterns = @(
    '^prisma/',
    '^src/lib/services/stripe-',
    '^src/app/api/commerce/',
    '^src/app/api/webhooks/stripe/',
    '^src/lib/services/refund-',
    '^src/lib/entitlements/',
    '^src/lib/services/catalogue-',
    '^src/lib/services/industry-package-',
    '^src/app/api/admin/system-health/schema-recovery/'
)

Write-Host "Applying additive TAYQAN measurement files + surgical wiring..." -ForegroundColor Yellow
node (Join-Path $PackageDir "apply-tayqan-measurement-p0.cjs") $Worktree $PackageDir
if ($LASTEXITCODE -ne 0) { throw "STOP: patch application failed." }

Write-Host "`n=== FILE SCOPE AUDIT ===" -ForegroundColor Cyan
$changed = @(git diff --name-only)
$changed | ForEach-Object { Write-Host $_ }

foreach ($file in $changed) {
    foreach ($pattern in $protectedPatterns) {
        if ($file -match $pattern) {
            throw "STOP: Protected file changed: $file"
        }
    }
}

$forbidden = @(
    'prisma/schema.prisma',
    'package.json',
    'package-lock.json'
)
foreach ($file in $forbidden) {
    if ($changed -contains $file) { throw "STOP: Forbidden file changed: $file" }
}

Write-Host "`n=== DIFF CHECK ===" -ForegroundColor Cyan
git diff --check
if ($LASTEXITCODE -ne 0) { throw "STOP: git diff --check failed." }

$rootNodeModules = Join-Path $Repo "node_modules"
$vitest = Join-Path $rootNodeModules ".bin\vitest.cmd"
$tsc = Join-Path $rootNodeModules ".bin\tsc.cmd"
$eslint = Join-Path $rootNodeModules ".bin\eslint.cmd"

if (Test-Path $vitest) {
    Write-Host "`n=== FOCUSED PURE TEST — ZERO OPENAI CALLS ===" -ForegroundColor Cyan
    & $vitest run tests/tayqan-measurement-contract.test.ts
    if ($LASTEXITCODE -ne 0) { throw "STOP: TAYQAN measurement contract test failed." }
} else {
    Write-Host "Vitest binary not found in root node_modules; skipped, not reported as PASS." -ForegroundColor Yellow
}

if (Test-Path $tsc) {
    Write-Host "`n=== TYPESCRIPT ===" -ForegroundColor Cyan
    & $tsc --noEmit -p (Join-Path $Worktree "tsconfig.json")
    if ($LASTEXITCODE -ne 0) { throw "STOP: TypeScript failed. Do not commit." }
} else {
    Write-Host "TypeScript binary not found in root node_modules; skipped, not reported as PASS." -ForegroundColor Yellow
}

if (Test-Path $eslint) {
    Write-Host "`n=== FOCUSED ESLINT ===" -ForegroundColor Cyan
    & $eslint `
      src/lib/tayqan/tayqan-measurement-contract.ts `
      src/lib/tayqan/tayqan-measurement-reasoner.ts `
      src/lib/tayqan/openai-tayqan-measurement-reasoner.ts `
      src/lib/services/tayqan-measurement-service.ts `
      src/lib/services/ai-draft-boq-service.ts `
      src/lib/services/tayqan-work-order-service.ts `
      tests/tayqan-measurement-contract.test.ts `
      --max-warnings=0
    if ($LASTEXITCODE -ne 0) { throw "STOP: focused ESLint failed. Do not commit." }
} else {
    Write-Host "ESLint binary not found in root node_modules; skipped, not reported as PASS." -ForegroundColor Yellow
}

Write-Host "`n=== FINAL STATUS ===" -ForegroundColor Cyan
git status --short
Write-Host "`nPatch is isolated and NOT committed, NOT pushed, NOT merged, NOT deployed." -ForegroundColor Green
Write-Host "Worktree: $Worktree" -ForegroundColor Green
Write-Host "Branch:   $Branch" -ForegroundColor Green
