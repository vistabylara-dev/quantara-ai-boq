import { describe, expect, it } from "vitest";
import { ExtractedEntityType, QuantityCalculationType } from "@prisma/client";
import {
  evaluateTayqanMeasurementSubject,
  normalizeTayqanMeasurementValue,
} from "../src/lib/tayqan/tayqan-measurement-contract";
import {
  buildTayqanMeasurementClusters,
  classifyTayqanDrawingPageRole,
  type TayqanMeasurementPageEvidence,
} from "../src/lib/tayqan/tayqan-measurement-reasoner";

const PAGE_PLAN = "11111111-1111-4111-8111-111111111111";
const PAGE_SECTION = "22222222-2222-4222-8222-222222222222";
const PAGE_SCHEDULE = "33333333-3333-4333-8333-333333333333";

function page(overrides: Partial<TayqanMeasurementPageEvidence>): TayqanMeasurementPageEvidence {
  return {
    id: PAGE_PLAN,
    projectFileId: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
    originalName: "A-101.pdf",
    pageNumber: 1,
    drawingNumber: "A-101",
    drawingTitle: "Floor Plan",
    revisionNumber: "P01",
    discipline: "Architectural",
    drawingType: "Plan",
    sheetName: null,
    role: "PLAN",
    width: 2000,
    height: 1400,
    dpi: 144,
    text: null,
    drawingTitles: [],
    technicalLines: [],
    detectedScale: "1:100",
    scaleVerified: false,
    scaleRatio: null,
    drawingUnit: null,
    realWorldUnit: null,
    hasImage: true,
    ...overrides,
  };
}

describe("TAYQAN measurement contract", () => {
  it("normalizes engineering units without guessing", () => {
    expect(normalizeTayqanMeasurementValue(6200, "mm", "m")).toBeCloseTo(6.2);
    expect(normalizeTayqanMeasurementValue(286000000, "mm2", "m2")).toBeCloseTo(286);
    expect(normalizeTayqanMeasurementValue(1.5, "t", "kg")).toBe(1500);
    expect(() => normalizeTayqanMeasurementValue(12, null, "m")).toThrow(/source unit/i);
  });

  it("combines cross-page plan + section evidence and lets the deterministic registry calculate wall area", () => {
    const result = evaluateTayqanMeasurementSubject({
      existingEntityId: null,
      primaryPageId: PAGE_PLAN,
      evidencePageIds: [PAGE_PLAN, PAGE_SECTION],
      entityType: ExtractedEntityType.WALL_FINISH,
      label: "Painted gypsum wall finish",
      calculationType: QuantityCalculationType.WALL_AREA,
      inputs: [
        {
          key: "wallLength",
          value: 6200,
          unit: "mm",
          derivation: "EXPLICIT_DIMENSION",
          evidencePageIds: [PAGE_PLAN],
          evidenceRoomIds: [],
          confidence: 96,
        },
        {
          key: "wallHeight",
          value: 3000,
          unit: "mm",
          derivation: "EXPLICIT_DIMENSION",
          evidencePageIds: [PAGE_SECTION],
          evidenceRoomIds: [],
          confidence: 94,
        },
        {
          key: "openingsArea",
          value: 2.1,
          unit: "m2",
          derivation: "SCHEDULE_VALUE",
          evidencePageIds: [PAGE_SCHEDULE],
          evidenceRoomIds: [],
          confidence: 92,
        },
      ],
      rationale: "Plan supplies wall length, section supplies height, door schedule supplies opening deduction.",
      sourceSummary: "A-101 + A-301 + D-601",
      confidence: 95,
    }, {
      allowedEntityIds: new Set(),
      allowedRoomIds: new Set(),
      pagesById: new Map([
        [PAGE_PLAN, { projectFileId: "f1", scaleVerified: false }],
        [PAGE_SECTION, { projectFileId: "f2", scaleVerified: false }],
        [PAGE_SCHEDULE, { projectFileId: "f3", scaleVerified: false }],
      ]),
    });

    expect(result.normalizedInputValues.wallLength).toBeCloseTo(6.2);
    expect(result.normalizedInputValues.wallHeight).toBeCloseTo(3);
    expect(result.resultUnit).toBe("m2");
    expect(result.resultValue).toBeCloseTo(16.5);
    expect(result.confidence).toBe(92);
  });

  it("refuses pixel/scaled geometry unless the cited page scale is verified", () => {
    expect(() => evaluateTayqanMeasurementSubject({
      existingEntityId: null,
      primaryPageId: PAGE_PLAN,
      evidencePageIds: [PAGE_PLAN],
      entityType: ExtractedEntityType.FLOOR_FINISH,
      label: "Floor tile",
      calculationType: QuantityCalculationType.FLOOR_AREA,
      inputs: [{
        key: "netFloorArea",
        value: 25,
        unit: "m2",
        derivation: "VERIFIED_SCALE_GEOMETRY",
        evidencePageIds: [PAGE_PLAN],
        evidenceRoomIds: [],
        confidence: 90,
      }],
      rationale: "Measured polygon from page geometry.",
      sourceSummary: "A-101",
      confidence: 90,
    }, {
      allowedEntityIds: new Set(),
      allowedRoomIds: new Set(),
      pagesById: new Map([[PAGE_PLAN, { projectFileId: "f1", scaleVerified: false }]]),
    })).toThrow(/unverified drawing scale/i);
  });

  it("never accepts rates or arbitrary formula inputs because the strict schema/formula registry owns the input contract", () => {
    expect(() => evaluateTayqanMeasurementSubject({
      existingEntityId: null,
      primaryPageId: PAGE_PLAN,
      evidencePageIds: [PAGE_PLAN],
      entityType: ExtractedEntityType.FLOOR_FINISH,
      label: "Floor tile",
      calculationType: QuantityCalculationType.FLOOR_AREA,
      inputs: [{
        key: "unitPrice",
        value: 50,
        unit: null,
        derivation: "SCHEDULE_VALUE",
        evidencePageIds: [PAGE_PLAN],
        evidenceRoomIds: [],
        confidence: 100,
      }],
      rationale: "Forbidden commercial field.",
      sourceSummary: "A-101",
      confidence: 100,
    }, {
      allowedEntityIds: new Set(),
      allowedRoomIds: new Set(),
      pagesById: new Map([[PAGE_PLAN, { projectFileId: "f1", scaleVerified: false }]]),
    })).toThrow(/unexpected input/i);
  });
});

describe("TAYQAN cross-page clusters", () => {
  it("classifies anchor pages and repeats section/schedule evidence with plan chunks", () => {
    expect(classifyTayqanDrawingPageRole({ drawingTitle: "Typical Section A-A" })).toBe("SECTION");
    expect(classifyTayqanDrawingPageRole({ drawingTitle: "Door Schedule" })).toBe("SCHEDULE");

    const pages = [
      page({ id: PAGE_PLAN, pageNumber: 1, role: "PLAN" }),
      page({ id: "44444444-4444-4444-8444-444444444444", pageNumber: 2, role: "PLAN" }),
      page({ id: PAGE_SECTION, pageNumber: 3, role: "SECTION" }),
      page({ id: PAGE_SCHEDULE, pageNumber: 4, role: "SCHEDULE" }),
    ];
    const clusters = buildTayqanMeasurementClusters(pages, 4);
    expect(clusters.length).toBeGreaterThan(0);
    expect(clusters.every((cluster) => cluster.pageIds.includes(PAGE_SECTION))).toBe(true);
    expect(clusters.every((cluster) => cluster.pageIds.includes(PAGE_SCHEDULE))).toBe(true);
    expect(new Set(clusters.flatMap((cluster) => cluster.pageIds))).toEqual(new Set(pages.map((entry) => entry.id)));
  });
});
