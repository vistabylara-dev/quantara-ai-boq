import {
  ExtractedEntityType,
  QuantityCalculationType,
} from "@prisma/client";
import { z } from "zod";
import {
  getRequiredDimensions,
  listSupportedCalculationTypes,
} from "@/lib/calculations/required-dimensions-registry";

export const TAYQAN_MEASUREMENT_VERSION = "tayqan-measurement-v1" as const;
export const TAYQAN_MEASUREMENT_CALCULATED_BY_PREFIX = `${TAYQAN_MEASUREMENT_VERSION}:`;

export const tayqanMeasurementDerivationSchema = z.enum([
  "EXPLICIT_DIMENSION",
  "SCHEDULE_VALUE",
  "COUNT_RECONCILIATION",
  "ROOM_GEOMETRY",
  "VERIFIED_SCALE_GEOMETRY",
]);

export type TayqanMeasurementDerivation = z.infer<
  typeof tayqanMeasurementDerivationSchema
>;

export const tayqanMeasurementInputSchema = z.object({
  key: z.string().trim().min(1).max(80),
  value: z.number().finite().min(0),
  unit: z.string().trim().min(1).max(24).nullable(),
  derivation: tayqanMeasurementDerivationSchema,
  evidencePageIds: z.array(z.string().uuid()).min(1).max(8),
  evidenceRoomIds: z.array(z.string().uuid()).max(8),
  confidence: z.number().finite().min(0).max(100),
}).strict();

export const tayqanMeasurementSubjectSchema = z.object({
  existingEntityId: z.string().uuid().nullable(),
  primaryPageId: z.string().uuid(),
  evidencePageIds: z.array(z.string().uuid()).min(1).max(12),
  entityType: z.nativeEnum(ExtractedEntityType),
  label: z.string().trim().min(1).max(240),
  calculationType: z.nativeEnum(QuantityCalculationType),
  inputs: z.array(tayqanMeasurementInputSchema).min(1).max(16),
  rationale: z.string().trim().min(1).max(2_000),
  sourceSummary: z.string().trim().min(1).max(2_000),
  confidence: z.number().finite().min(0).max(100),
}).strict();

export const tayqanMeasurementExceptionSchema = z.object({
  kind: z.enum([
    "INSUFFICIENT_EVIDENCE",
    "SCALE_REQUIRED",
    "AMBIGUOUS_SCOPE",
    "CROSS_PAGE_CONFLICT",
    "UNSUPPORTED_FORMULA",
  ]),
  message: z.string().trim().min(1).max(1_500),
  pageIds: z.array(z.string().uuid()).max(12),
  relatedEntityId: z.string().uuid().nullable(),
}).strict();

export const tayqanMeasurementPlanSchema = z.object({
  subjects: z.array(tayqanMeasurementSubjectSchema).max(250),
  exceptions: z.array(tayqanMeasurementExceptionSchema).max(250),
}).strict();

export type TayqanMeasurementInput = z.infer<typeof tayqanMeasurementInputSchema>;
export type TayqanMeasurementSubject = z.infer<typeof tayqanMeasurementSubjectSchema>;
export type TayqanMeasurementPlan = z.infer<typeof tayqanMeasurementPlanSchema>;
export type TayqanMeasurementException = z.infer<typeof tayqanMeasurementExceptionSchema>;

export type TayqanMeasurementPageGuard = {
  projectFileId: string;
  scaleVerified: boolean;
};

export type TayqanMeasurementEvaluationContext = {
  allowedEntityIds: ReadonlySet<string>;
  allowedRoomIds: ReadonlySet<string>;
  pagesById: ReadonlyMap<string, TayqanMeasurementPageGuard>;
};

export type EvaluatedTayqanMeasurement = {
  subject: TayqanMeasurementSubject;
  normalizedInputValues: Record<string, number>;
  formula: string;
  resultValue: number;
  resultUnit: string;
  deductions: Record<string, number> | null;
  allowances: Record<string, number> | null;
  confidence: number;
};

function canonicalUnit(value: string | null): string | null {
  if (value === null) return null;
  const normalized = value
    .trim()
    .toLowerCase()
    .replaceAll("²", "2")
    .replaceAll("³", "3")
    .replace(/\s+/g, "");

  const aliases: Record<string, string> = {
    metre: "m",
    meter: "m",
    metres: "m",
    meters: "m",
    millimetre: "mm",
    millimeter: "mm",
    millimetres: "mm",
    millimeters: "mm",
    centimetre: "cm",
    centimeter: "cm",
    centimetres: "cm",
    centimeters: "cm",
    sqm: "m2",
    "sq.m": "m2",
    sqmeter: "m2",
    sqmetre: "m2",
    "m^2": "m2",
    "mm^2": "mm2",
    "cm^2": "cm2",
    cum: "m3",
    "cu.m": "m3",
    "m^3": "m3",
    "mm^3": "mm3",
    "cm^3": "cm3",
    number: "nr",
    no: "nr",
    nos: "nr",
    count: "nr",
    ea: "nr",
    each: "nr",
    percent: "%",
    percentage: "%",
    tonne: "t",
    tonnes: "t",
    ton: "t",
    tons: "t",
  };

  return aliases[normalized] ?? normalized;
}

function convertLinear(value: number, from: string, to: string): number | null {
  const metres: Record<string, number> = { mm: 0.001, cm: 0.01, m: 1 };
  const fromFactor = metres[from];
  const toFactor = metres[to];
  if (fromFactor === undefined || toFactor === undefined) return null;
  return value * fromFactor / toFactor;
}

function convertArea(value: number, from: string, to: string): number | null {
  const squareMetres: Record<string, number> = {
    mm2: 0.000001,
    cm2: 0.0001,
    m2: 1,
  };
  const fromFactor = squareMetres[from];
  const toFactor = squareMetres[to];
  if (fromFactor === undefined || toFactor === undefined) return null;
  return value * fromFactor / toFactor;
}

function convertVolume(value: number, from: string, to: string): number | null {
  const cubicMetres: Record<string, number> = {
    mm3: 0.000000001,
    cm3: 0.000001,
    m3: 1,
  };
  const fromFactor = cubicMetres[from];
  const toFactor = cubicMetres[to];
  if (fromFactor === undefined || toFactor === undefined) return null;
  return value * fromFactor / toFactor;
}

export function normalizeTayqanMeasurementValue(
  value: number,
  sourceUnit: string | null,
  expectedUnit: string | null,
): number {
  if (!Number.isFinite(value) || value < 0) {
    throw new Error("TAYQAN measurement inputs must be finite, non-negative values.");
  }

  const expected = canonicalUnit(expectedUnit);
  const source = canonicalUnit(sourceUnit);

  if (expected === null) {
    if (source !== null && !["nr", "unit", "units"].includes(source)) {
      throw new Error(`Dimensionless input cannot consume source unit "${sourceUnit}".`);
    }
    return value;
  }

  if (source === null) {
    throw new Error(`A source unit is required for an input whose canonical unit is "${expectedUnit}".`);
  }

  if (source === expected) return value;

  const linear = convertLinear(value, source, expected);
  if (linear !== null) return linear;

  const area = convertArea(value, source, expected);
  if (area !== null) return area;

  const volume = convertVolume(value, source, expected);
  if (volume !== null) return volume;

  if (expected === "kg" && source === "g") return value / 1_000;
  if (expected === "kg" && source === "t") return value * 1_000;
  if (expected === "kg/m" && source === "g/m") return value / 1_000;
  if (expected === "%" && source === "%") return value;

  throw new Error(`Cannot normalize source unit "${sourceUnit}" to required unit "${expectedUnit}".`);
}

function integerInputKey(key: string): boolean {
  return ["verifiedCount", "faces", "coats"].includes(key);
}

export function evaluateTayqanMeasurementSubject(
  rawSubject: unknown,
  context: TayqanMeasurementEvaluationContext,
): EvaluatedTayqanMeasurement {
  const subject = tayqanMeasurementSubjectSchema.parse(rawSubject);

  if (subject.existingEntityId && !context.allowedEntityIds.has(subject.existingEntityId)) {
    throw new Error("TAYQAN measurement referenced an extracted entity outside the frozen source scope.");
  }

  const primaryPage = context.pagesById.get(subject.primaryPageId);
  if (!primaryPage) {
    throw new Error("TAYQAN measurement referenced a primary page outside the frozen source scope.");
  }

  for (const pageId of subject.evidencePageIds) {
    if (!context.pagesById.has(pageId)) {
      throw new Error("TAYQAN measurement referenced evidence outside the frozen source scope.");
    }
  }

  const definition = getRequiredDimensions(subject.calculationType);
  if (!definition) {
    throw new Error(`TAYQAN selected unsupported deterministic calculation type "${subject.calculationType}".`);
  }

  const supported = new Set(listSupportedCalculationTypes());
  if (!supported.has(subject.calculationType)) {
    throw new Error(`TAYQAN selected a calculation type not registered for deterministic evaluation: "${subject.calculationType}".`);
  }

  const inputDefinitions = new Map(definition.inputs.map((input) => [input.key, input]));
  const normalizedInputValues: Record<string, number> = {};
  const seen = new Set<string>();
  const inputConfidences: number[] = [];

  for (const input of subject.inputs) {
    const definitionInput = inputDefinitions.get(input.key);
    if (!definitionInput) {
      throw new Error(`TAYQAN supplied unexpected input "${input.key}" for ${subject.calculationType}.`);
    }
    if (seen.has(input.key)) {
      throw new Error(`TAYQAN supplied duplicate input "${input.key}".`);
    }
    seen.add(input.key);

    for (const roomId of input.evidenceRoomIds) {
      if (!context.allowedRoomIds.has(roomId)) {
        throw new Error(`Input "${input.key}" cites room geometry outside the frozen source scope.`);
      }
    }
    if (input.derivation === "ROOM_GEOMETRY" && input.evidenceRoomIds.length === 0) {
      throw new Error(`Input "${input.key}" claims room geometry without citing a stored room.`);
    }

    for (const pageId of input.evidencePageIds) {
      const page = context.pagesById.get(pageId);
      if (!page) {
        throw new Error(`Input "${input.key}" cites a page outside the frozen source scope.`);
      }
      if (input.derivation === "VERIFIED_SCALE_GEOMETRY" && !page.scaleVerified) {
        throw new Error(`Input "${input.key}" attempted scaled geometry on an unverified drawing scale.`);
      }
    }

    const normalized = normalizeTayqanMeasurementValue(
      input.value,
      input.unit,
      definitionInput.unit,
    );

    if (integerInputKey(input.key) && !Number.isInteger(normalized)) {
      throw new Error(`Input "${input.key}" must be an integer.`);
    }

    normalizedInputValues[input.key] = normalized;
    inputConfidences.push(input.confidence);
  }

  for (const required of definition.inputs.filter((input) => input.required)) {
    if (normalizedInputValues[required.key] === undefined) {
      throw new Error(`TAYQAN did not provide required evidence-backed input "${required.key}".`);
    }
  }

  const computed = definition.compute(normalizedInputValues);
  if (!Number.isFinite(computed.resultValue) || computed.resultValue < 0) {
    throw new Error("Deterministic TAYQAN formula returned an invalid result.");
  }
  if (computed.resultUnit !== definition.resultUnit) {
    throw new Error("Deterministic TAYQAN formula returned an unexpected result unit.");
  }

  const confidence = Math.min(
    subject.confidence,
    ...(inputConfidences.length > 0 ? inputConfidences : [subject.confidence]),
  );

  return {
    subject,
    normalizedInputValues,
    formula: computed.formula,
    resultValue: computed.resultValue,
    resultUnit: computed.resultUnit,
    deductions: computed.deductions ?? null,
    allowances: computed.allowances ?? null,
    confidence,
  };
}
