import type { Prisma } from "@prisma/client";
import type { TayqanMeasurementPlan } from "@/lib/tayqan/tayqan-measurement-contract";

export type TayqanMeasurementPageRole =
  | "PLAN"
  | "SECTION"
  | "SCHEDULE"
  | "DETAIL"
  | "MEP"
  | "OTHER";

export type TayqanMeasurementPageEvidence = {
  id: string;
  projectFileId: string;
  originalName: string;
  pageNumber: number;
  drawingNumber: string | null;
  drawingTitle: string | null;
  revisionNumber: string | null;
  discipline: string | null;
  drawingType: string | null;
  sheetName: string | null;
  role: TayqanMeasurementPageRole;
  width: number | null;
  height: number | null;
  dpi: number | null;
  text: string | null;
  drawingTitles: string[];
  technicalLines: string[];
  detectedScale: string | null;
  scaleVerified: boolean;
  scaleRatio: number | null;
  drawingUnit: string | null;
  realWorldUnit: string | null;
  hasImage: boolean;
};

export type TayqanMeasurementExistingEntityEvidence = {
  id: string;
  projectFileId: string;
  drawingPageId: string | null;
  entityType: string;
  label: string;
  quantity: number | null;
  unit: string | null;
  confidence: number;
  status: string;
  sourceText: string | null;
  sourceReference: string | null;
  technicalData: Prisma.JsonValue | null;
};

export type TayqanMeasurementRoomEvidence = {
  id: string;
  drawingPageId: string | null;
  roomName: string;
  roomNumber: string | null;
  area: number | null;
  perimeter: number | null;
  ceilingHeight: number | null;
  floorLevel: string | null;
  confidence: number;
  status: string;
};

export type TayqanMeasurementEvidenceBundle = {
  project: {
    id: string;
    slug: string;
    name: string;
    reference: string;
  };
  sourceFileIds: string[];
  pages: TayqanMeasurementPageEvidence[];
  existingEntities: TayqanMeasurementExistingEntityEvidence[];
  rooms: TayqanMeasurementRoomEvidence[];
};

export type TayqanMeasurementCluster = {
  key: string;
  discipline: string;
  pageIds: string[];
};

export type TayqanMeasurementReasonerInput = {
  bundle: TayqanMeasurementEvidenceBundle;
  loadPageImageDataUrl: (pageId: string) => Promise<string | null>;
};

export type TayqanMeasurementReasonerResult = {
  provider: string;
  model: string;
  responseIds: string[];
  plan: TayqanMeasurementPlan;
};

export type TayqanMeasurementReasoner = (
  input: TayqanMeasurementReasonerInput,
) => Promise<TayqanMeasurementReasonerResult>;

function normalized(value: string | null | undefined): string {
  return (value ?? "").trim().toUpperCase();
}

export function classifyTayqanDrawingPageRole(input: {
  drawingType?: string | null;
  drawingTitle?: string | null;
  sheetName?: string | null;
  drawingTitles?: readonly string[];
  discipline?: string | null;
}): TayqanMeasurementPageRole {
  const haystack = [
    input.drawingType,
    input.drawingTitle,
    input.sheetName,
    ...(input.drawingTitles ?? []),
  ]
    .map(normalized)
    .filter(Boolean)
    .join(" ");

  if (/\bSCHEDULE\b/.test(haystack)) return "SCHEDULE";
  if (/\bSECTION\b|\bELEVATION\b/.test(haystack)) return "SECTION";
  if (/\bDETAIL\b/.test(haystack)) return "DETAIL";
  if (/\bPLAN\b|\bLAYOUT\b|\bGA\b/.test(haystack)) return "PLAN";

  const discipline = normalized(input.discipline);
  if (/MEP|HVAC|MECHANICAL|ELECTRICAL|PLUMBING|FIRE|ELV/.test(discipline)) {
    return "MEP";
  }
  return "OTHER";
}

/**
 * Deterministic page clustering: every source page appears as a primary page
 * at least once. Section/schedule/detail pages are repeated as cross-page
 * anchors inside their discipline so plan measurements can be reconciled
 * with heights, schedules and details without a model deciding which pages
 * are allowed to exist.
 */
export function buildTayqanMeasurementClusters(
  pages: readonly TayqanMeasurementPageEvidence[],
  maximumPagesPerCluster = 6,
): TayqanMeasurementCluster[] {
  if (maximumPagesPerCluster < 2) {
    throw new Error("TAYQAN measurement clusters require at least two page slots.");
  }

  const groups = new Map<string, TayqanMeasurementPageEvidence[]>();
  for (const page of pages) {
    const discipline = normalized(page.discipline) || "UNSPECIFIED";
    const current = groups.get(discipline) ?? [];
    current.push(page);
    groups.set(discipline, current);
  }

  const clusters: TayqanMeasurementCluster[] = [];
  for (const [discipline, groupPages] of groups) {
    const anchors = groupPages
      .filter((page) => ["SCHEDULE", "SECTION", "DETAIL"].includes(page.role))
      .slice(0, 2);

    const anchorIds = new Set(anchors.map((page) => page.id));
    const primaryPages = groupPages.filter((page) => !anchorIds.has(page.id));
    const primaryChunkSize = Math.max(1, maximumPagesPerCluster - anchors.length);

    const primaryChunks = primaryPages.length > 0
      ? Array.from(
          { length: Math.ceil(primaryPages.length / primaryChunkSize) },
          (_, index) => primaryPages.slice(index * primaryChunkSize, (index + 1) * primaryChunkSize),
        )
      : [[]];

    for (const [index, primaryChunk] of primaryChunks.entries()) {
      const combined = [...primaryChunk, ...anchors]
        .filter((page, pageIndex, all) => all.findIndex((candidate) => candidate.id === page.id) === pageIndex)
        .slice(0, maximumPagesPerCluster);
      if (combined.length === 0) continue;
      clusters.push({
        key: `${discipline}:${index + 1}`,
        discipline,
        pageIds: combined.map((page) => page.id),
      });
    }
  }

  const covered = new Set(clusters.flatMap((cluster) => cluster.pageIds));
  for (const page of pages) {
    if (!covered.has(page.id)) {
      clusters.push({
        key: `${normalized(page.discipline) || "UNSPECIFIED"}:recovery:${page.pageNumber}`,
        discipline: normalized(page.discipline) || "UNSPECIFIED",
        pageIds: [page.id],
      });
    }
  }

  return clusters;
}
