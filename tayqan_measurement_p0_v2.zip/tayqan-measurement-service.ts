import { createHash } from "node:crypto";
import {
  ExtractedEntityStatus,
  ExtractionMethod,
  Prisma,
} from "@prisma/client";
import type { CurrentActor } from "@/lib/auth/current-actor";
import { requireCapability } from "@/lib/auth/rbac";
import { prisma } from "@/lib/db/prisma";
import { AppError } from "@/lib/errors/app-error";
import { createAuditLog } from "@/lib/repositories/audit-repository";
import { getProjectRecord } from "@/lib/repositories/project-repository";
import { createStorageAdapter, resolveStorageProvider } from "@/lib/storage/storage-factory";
import type { DocumentStorageAdapter } from "@/lib/storage/document-storage-adapter";
import {
  evaluateTayqanMeasurementSubject,
  TAYQAN_MEASUREMENT_CALCULATED_BY_PREFIX,
  TAYQAN_MEASUREMENT_VERSION,
  type EvaluatedTayqanMeasurement,
  type TayqanMeasurementException,
} from "@/lib/tayqan/tayqan-measurement-contract";
import { createOpenAITayqanMeasurementReasoner } from "@/lib/tayqan/openai-tayqan-measurement-reasoner";
import {
  classifyTayqanDrawingPageRole,
  type TayqanMeasurementEvidenceBundle,
  type TayqanMeasurementPageEvidence,
  type TayqanMeasurementReasoner,
} from "@/lib/tayqan/tayqan-measurement-reasoner";
import type { PageTextExtraction } from "@/lib/files/pdf-text-extraction";

const MAX_PAGE_IMAGE_BYTES = 20 * 1024 * 1024;
const ACTIVE_ENTITY_STATUSES = [
  ExtractedEntityStatus.EXTRACTED,
  ExtractedEntityStatus.NEEDS_REVIEW,
  ExtractedEntityStatus.CONFIRMED,
  ExtractedEntityStatus.CORRECTED,
] as const;

let storageAdapter: DocumentStorageAdapter | null = null;
function getStorageAdapter(): DocumentStorageAdapter {
  if (!storageAdapter) {
    storageAdapter = createStorageAdapter({
      provider: resolveStorageProvider(),
      purpose: "project-files",
    });
  }
  return storageAdapter;
}

function jsonRecord(value: Prisma.JsonValue | null): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, unknown>
    : {};
}

function normalizedLabel(value: string): string {
  return value.trim().toLowerCase().replace(/\s+/g, " ");
}

function fingerprintMeasurement(evaluated: EvaluatedTayqanMeasurement): string {
  return createHash("sha256")
    .update(JSON.stringify({
      version: TAYQAN_MEASUREMENT_VERSION,
      existingEntityId: evaluated.subject.existingEntityId,
      primaryPageId: evaluated.subject.primaryPageId,
      evidencePageIds: [...evaluated.subject.evidencePageIds].sort(),
      entityType: evaluated.subject.entityType,
      label: normalizedLabel(evaluated.subject.label),
      calculationType: evaluated.subject.calculationType,
      inputValues: evaluated.normalizedInputValues,
      formula: evaluated.formula,
      resultValue: evaluated.resultValue,
      resultUnit: evaluated.resultUnit,
    }))
    .digest("hex")
    .slice(0, 24);
}

function sourceText(page: { textLayerJson: Prisma.JsonValue | null }): PageTextExtraction | null {
  const value = page.textLayerJson;
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as unknown as PageTextExtraction;
}

export type PrepareTayqanMeasurementsInput = {
  projectId: string;
  sourceFileIds: readonly string[];
};

export type PrepareTayqanMeasurementsResult = {
  measuredSubjectCount: number;
  createdEntityCount: number;
  reusedEntityCount: number;
  createdCalculationCount: number;
  reusedCalculationCount: number;
  exceptionCount: number;
  exceptions: TayqanMeasurementException[];
  provider: string;
  model: string;
};

export type PrepareTayqanMeasurementsOptions = {
  reasoner?: TayqanMeasurementReasoner;
  env?: NodeJS.ProcessEnv;
};

async function buildEvidenceBundle(
  actor: CurrentActor,
  projectIdentifier: string,
  input: PrepareTayqanMeasurementsInput,
): Promise<{
  bundle: TayqanMeasurementEvidenceBundle;
  imageStorageKeyByPageId: Map<string, string>;
}> {
  const project = await getProjectRecord(actor.companyId, projectIdentifier);
  if (project.id !== input.projectId) {
    throw new AppError(
      "TAYQAN_MEASUREMENT_PROJECT_MISMATCH",
      "TAYQAN measurement input belongs to another project.",
      403,
    );
  }

  const sourceFileIds = [...new Set(input.sourceFileIds.map((id) => id.trim()).filter(Boolean))];
  if (sourceFileIds.length === 0) {
    throw new AppError(
      "TAYQAN_MEASUREMENT_SOURCES_REQUIRED",
      "TAYQAN needs the frozen source-file scope before measuring the drawings.",
      409,
    );
  }

  const files = await prisma.projectFile.findMany({
    where: {
      companyId: actor.companyId,
      projectId: project.id,
      id: { in: sourceFileIds },
      status: { not: "ARCHIVED" },
    },
    select: {
      id: true,
      originalName: true,
      drawingNumber: true,
      drawingTitle: true,
      revisionNumber: true,
      scaleText: true,
      metadataJson: true,
    },
  });
  if (files.length !== sourceFileIds.length) {
    throw new AppError(
      "TAYQAN_MEASUREMENT_SOURCE_SCOPE_INVALID",
      "One or more frozen TAYQAN source files are missing, archived, or outside this project.",
      409,
    );
  }

  const fileById = new Map(files.map((file) => [file.id, file]));
  const pages = await prisma.drawingPage.findMany({
    where: {
      companyId: actor.companyId,
      projectFileId: { in: sourceFileIds },
    },
    orderBy: [{ projectFileId: "asc" }, { pageNumber: "asc" }],
  });

  if (pages.length === 0) {
    throw new AppError(
      "TAYQAN_MEASUREMENT_PAGES_REQUIRED",
      "TAYQAN cannot measure these sources because no processed drawing pages exist yet.",
      409,
    );
  }

  const calibrations = await prisma.drawingScaleCalibration.findMany({
    where: {
      companyId: actor.companyId,
      drawingPageId: { in: pages.map((page) => page.id) },
    },
    orderBy: { createdAt: "desc" },
  });
  const calibrationByPageId = new Map<string, (typeof calibrations)[number]>();
  for (const calibration of calibrations) {
    if (!calibrationByPageId.has(calibration.drawingPageId)) {
      calibrationByPageId.set(calibration.drawingPageId, calibration);
    }
  }

  const pageEvidence: TayqanMeasurementPageEvidence[] = pages.map((page) => {
    const file = fileById.get(page.projectFileId);
    if (!file) throw new Error("TAYQAN page resolved to a source file outside its frozen scope.");
    const metadata = jsonRecord(file.metadataJson);
    const text = sourceText(page);
    const calibration = calibrationByPageId.get(page.id) ?? null;
    const discipline = typeof metadata.discipline === "string" ? metadata.discipline : null;
    const drawingType = typeof metadata.drawingType === "string" ? metadata.drawingType : null;
    const drawingTitles = text?.signals?.drawingTitles ?? [];

    return {
      id: page.id,
      projectFileId: page.projectFileId,
      originalName: file.originalName,
      pageNumber: page.pageNumber,
      drawingNumber: file.drawingNumber,
      drawingTitle: file.drawingTitle,
      revisionNumber: file.revisionNumber,
      discipline,
      drawingType,
      sheetName: page.sheetName,
      role: classifyTayqanDrawingPageRole({
        drawingType,
        drawingTitle: file.drawingTitle,
        sheetName: page.sheetName,
        drawingTitles,
        discipline,
      }),
      width: page.width,
      height: page.height,
      dpi: page.dpi,
      text: text?.text ?? null,
      drawingTitles,
      technicalLines: text?.signals?.technicalLines ?? [],
      detectedScale: page.detectedScale ?? file.scaleText,
      scaleVerified: calibration?.isVerified === true,
      scaleRatio: calibration?.scaleRatio.toNumber() ?? null,
      drawingUnit: calibration?.drawingUnit ?? null,
      realWorldUnit: calibration?.realWorldUnit ?? null,
      hasImage: Boolean(page.imageStorageKey),
    };
  });

  const entities = await prisma.extractedEntity.findMany({
    where: {
      companyId: actor.companyId,
      projectId: project.id,
      projectFileId: { in: sourceFileIds },
      status: { in: [...ACTIVE_ENTITY_STATUSES] },
    },
    orderBy: { createdAt: "asc" },
  });

  const rooms = await prisma.detectedRoom.findMany({
    where: {
      companyId: actor.companyId,
      projectId: project.id,
      drawingPageId: { in: pages.map((page) => page.id) },
      status: { in: [...ACTIVE_ENTITY_STATUSES] },
    },
    orderBy: { createdAt: "asc" },
  });

  return {
    bundle: {
      project: {
        id: project.id,
        slug: project.slug,
        name: project.name,
        reference: project.reference,
      },
      sourceFileIds,
      pages: pageEvidence,
      existingEntities: entities.map((entity) => ({
        id: entity.id,
        projectFileId: entity.projectFileId,
        drawingPageId: entity.drawingPageId,
        entityType: entity.entityType,
        label: entity.label,
        quantity: entity.quantity?.toNumber() ?? null,
        unit: entity.unit,
        confidence: entity.confidence.toNumber(),
        status: entity.status,
        sourceText: entity.sourceText,
        sourceReference: entity.sourceReference,
        technicalData: entity.technicalDataJson,
      })),
      rooms: rooms.map((room) => ({
        id: room.id,
        drawingPageId: room.drawingPageId,
        roomName: room.roomName,
        roomNumber: room.roomNumber,
        area: room.area?.toNumber() ?? null,
        perimeter: room.perimeter?.toNumber() ?? null,
        ceilingHeight: room.ceilingHeight?.toNumber() ?? null,
        floorLevel: room.floorLevel,
        confidence: room.confidence.toNumber(),
        status: room.status,
      })),
    },
    imageStorageKeyByPageId: new Map(
      pages.flatMap((page) => page.imageStorageKey ? [[page.id, page.imageStorageKey] as const] : []),
    ),
  };
}

async function resolveOrCreateMeasurementEntity(
  db: Prisma.TransactionClient,
  actor: CurrentActor,
  projectId: string,
  evaluated: EvaluatedTayqanMeasurement,
  pageById: ReadonlyMap<string, { projectFileId: string; originalName: string }>,
  fingerprint: string,
) {
  if (evaluated.subject.existingEntityId) {
    const existing = await db.extractedEntity.findFirst({
      where: {
        id: evaluated.subject.existingEntityId,
        companyId: actor.companyId,
        projectId,
        status: { in: [...ACTIVE_ENTITY_STATUSES] },
      },
    });
    if (!existing) {
      throw new AppError(
        "TAYQAN_MEASUREMENT_ENTITY_CHANGED",
        "An extracted entity changed while TAYQAN was preparing measurements. Restart the work order against the current evidence.",
        409,
      );
    }
    return { entity: existing, created: false };
  }

  const primaryPage = pageById.get(evaluated.subject.primaryPageId);
  if (!primaryPage) {
    throw new Error("TAYQAN measurement primary page has no source file.");
  }
  const primaryProjectFileId = primaryPage.projectFileId;
  const marker = `TAYQAN_MEASUREMENT:${fingerprint}`;
  const existing = await db.extractedEntity.findFirst({
    where: {
      companyId: actor.companyId,
      projectId,
      projectFileId: primaryProjectFileId,
      drawingPageId: evaluated.subject.primaryPageId,
      extractionMethod: ExtractionMethod.VISION_MODEL,
      sourceReference: { contains: marker },
    },
  });
  if (existing) return { entity: existing, created: false };

  const entity = await db.extractedEntity.create({
    data: {
      companyId: actor.companyId,
      projectId,
      projectFileId: primaryProjectFileId,
      drawingPageId: evaluated.subject.primaryPageId,
      entityType: evaluated.subject.entityType,
      label: evaluated.subject.label,
      normalizedLabel: normalizedLabel(evaluated.subject.label),
      quantity: null,
      unit: null,
      confidence: evaluated.confidence,
      extractionMethod: ExtractionMethod.VISION_MODEL,
      sourceText: evaluated.subject.sourceSummary,
      sourceReference: `${primaryPage.originalName} · ${marker}`,
      technicalDataJson: {
        tayqanMeasurementVersion: TAYQAN_MEASUREMENT_VERSION,
        measurementFingerprint: fingerprint,
        evidencePageIds: evaluated.subject.evidencePageIds,
        calculationType: evaluated.subject.calculationType,
        rationale: evaluated.subject.rationale,
      },
      status: ExtractedEntityStatus.NEEDS_REVIEW,
    },
  });
  return { entity, created: true };
}

export async function prepareTayqanMeasurementProposals(
  actor: CurrentActor,
  projectIdentifier: string,
  input: PrepareTayqanMeasurementsInput,
  options: PrepareTayqanMeasurementsOptions = {},
): Promise<PrepareTayqanMeasurementsResult> {
  requireCapability(actor, "boq:edit");
  const { bundle, imageStorageKeyByPageId } = await buildEvidenceBundle(
    actor,
    projectIdentifier,
    input,
  );

  const env = options.env ?? process.env;
  const apiKey = env.OPENAI_API_KEY?.trim();
  const model = env.TAYQAN_MEASUREMENT_MODEL?.trim()
    || env.WORKER_AI_MODEL?.trim()
    || "gpt-5";
  const reasoner = options.reasoner ?? (() => {
    if (!apiKey) {
      throw new AppError(
        "TAYQAN_MEASUREMENT_AI_NOT_CONFIGURED",
        "TAYQAN drawing measurement requires the configured server-side AI provider before it can prepare a quantity-complete draft.",
        503,
      );
    }
    return createOpenAITayqanMeasurementReasoner({ apiKey, model });
  })();

  const result = await reasoner({
    bundle,
    loadPageImageDataUrl: async (pageId) => {
      const key = imageStorageKeyByPageId.get(pageId);
      if (!key) return null;
      const buffer = await getStorageAdapter().getObject(key);
      if (buffer.byteLength > MAX_PAGE_IMAGE_BYTES) {
        throw new AppError(
          "TAYQAN_MEASUREMENT_PAGE_TOO_LARGE",
          "A rendered drawing page is too large for bounded AI measurement analysis. Re-render the page at the standard processing resolution instead of sending an unbounded image.",
          409,
        );
      }
      return `data:image/png;base64,${buffer.toString("base64")}`;
    },
  });

  const allowedEntityIds = new Set(bundle.existingEntities.map((entity) => entity.id));
  const allowedRoomIds = new Set(bundle.rooms.map((room) => room.id));
  const pagesById = new Map(
    bundle.pages.map((page) => [page.id, {
      projectFileId: page.projectFileId,
      scaleVerified: page.scaleVerified,
    }] as const),
  );
  const pageById = new Map(
    bundle.pages.map((page) => [page.id, {
      projectFileId: page.projectFileId,
      originalName: page.originalName,
    }] as const),
  );

  const evaluated = result.plan.subjects.map((subject) =>
    evaluateTayqanMeasurementSubject(subject, { allowedEntityIds, allowedRoomIds, pagesById }),
  );

  let createdEntityCount = 0;
  let reusedEntityCount = 0;
  let createdCalculationCount = 0;
  let reusedCalculationCount = 0;

  for (const measurement of evaluated) {
    const fingerprint = fingerprintMeasurement(measurement);

    const persisted = await prisma.$transaction(async (tx) => {
      const { entity, created } = await resolveOrCreateMeasurementEntity(
        tx,
        actor,
        bundle.project.id,
        measurement,
        pageById,
        fingerprint,
      );

      const calculatedBy = `${TAYQAN_MEASUREMENT_CALCULATED_BY_PREFIX}${fingerprint}`;
      let calculation = await tx.quantityCalculation.findFirst({
        where: {
          companyId: actor.companyId,
          projectId: bundle.project.id,
          extractedEntityId: entity.id,
          calculatedBy,
        },
        orderBy: { createdAt: "desc" },
      });

      let calculationCreated = false;
      if (!calculation) {
        calculation = await tx.quantityCalculation.create({
          data: {
            companyId: actor.companyId,
            projectId: bundle.project.id,
            extractedEntityId: entity.id,
            calculationType: measurement.subject.calculationType,
            inputValuesJson: measurement.normalizedInputValues,
            deductionsJson: measurement.deductions ?? undefined,
            allowancesJson: measurement.allowances ?? undefined,
            formula: measurement.formula,
            resultValue: measurement.resultValue,
            resultUnit: measurement.resultUnit,
            confidence: measurement.confidence,
            status: ExtractedEntityStatus.EXTRACTED,
            calculatedBy,
          },
        });
        calculationCreated = true;

        await createAuditLog(actor.companyId, {
          entityType: "QuantityCalculation",
          entityId: calculation.id,
          action: "TAYQAN_MEASUREMENT_PROPOSED",
          actorName: actor.fullName,
          payload: {
            projectId: bundle.project.id,
            extractedEntityId: entity.id,
            measurementVersion: TAYQAN_MEASUREMENT_VERSION,
            fingerprint,
            calculationType: measurement.subject.calculationType,
            evidencePageIds: measurement.subject.evidencePageIds,
            normalizedInputValues: measurement.normalizedInputValues,
            formula: measurement.formula,
            resultValue: measurement.resultValue,
            resultUnit: measurement.resultUnit,
            confidence: measurement.confidence,
            rationale: measurement.subject.rationale,
            sourceSummary: measurement.subject.sourceSummary,
            provider: result.provider,
            model: result.model,
            providerResponseIds: result.responseIds,
            professionallyConfirmed: false,
          },
        }, tx);
      }

      return { entityCreated: created, calculationCreated };
    }, {
      maxWait: 10_000,
      timeout: 20_000,
    });

    if (persisted.entityCreated) createdEntityCount += 1;
    else reusedEntityCount += 1;
    if (persisted.calculationCreated) createdCalculationCount += 1;
    else reusedCalculationCount += 1;
  }

  await createAuditLog(actor.companyId, {
    entityType: "Project",
    entityId: bundle.project.id,
    action: "TAYQAN_MEASUREMENT_PASS_COMPLETED",
    actorName: actor.fullName,
    payload: {
      measurementVersion: TAYQAN_MEASUREMENT_VERSION,
      sourceFileCount: bundle.sourceFileIds.length,
      pageCount: bundle.pages.length,
      measuredSubjectCount: evaluated.length,
      createdEntityCount,
      reusedEntityCount,
      createdCalculationCount,
      reusedCalculationCount,
      exceptionCount: result.plan.exceptions.length,
      provider: result.provider,
      model: result.model,
      professionallyConfirmed: false,
    },
  });

  return {
    measuredSubjectCount: evaluated.length,
    createdEntityCount,
    reusedEntityCount,
    createdCalculationCount,
    reusedCalculationCount,
    exceptionCount: result.plan.exceptions.length,
    exceptions: result.plan.exceptions,
    provider: result.provider,
    model: result.model,
  };
}
