# TAYQAN Measurement Intelligence P0 — Audit, Architecture & Runbook

## Audited baseline

- Repository: `vistabylara-dev/quantara-ai-boq`
- Exact base SHA: `50de95e451bc8874de99e6973d571b2567888ea6`
- Rebase audit: previous audited base `95e72e6d36b455965e0c3b85663c820f55893de4` → current main is 6 commits ahead; changes are confined to public marketing/SEO and admin sample-BOQ files. All existing files modified by this package retain identical blob SHAs.
- Base state includes merged PR #67.
- This package intentionally does not overlap the open Product Manager PR #66.

The installer aborts if `origin/main` no longer equals the audited SHA. It never rebases, resets, cleans, stashes, merges, deploys, or changes production.

## Product contract

TAYQAN's target responsibility is:

`processed drawings → cross-page reasoning → engineering input normalization → deterministic quantity calculation → unconfirmed AI measurement proposal → Draft BOQ with quantity → engineer unit price + professional review`

TAYQAN does **not** create or infer unit prices in this package.

## Existing Quantara systems deliberately reused

1. Existing source processing / drawing rasterization.
2. Existing page PNG + text layer evidence.
3. Existing structured table/schedule extraction and candidate bridge.
4. Existing `DetectedRoom` geometry.
5. Existing verified scale calibration.
6. Existing `required-dimensions-registry.ts`.
7. Existing deterministic `quantity-formulas.ts`.
8. Existing `QuantityCalculation` table/model — no schema change.
9. Existing AI Draft BOQ service.
10. Existing BOQ quantity provenance.
11. Existing BOQ editor and professional confirmation controls.
12. Existing TAYQAN work-order state machine.

## New files

### `src/lib/tayqan/tayqan-measurement-contract.ts`
Strict contract and deterministic evaluator.

Safety properties:
- only registered Quantara calculation types are allowed;
- required formula inputs must exist;
- units are normalized server-side;
- negative/NaN values are rejected;
- scaled geometry is rejected unless its cited page has a verified scale;
- room-geometry claims must cite stored `DetectedRoom` IDs;
- rates/prices are not a valid formula input;
- model never supplies the final formula result — existing Quantara math does.

### `src/lib/tayqan/tayqan-measurement-reasoner.ts`
Evidence types + deterministic cross-page clustering.

Every page is analyzed at least once. Section/schedule/detail pages become bounded anchors repeated with same-discipline plan chunks so cross-page evidence can be correlated without silently omitting pages.

### `src/lib/tayqan/openai-tayqan-measurement-reasoner.ts`
Server-only bounded multimodal adapter.

- Reads rendered drawing images through the existing storage abstraction.
- Uses base64 image inputs; no public source URLs are created.
- Sends a maximum of six related pages per reasoning call.
- Maximum concurrency is two.
- Output is strict structured JSON.
- The prompt explicitly forbids rate/cost/price/margin output.
- Insufficient or conflicting evidence must be emitted as an exception rather than guessed.
- `VERIFIED_SCALE_GEOMETRY` is accepted by the server only when scale verification already exists.

### `src/lib/services/tayqan-measurement-service.ts`
Measurement orchestration and persistence.

- Uses the TAYQAN frozen source-file scope.
- Loads only non-archived source files from the same company/project.
- Loads DrawingPage images/text and source-scoped DetectedRoom records.
- Loads active ExtractedEntity candidates from the same frozen source files.
- Evaluates every AI proposal with the deterministic formula registry.
- Existing extracted data is not overwritten.
- New visual-only scope is stored as `VISION_MODEL` + `NEEDS_REVIEW`.
- Proposed measurements are stored as existing `QuantityCalculation` rows with status `EXTRACTED`.
- No `confirmedByUserId` or `confirmedAt` is fabricated.
- Every measurement has a deterministic fingerprint for idempotent retry.
- Each entity/calculation pair is persisted atomically in a short transaction.
- If the run stops halfway, completed proposals can be reused safely on retry.
- Audit logs store formula, normalized inputs, evidence page IDs, confidence and provider response IDs.

## Surgical modifications

### `src/lib/services/tayqan-work-order-service.ts`
For `COMPLETE_BOQ_FROM_SOURCES` / `UPDATE_EXISTING_BOQ` only:

`SOURCE_PROCESSING → TAYQAN measurement pass → AI Draft BOQ`

The measurement summary is stored in existing `progressJson`; no Prisma field is added.

### `src/lib/services/ai-draft-boq-service.ts`
Adds an opt-in quantity mode:

- default: `EXTRACTION_ONLY` — existing Quantara self-service behavior unchanged;
- TAYQAN: `TAYQAN_MEASUREMENT_PROPOSAL` — prefers latest TAYQAN `QuantityCalculation` result.

TAYQAN quantity provenance receives the existing `quantityCalculationId` and remains `LEGACY_UNVERIFIED` until a real professional confirms it. If a TAYQAN calculation is later genuinely confirmed, existing `CONFIRMED_CALCULATION` provenance can be used.

Unit cost remains `0` / unverified exactly as the current AI Draft behavior already requires.

### EN / AR dictionaries
Adds only `tayqan.hire.workflow.measurementComplete`.

## Protected systems — must remain unchanged

- `prisma/schema.prisma`
- `prisma/migrations/**`
- production DB / data
- Stripe products/prices/provider mappings
- Stripe checkout/webhooks/billing portal
- refunds
- subscriptions/entitlements
- catalogue/package activation
- authentication/RBAC
- BOQ lock/issue/approve logic
- schema-recovery routes/mechanisms
- package.json / package-lock.json
- local rescue/handoff files

The installer scans changed paths and stops on protected patterns.

## Known engineering boundary

This is an **AI measurement proposal**, not a contractual survey certification.

- Explicit printed dimensions and schedule values can be used directly as evidence.
- Existing room geometry can be used when cited.
- Geometry inferred from drawing scale is permitted only when the existing scale calibration is verified.
- If a required dimension is absent or conflicting, the model must emit an exception rather than fabricate it.
- No confidence score can lock, issue, approve or professionally confirm a BOQ.

## Zero-credit test strategy

`tests/tayqan-measurement-contract.test.ts` does not call OpenAI.
It proves:
- mm → m and engineering unit normalization;
- cross-page wall-length + section-height + schedule-opening calculation;
- deterministic formula result;
- unverified scale geometry is rejected;
- commercial/unit-price inputs are rejected;
- page clustering preserves all pages and cross-page anchors.

## Apply

1. Download/extract this package anywhere on the Windows PC.
2. From PowerShell, run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
& "C:\path\to\tayqan_measurement_p0\install-tayqan-measurement-p0.ps1"
```

Default repo expected:

`C:\Users\PC\Desktop\quantara-ai-boq`

The script creates:

`C:\Users\PC\Desktop\quantara-ai-boq\.worktrees\tayqan-measurement-p0-20260817`

Branch:

`feat/tayqan-measurement-intelligence-p0-20260817`

It does **not** commit, push, merge or deploy.

## Mandatory post-apply evidence

Copy the PowerShell output back into ChatGPT. Do not troubleshoot by running Prisma commands.

The next acceptance gate is a real project/drawing fixture proving:

`processed pages → TAYQAN measurement proposals → QuantityCalculation rows → Draft BOQ quantities → unit price remains for engineer`

Only after that evidence should the branch be considered for commit/PR.


## V3 Windows installer hardening

- Patch anchors are evaluated against LF-normalized content and original CRLF/LF line endings are preserved on write.
- All existing-file anchors are preflighted in memory before any file is written.
- If the exact prior isolated worktree exists from the CRLF-anchor failure, V3 resumes only when HEAD/branch match the audited baseline and the only changes are the five expected untracked TAYQAN files. It removes only those files and reuses the worktree.

## V4 validation repair

V3 applied the nine-file patch successfully but full-repo TypeScript validation exposed a stale generated Prisma client plus one patch-local ES2020 compatibility error (`String.replaceAll`). V4 verifies the five V3-added files by exact SHA-256 before replacing them with audited V4 versions. It fixes the ES2020 issue, requires stored `ROOM_GEOMETRY` to be backed by a verified scale calibration, requires every input evidence page to be present in the subject provenance set, and uses a clean-baseline delta TypeScript comparison. It does not run `prisma generate`, migrations, reset, seed, or any database command.
