const fs = require("node:fs");

const [baselinePath, patchedPath] = process.argv.slice(2);
if (!baselinePath || !patchedPath) {
  throw new Error("Usage: node compare-tsc-errors.cjs <baseline-output> <patched-output>");
}

function normalizeMessage(message) {
  return message
    .replace(/\\/g, "/")
    .replace(/[A-Z]:\/[^'\"\s]+\/node_modules\//gi, "node_modules/")
    .replace(/\s+/g, " ")
    .trim();
}

function extract(file) {
  const text = fs.readFileSync(file, "utf8").replace(/\r\n/g, "\n");
  const counts = new Map();
  const details = new Map();
  const re = /^(.*?):\d+:\d+\s+-\s+error\s+(TS\d+):\s+(.*)$/gm;
  let match;
  let total = 0;
  while ((match = re.exec(text)) !== null) {
    total += 1;
    const sourceFile = match[1].replace(/\\/g, "/").trim();
    const code = match[2];
    const message = normalizeMessage(match[3]);
    const key = `${sourceFile}|${code}|${message}`;
    counts.set(key, (counts.get(key) || 0) + 1);
    details.set(key, `${sourceFile} ${code}: ${message}`);
  }
  return { counts, details, total };
}

const baseline = extract(baselinePath);
const patched = extract(patchedPath);
const introduced = [];
const resolved = [];

for (const [key, patchedCount] of patched.counts) {
  const baselineCount = baseline.counts.get(key) || 0;
  if (patchedCount > baselineCount) {
    introduced.push({ key, count: patchedCount - baselineCount });
  }
}
for (const [key, baselineCount] of baseline.counts) {
  const patchedCount = patched.counts.get(key) || 0;
  if (baselineCount > patchedCount) {
    resolved.push({ key, count: baselineCount - patchedCount });
  }
}

console.log(`Baseline TypeScript errors:             ${baseline.total}`);
console.log(`Patched TypeScript errors:              ${patched.total}`);
console.log(`New errors introduced by patch:         ${introduced.reduce((n, x) => n + x.count, 0)}`);
console.log(`Baseline errors resolved by patch:      ${resolved.reduce((n, x) => n + x.count, 0)}`);

if (introduced.length > 0) {
  console.error("\nNEW TYPESCRIPT ERRORS INTRODUCED BY PATCH:");
  for (const item of introduced) {
    console.error(`- x${item.count} ${patched.details.get(item.key)}`);
  }
  process.exit(1);
}

console.log("\nPASS: patched worktree introduces no new TypeScript errors versus the exact clean baseline under the same installed dependencies.");
