import { ExtractedEntityType } from "@prisma/client";
import {
  listSupportedCalculationTypes,
} from "@/lib/calculations/required-dimensions-registry";
import {
  tayqanMeasurementPlanSchema,
  type TayqanMeasurementPlan,
} from "@/lib/tayqan/tayqan-measurement-contract";
import {
  buildTayqanMeasurementClusters,
  type TayqanMeasurementEvidenceBundle,
  type TayqanMeasurementReasoner,
  type TayqanMeasurementReasonerResult,
} from "@/lib/tayqan/tayqan-measurement-reasoner";

const MAX_PAGE_TEXT = 8_000;
const MAX_ENTITY_TEXT = 2_000;
const MAX_CLUSTER_CONCURRENCY = 2;

function record(value: unknown): Record<string, unknown> | null {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, unknown>
    : null;
}

function extractOutputText(response: Record<string, unknown>): string {
  if (typeof response.output_text === "string" && response.output_text.trim()) {
    return response.output_text;
  }
  if (!Array.isArray(response.output)) {
    throw new Error("OpenAI TAYQAN measurement response did not contain structured output.");
  }
  for (const output of response.output) {
    const outputRecord = record(output);
    if (!Array.isArray(outputRecord?.content)) continue;
    for (const content of outputRecord.content) {
      const contentRecord = record(content);
      if (contentRecord?.type === "refusal") {
        throw new Error("OpenAI refused the bounded TAYQAN measurement request.");
      }
      if (contentRecord?.type === "output_text" && typeof contentRecord.text === "string") {
        return contentRecord.text;
      }
    }
  }
  throw new Error("OpenAI TAYQAN measurement response did not contain structured output text.");
}

const measurementPlanJsonSchema = {
  type: "object",
  additionalProperties: false,
  required: ["subjects", "exceptions"],
  properties: {
    subjects: {
      type: "array",
      maxItems: 250,
      items: {
        type: "object",
        additionalProperties: false,
        required: [
          "existingEntityId",
          "primaryPageId",
          "evidencePageIds",
          "entityType",
          "label",
          "calculationType",
          "inputs",
          "rationale",
          "sourceSummary",
          "confidence",
        ],
        properties: {
          existingEntityId: { type: ["string", "null"] },
          primaryPageId: { type: "string" },
          evidencePageIds: { type: "array", minItems: 1, maxItems: 12, items: { type: "string" } },
          entityType: { type: "string", enum: Object.values(ExtractedEntityType) },
          label: { type: "string", minLength: 1, maxLength: 240 },
          calculationType: { type: "string", enum: listSupportedCalculationTypes() },
          inputs: {
            type: "array",
            minItems: 1,
            maxItems: 16,
            items: {
              type: "object",
              additionalProperties: false,
              required: ["key", "value", "unit", "derivation", "evidencePageIds", "evidenceRoomIds", "confidence"],
              properties: {
                key: { type: "string", minLength: 1, maxLength: 80 },
                value: { type: "number", minimum: 0 },
                unit: { type: ["string", "null"] },
                derivation: {
                  type: "string",
                  enum: [
                    "EXPLICIT_DIMENSION",
                    "SCHEDULE_VALUE",
                    "COUNT_RECONCILIATION",
                    "ROOM_GEOMETRY",
                    "VERIFIED_SCALE_GEOMETRY",
                  ],
                },
                evidencePageIds: { type: "array", minItems: 1, maxItems: 8, items: { type: "string" } },
                evidenceRoomIds: { type: "array", maxItems: 8, items: { type: "string" } },
                confidence: { type: "number", minimum: 0, maximum: 100 },
              },
            },
          },
          rationale: { type: "string", minLength: 1, maxLength: 2_000 },
          sourceSummary: { type: "string", minLength: 1, maxLength: 2_000 },
          confidence: { type: "number", minimum: 0, maximum: 100 },
        },
      },
    },
    exceptions: {
      type: "array",
      maxItems: 250,
      items: {
        type: "object",
        additionalProperties: false,
        required: ["kind", "message", "pageIds", "relatedEntityId"],
        properties: {
          kind: {
            type: "string",
            enum: [
              "INSUFFICIENT_EVIDENCE",
              "SCALE_REQUIRED",
              "AMBIGUOUS_SCOPE",
              "CROSS_PAGE_CONFLICT",
              "UNSUPPORTED_FORMULA",
            ],
          },
          message: { type: "string", minLength: 1, maxLength: 1_500 },
          pageIds: { type: "array", maxItems: 12, items: { type: "string" } },
          relatedEntityId: { type: ["string", "null"] },
        },
      },
    },
  },
} as const;

function clusterContext(
  bundle: TayqanMeasurementEvidenceBundle,
  pageIds: readonly string[],
) {
  const pageSet = new Set(pageIds);
  const pages = bundle.pages
    .filter((page) => pageSet.has(page.id))
    .map((page) => ({
      id: page.id,
      projectFileId: page.projectFileId,
      file: page.originalName,
      pageNumber: page.pageNumber,
      drawingNumber: page.drawingNumber,
      drawingTitle: page.drawingTitle,
      revisionNumber: page.revisionNumber,
      discipline: page.discipline,
      drawingType: page.drawingType,
      sheetName: page.sheetName,
      role: page.role,
      text: page.text?.slice(0, MAX_PAGE_TEXT) ?? null,
      drawingTitles: page.drawingTitles,
      technicalLines: page.technicalLines,
      detectedScale: page.detectedScale,
      scaleVerified: page.scaleVerified,
      scaleRatio: page.scaleRatio,
      drawingUnit: page.drawingUnit,
      realWorldUnit: page.realWorldUnit,
      hasImage: page.hasImage,
    }));

  const fileIds = new Set(pages.map((page) => page.projectFileId));
  const entities = bundle.existingEntities
    .filter((entity) =>
      (entity.drawingPageId && pageSet.has(entity.drawingPageId))
      || fileIds.has(entity.projectFileId),
    )
    .slice(0, 120)
    .map((entity) => ({
      ...entity,
      sourceText: entity.sourceText?.slice(0, MAX_ENTITY_TEXT) ?? null,
      technicalData: entity.technicalData,
    }));

  const rooms = bundle.rooms
    .filter((room) => !room.drawingPageId || pageSet.has(room.drawingPageId))
    .slice(0, 100);

  return {
    project: bundle.project,
    pages,
    existingEntities: entities,
    rooms,
  };
}

function mergePlans(plans: readonly TayqanMeasurementPlan[]): TayqanMeasurementPlan {
  const subjects = [] as TayqanMeasurementPlan["subjects"];
  const exceptions = [] as TayqanMeasurementPlan["exceptions"];
  const seenSubjectKeys = new Set<string>();
  const seenExceptionKeys = new Set<string>();

  for (const plan of plans) {
    for (const subject of plan.subjects) {
      const key = subject.existingEntityId
        ? `existing:${subject.existingEntityId}:${subject.calculationType}`
        : `new:${subject.entityType}:${subject.label.trim().toLowerCase()}:${subject.calculationType}:${subject.primaryPageId}`;
      if (seenSubjectKeys.has(key)) continue;
      seenSubjectKeys.add(key);
      subjects.push(subject);
    }
    for (const exception of plan.exceptions) {
      const key = `${exception.kind}:${exception.relatedEntityId ?? ""}:${exception.message}:${[...exception.pageIds].sort().join(",")}`;
      if (seenExceptionKeys.has(key)) continue;
      seenExceptionKeys.add(key);
      exceptions.push(exception);
    }
  }

  return tayqanMeasurementPlanSchema.parse({ subjects, exceptions });
}

async function mapWithConcurrency<T, R>(
  values: readonly T[],
  concurrency: number,
  mapper: (value: T, index: number) => Promise<R>,
): Promise<R[]> {
  const output = new Array<R>(values.length);
  let cursor = 0;

  async function worker() {
    for (;;) {
      const index = cursor;
      cursor += 1;
      if (index >= values.length) return;
      output[index] = await mapper(values[index]!, index);
    }
  }

  await Promise.all(
    Array.from({ length: Math.min(concurrency, values.length) }, () => worker()),
  );
  return output;
}

export function createOpenAITayqanMeasurementReasoner(
  config: { apiKey: string; model: string },
  fetchImpl: typeof fetch = fetch,
): TayqanMeasurementReasoner {
  return async (input): Promise<TayqanMeasurementReasonerResult> => {
    const clusters = buildTayqanMeasurementClusters(input.bundle.pages, 6);
    const responseIds: string[] = [];

    const plans = await mapWithConcurrency(
      clusters,
      MAX_CLUSTER_CONCURRENCY,
      async (cluster) => {
        const context = clusterContext(input.bundle, cluster.pageIds);
        const content: Array<Record<string, unknown>> = [{
          type: "input_text",
          text: JSON.stringify({
            instruction: [
              "Act as a bounded construction quantity-surveying measurement reasoner.",
              "Understand related information across the supplied plan/section/schedule/detail pages.",
              "Identify BOQ-measurable scope and evidence-backed deterministic-formula inputs only.",
              "Never output a unit price, rate, cost, margin, total, or commercial value.",
              "Never calculate the final quantity yourself; the server will apply its deterministic formula registry.",
              "Every numeric input must be grounded in explicit dimensions, schedules, reconciled counts, stored room geometry, or geometry from a VERIFIED scale.",
              "Detected/unverified scale text is context only and must never authorize scaled geometry.",
              "Printed dimensions may be used without a verified drawing scale because they are explicit evidence.",
              "If evidence is insufficient or conflicting, create an exception instead of guessing.",
              "Reuse existingEntityId when the measurable scope is clearly the same existing extracted candidate. Otherwise return null and describe a new evidence-backed scope item.",
              "Use only supplied page IDs, existing entity IDs and stored room IDs.",
              "ROOM_GEOMETRY inputs must cite stored room IDs whose scaleVerified field is true; otherwise use explicit printed dimensions/schedule evidence or create a SCALE_REQUIRED exception.",
              "Every input evidencePageId must also appear in that subject's evidencePageIds so persisted provenance is complete.",
            ].join("\n"),
            clusterKey: cluster.key,
            context,
          }),
        }];

        for (const pageId of cluster.pageIds) {
          const page = input.bundle.pages.find((candidate) => candidate.id === pageId);
          if (!page?.hasImage) continue;
          const imageDataUrl = await input.loadPageImageDataUrl(pageId);
          if (!imageDataUrl) continue;
          content.push({
            type: "input_text",
            text: `PAGE_IMAGE id=${page.id} file=${page.originalName} page=${page.pageNumber} drawing=${page.drawingNumber ?? ""} title=${page.drawingTitle ?? ""}`,
          });
          content.push({
            type: "input_image",
            image_url: imageDataUrl,
            detail: "high",
          });
        }

        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 60_000);
        let response: Response;
        try {
          response = await fetchImpl("https://api.openai.com/v1/responses", {
            method: "POST",
            headers: {
              Authorization: `Bearer ${config.apiKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: config.model,
              input: [{ role: "user", content }],
              text: {
                format: {
                  type: "json_schema",
                  name: "tayqan_measurement_plan",
                  strict: true,
                  schema: measurementPlanJsonSchema,
                },
              },
            }),
            signal: controller.signal,
          });
        } finally {
          clearTimeout(timeout);
        }

        if (!response.ok) {
          throw new Error(`OpenAI TAYQAN measurement request failed with status ${response.status}.`);
        }
        const raw = await response.json() as Record<string, unknown>;
        if (typeof raw.id === "string") responseIds.push(raw.id);

        let decoded: unknown;
        try {
          decoded = JSON.parse(extractOutputText(raw));
        } catch (error) {
          if (error instanceof SyntaxError) {
            throw new Error("OpenAI TAYQAN measurement reasoner returned invalid structured JSON.");
          }
          throw error;
        }
        return tayqanMeasurementPlanSchema.parse(decoded);
      },
    );

    return {
      provider: "openai",
      model: config.model,
      responseIds,
      plan: mergePlans(plans),
    };
  };
}
