param(
    [string]$Repo = "$env:USERPROFILE\Desktop\quantara-ai-boq",
    [string]$Worktree = "$env:USERPROFILE\Desktop\quantara-ai-boq\.worktrees\tayqan-measurement-p0-20260817"
)

$ErrorActionPreference = "Stop"
$ExpectedBase = "50de95e451bc8874de99e6973d571b2567888ea6"
$ExpectedBranch = "feat/tayqan-measurement-intelligence-p0-20260817"
$ExpectedV3NewFileSha256 = @{
    "src/lib/tayqan/tayqan-measurement-contract.ts" = "bb9939b15eec3d7437994e97101409283f30a1c30962ead5aca3aa2b1df706d6"
    "src/lib/tayqan/tayqan-measurement-reasoner.ts" = "25eb8b7ee0f6b720d90c43b2d93e2ddaa31a674cf2e82ee66de90a80ee913f24"
    "src/lib/tayqan/openai-tayqan-measurement-reasoner.ts" = "73565b88344108c9ef8615c0fbbf50b959644cae18e96afad2c50c83679ea39e"
    "src/lib/services/tayqan-measurement-service.ts" = "f3bd7b3b77f0092821be25df16aa8c903788802fe3ce3b55c51e324e08e60c7d"
    "tests/tayqan-measurement-contract.test.ts" = "fa881f0a80c136e0d860c37852074616e8fc1adac5673ebf99c61442ce0de5e5"
}
$PackageDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "=== TAYQAN MEASUREMENT P0 V4 — REPAIR + BASELINE-DELTA VALIDATION ===" -ForegroundColor Cyan
Write-Host "No Prisma commands. No reset. No clean. No commit. No push. No merge. No deploy." -ForegroundColor DarkGray

if (-not (Test-Path (Join-Path $Repo ".git"))) {
    throw "STOP: Quantara repo not found at $Repo"
}
if (-not (Test-Path $Worktree)) {
    throw "STOP: Expected isolated TAYQAN worktree is missing at $Worktree. Do not recreate it manually."
}

Set-Location $Repo
git fetch origin main
if ($LASTEXITCODE -ne 0) { throw "STOP: git fetch failed." }
$originMain = (git rev-parse origin/main).Trim()
if ($originMain -ne $ExpectedBase) {
    throw "STOP: origin/main moved again. Expected $ExpectedBase but found $originMain. Do not validate against an unaudited base."
}

$head = (git -C $Worktree rev-parse HEAD).Trim()
$branch = (git -C $Worktree branch --show-current).Trim()
if ($head -ne $ExpectedBase -or $branch -ne $ExpectedBranch) {
    throw "STOP: Isolated worktree identity mismatch. Head=$head Branch=$branch"
}

$allowedChanges = @(
    "src/lib/tayqan/tayqan-measurement-contract.ts",
    "src/lib/tayqan/tayqan-measurement-reasoner.ts",
    "src/lib/tayqan/openai-tayqan-measurement-reasoner.ts",
    "src/lib/services/tayqan-measurement-service.ts",
    "tests/tayqan-measurement-contract.test.ts",
    "src/lib/services/ai-draft-boq-service.ts",
    "src/lib/services/tayqan-work-order-service.ts",
    "src/lib/i18n/dictionaries/en.ts",
    "src/lib/i18n/dictionaries/ar.ts"
)

Write-Host "`n=== 1. VERIFY EXACT V3 ISOLATED SCOPE ===" -ForegroundColor Cyan
$statusLines = @(git -C $Worktree status --porcelain=v1 --untracked-files=all)
$changed = @()
foreach ($line in $statusLines) {
    if ($line.Length -lt 4) { continue }
    $file = $line.Substring(3).Replace('\','/')
    $changed += $file
    Write-Host $line
    if ($allowedChanges -notcontains $file) {
        throw "STOP: Unexpected worktree change exists. V4 will not touch it: $file"
    }
}
$unexpectedMissing = @($allowedChanges | Where-Object { $changed -notcontains $_ })
if ($unexpectedMissing.Count -ne 0) {
    throw "STOP: Expected V3 nine-file state is incomplete: $($unexpectedMissing -join ', ')"
}

# Verify distinctive V3 wiring markers before repairing anything.
$markerChecks = @(
    @{ File = "src/lib/services/ai-draft-boq-service.ts"; Marker = 'quantityMode?: "EXTRACTION_ONLY" | "TAYQAN_MEASUREMENT_PROPOSAL";' },
    @{ File = "src/lib/services/ai-draft-boq-service.ts"; Marker = 'quantityCalculationId: tayqanMeasurement?.id ?? null' },
    @{ File = "src/lib/services/tayqan-work-order-service.ts"; Marker = 'prepareTayqanMeasurementProposals' },
    @{ File = "src/lib/services/tayqan-work-order-service.ts"; Marker = 'quantityMode: "TAYQAN_MEASUREMENT_PROPOSAL"' },
    @{ File = "src/lib/i18n/dictionaries/en.ts"; Marker = 'measurementComplete: "TAYQAN completed evidence-backed drawing measurements' },
    @{ File = "src/lib/i18n/dictionaries/ar.ts"; Marker = 'measurementComplete: "اكتملت قياسات TAYQAN' }
)
foreach ($check in $markerChecks) {
    $full = Join-Path $Worktree $check.File
    $text = Get-Content $full -Raw
    if (-not $text.Contains($check.Marker)) {
        throw "STOP: Expected V3 marker missing from $($check.File). No repair performed."
    }
}

Write-Host "`n=== 2. VERIFY + REPLACE ONLY THE FIVE V3-ADDED TAYQAN FILES ===" -ForegroundColor Cyan
$packageFileByTarget = @{
    "src/lib/tayqan/tayqan-measurement-contract.ts" = "tayqan-measurement-contract.ts"
    "src/lib/tayqan/tayqan-measurement-reasoner.ts" = "tayqan-measurement-reasoner.ts"
    "src/lib/tayqan/openai-tayqan-measurement-reasoner.ts" = "openai-tayqan-measurement-reasoner.ts"
    "src/lib/services/tayqan-measurement-service.ts" = "tayqan-measurement-service.ts"
    "tests/tayqan-measurement-contract.test.ts" = "tayqan-measurement-contract.test.ts"
}

# Do not overwrite anything unless all five current files first prove they are
# byte-for-byte the exact V3 files created by our previous package.
foreach ($target in $packageFileByTarget.Keys) {
    $currentPath = Join-Path $Worktree $target
    if (-not (Test-Path $currentPath)) { throw "STOP: Expected V3 file is missing: $target" }
    $currentHash = (Get-FileHash $currentPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($currentHash -ne $ExpectedV3NewFileSha256[$target]) {
        throw "STOP: Refusing to overwrite a TAYQAN file that no longer exactly matches V3: $target SHA256=$currentHash"
    }
}

foreach ($target in $packageFileByTarget.Keys) {
    $sourcePath = Join-Path $PackageDir $packageFileByTarget[$target]
    $targetPath = Join-Path $Worktree $target
    if (-not (Test-Path $sourcePath)) { throw "STOP: V4 package file missing: $sourcePath" }
    Copy-Item $sourcePath $targetPath -Force
    $sourceHash = (Get-FileHash $sourcePath -Algorithm SHA256).Hash.ToLowerInvariant()
    $targetHash = (Get-FileHash $targetPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($sourceHash -ne $targetHash) { throw "STOP: V4 copy verification failed for $target" }
}
Write-Host "PASS: five V3-added files upgraded to V4 after exact SHA-256 verification." -ForegroundColor Green
Write-Host "V4 fixes ES2020 compatibility and closes unverified ROOM_GEOMETRY / incomplete evidence-page provenance." -ForegroundColor Green
Write-Host "No existing shared service, Prisma, package or Stripe file was overwritten by this repair step." -ForegroundColor Green

Write-Host "`n=== 3. FILE-SCOPE + FORBIDDEN-AREA AUDIT ===" -ForegroundColor Cyan
$statusAfter = @(git -C $Worktree status --porcelain=v1 --untracked-files=all)
$changedAfter = @()
foreach ($line in $statusAfter) {
    if ($line.Length -lt 4) { continue }
    $file = $line.Substring(3).Replace('\','/')
    $changedAfter += $file
    if ($allowedChanges -notcontains $file) {
        throw "STOP: A file outside the exact nine-file TAYQAN scope changed: $file"
    }
}
$missingAfter = @($allowedChanges | Where-Object { $changedAfter -notcontains $_ })
if ($missingAfter.Count -ne 0) { throw "STOP: Nine-file TAYQAN scope is incomplete after repair." }

$forbiddenPatterns = @(
    '^prisma/',
    '^package\.json$',
    '^package-lock\.json$',
    '^src/lib/services/stripe-',
    '^src/lib/services/refund-',
    '^src/lib/services/catalogue-',
    '^src/lib/services/industry-package-',
    '^src/app/api/admin/system-health/schema-recovery/'
)
foreach ($file in $changedAfter) {
    foreach ($pattern in $forbiddenPatterns) {
        if ($file -match $pattern) { throw "STOP: Protected area changed: $file" }
    }
}
Write-Host "PASS: exactly nine approved TAYQAN files; no protected area changed." -ForegroundColor Green

Set-Location $Worktree
Write-Host "`n=== 4. DIFF CHECK ===" -ForegroundColor Cyan
git diff --check
if ($LASTEXITCODE -ne 0) { throw "STOP: git diff --check failed." }
Write-Host "PASS: git diff --check" -ForegroundColor Green

$rootNodeModules = Join-Path $Repo "node_modules"
$vitest = Join-Path $rootNodeModules ".bin\vitest.cmd"
$tsc = Join-Path $rootNodeModules ".bin\tsc.cmd"
$eslint = Join-Path $rootNodeModules ".bin\eslint.cmd"

if (Test-Path $vitest) {
    Write-Host "`n=== 5. FOCUSED TAYQAN CONTRACT TEST — ZERO OPENAI CALLS ===" -ForegroundColor Cyan
    & $vitest run tests/tayqan-measurement-contract.test.ts
    if ($LASTEXITCODE -ne 0) { throw "STOP: focused TAYQAN measurement contract test failed." }
    Write-Host "PASS: focused TAYQAN measurement contract test" -ForegroundColor Green
} else {
    throw "STOP: Vitest binary is missing from the existing repo node_modules."
}

if (-not (Test-Path $tsc)) { throw "STOP: TypeScript binary is missing from existing repo node_modules." }

Write-Host "`n=== 6. TYPESCRIPT BASELINE-DELTA CHECK — NO PRISMA GENERATE ===" -ForegroundColor Cyan
Write-Host "The installed Prisma client is stale, so clean main is expected to have existing errors. V4 fails only if this patch adds an error beyond that exact baseline." -ForegroundColor Yellow

$baselineWorktree = Join-Path $Repo ".worktrees\tayqan-ts-baseline-$PID"
$baselineLog = Join-Path $env:TEMP "tayqan-ts-baseline-$PID.txt"
$patchedLog = Join-Path $env:TEMP "tayqan-ts-patched-$PID.txt"

if (Test-Path $baselineWorktree) { throw "STOP: Temporary baseline validation worktree unexpectedly already exists: $baselineWorktree" }

Set-Location $Repo
git worktree add --detach $baselineWorktree $ExpectedBase
if ($LASTEXITCODE -ne 0) { throw "STOP: Could not create temporary clean baseline validation worktree." }

$oldNativePreference = $null
$hadNativePreference = Test-Path Variable:PSNativeCommandUseErrorActionPreference
if ($hadNativePreference) { $oldNativePreference = $PSNativeCommandUseErrorActionPreference }
$PSNativeCommandUseErrorActionPreference = $false

try {
    Set-Location $baselineWorktree
    & $tsc --noEmit --incremental false -p (Join-Path $baselineWorktree "tsconfig.json") *> $baselineLog
    $baselineExit = $LASTEXITCODE

    Set-Location $Worktree
    & $tsc --noEmit --incremental false -p (Join-Path $Worktree "tsconfig.json") *> $patchedLog
    $patchedExit = $LASTEXITCODE

    Write-Host "Clean baseline tsc exit: $baselineExit"
    Write-Host "Patched worktree tsc exit: $patchedExit"

    node (Join-Path $PackageDir "compare-tsc-errors.cjs") $baselineLog $patchedLog
    if ($LASTEXITCODE -ne 0) {
        Write-Host "`n--- PATCHED TSC OUTPUT ---" -ForegroundColor Red
        Get-Content $patchedLog | Select-Object -First 220
        throw "STOP: TAYQAN patch introduces TypeScript error(s) beyond the exact clean baseline."
    }
} finally {
    if ($hadNativePreference) { $PSNativeCommandUseErrorActionPreference = $oldNativePreference }
    Set-Location $Repo
    if (Test-Path $baselineWorktree) {
        git worktree remove --force $baselineWorktree | Out-Null
    }
    Remove-Item $baselineLog,$patchedLog -Force -ErrorAction SilentlyContinue
    Set-Location $Worktree
}

if (Test-Path $eslint) {
    Write-Host "`n=== 7. FOCUSED ESLINT ===" -ForegroundColor Cyan
    & $eslint `
      src/lib/tayqan/tayqan-measurement-contract.ts `
      src/lib/tayqan/tayqan-measurement-reasoner.ts `
      src/lib/tayqan/openai-tayqan-measurement-reasoner.ts `
      src/lib/services/tayqan-measurement-service.ts `
      src/lib/services/ai-draft-boq-service.ts `
      src/lib/services/tayqan-work-order-service.ts `
      tests/tayqan-measurement-contract.test.ts `
      --max-warnings=0
    if ($LASTEXITCODE -ne 0) { throw "STOP: focused ESLint failed. Do not commit." }
    Write-Host "PASS: focused ESLint" -ForegroundColor Green
} else {
    throw "STOP: ESLint binary is missing from existing repo node_modules."
}

Write-Host "`n=== 8. FINAL ISOLATED STATUS ===" -ForegroundColor Cyan
git status --short
Write-Host "`nV4 VALIDATION COMPLETE." -ForegroundColor Green
Write-Host "The patch remains isolated and is NOT committed, NOT pushed, NOT merged, NOT deployed." -ForegroundColor Green
Write-Host "No Prisma command was run." -ForegroundColor Green
Write-Host "Worktree: $Worktree" -ForegroundColor Green
Write-Host "Branch:   $ExpectedBranch" -ForegroundColor Green
