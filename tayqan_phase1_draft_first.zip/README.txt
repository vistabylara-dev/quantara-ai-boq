TAYQAN Phase 1 — Draft-First Employee Flow

Pinned base:
c61f1a3fd6ae996704e471b96cd4fe29c01872e5

Expected existing worktree:
C:\Users\PC\Desktop\quantara-ai-boq\.worktrees\tayqan-draft-first-20260816

Expected branch:
feat/tayqan-draft-first-20260816

This runner:
- stops if origin/main moved
- stops if the worktree/branch/HEAD is wrong or dirty
- edits exactly six intended files
- does not touch Prisma schema/migrations
- does not touch Stripe, commerce, catalogue, auth or entitlement code
- runs focused AI Draft/TAYQAN/i18n tests
- runs ESLint and repository typecheck
- verifies protected areas remain unchanged
- commits and pushes the feature branch only after every gate passes
- DOES NOT merge

Run:
  $ErrorActionPreference = "Stop"
  $zip  = "$env:USERPROFILE\Downloads\tayqan_phase1_draft_first.zip"
  $dest = "$env:USERPROFILE\Desktop\tayqan_phase1_draft_first"

  if (-not (Test-Path $zip)) { throw "STOP: bundle not found." }
  if (Test-Path $dest) { throw "STOP: destination already exists." }

  Expand-Archive -LiteralPath $zip -DestinationPath $dest
  Set-Location $dest
  powershell -NoProfile -ExecutionPolicy Bypass -File ".\resume.ps1"

Do not merge after the runner. Send the final COMPLETE block back for audit.
