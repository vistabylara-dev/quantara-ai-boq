﻿﻿$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$root   = "$env:USERPROFILE\Desktop\quantara-ai-boq"
$wt     = "$root\.worktrees\tayqan-draft-first-20260816"
$branch = "feat/tayqan-draft-first-20260816"
$base   = "c61f1a3fd6ae996704e471b96cd4fe29c01872e5"

$allowed = @(
    "src/lib/services/ai-draft-boq-service.ts",
    "src/lib/services/tayqan-work-order-service.ts",
    "src/lib/i18n/dictionaries/en.ts",
    "src/lib/i18n/dictionaries/ar.ts",
    "tests/ai-draft-boq-workflow.test.ts",
    "tests/tayqan-complete-workflow.test.ts"
)

function Stop-Run([string]$Message) {
    throw "STOP: $Message"
}

function Replace-Exact {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$Old,
        [Parameter(Mandatory=$true)][string]$New
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        Stop-Run "Required file missing: $Path"
    }

    $raw = [System.IO.File]::ReadAllText($Path)
    $usesCrLf = $raw.Contains("`r`n")
    $text = $raw.Replace("`r`n", "`n")
    $oldNormalized = $Old.Replace("`r`n", "`n")
    $newNormalized = $New.Replace("`r`n", "`n")

    $escaped = [regex]::Escape($oldNormalized)
    $count = ([regex]::Matches($text, $escaped)).Count

    if ($count -ne 1) {
        Stop-Run "Expected exactly one matching pre-image in $Path; found $count. No safe edit performed."
    }

    $updated = $text.Replace($oldNormalized, $newNormalized)

    if ($usesCrLf) {
        $updated = $updated.Replace("`n", "`r`n")
    }

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $updated, $utf8NoBom)
}

Write-Host "`n=== TAYQAN PHASE 1 — DRAFT-FIRST EMPLOYEE FLOW ===" -ForegroundColor Cyan

if (-not (Test-Path -LiteralPath $wt)) {
    Stop-Run "TAYQAN worktree does not exist: $wt"
}

Set-Location $root
git fetch origin

$remoteMain = (git rev-parse origin/main).Trim()
if ($remoteMain -ne $base) {
    Stop-Run "origin/main moved from pinned base $base to $remoteMain. Do not apply this bundle."
}

Set-Location $wt

$actualBranch = (git branch --show-current).Trim()
$actualHead = (git rev-parse HEAD).Trim()
$statusBefore = @(git status --porcelain)

if ($actualBranch -ne $branch) {
    Stop-Run "Wrong branch. Expected $branch, got $actualBranch."
}
if ($actualHead -ne $base) {
    Stop-Run "Wrong HEAD. Expected $base, got $actualHead."
}
if ($statusBefore.Count -gt 0) {
    Write-Host ($statusBefore -join "`n")
    Stop-Run "TAYQAN worktree is not clean."
}

Write-Host "PASS: pinned main / branch / clean worktree" -ForegroundColor Green

foreach ($file in $allowed) {
    if (-not (Test-Path -LiteralPath $file)) {
        Stop-Run "Required file missing: $file"
    }
}

# -------------------------------------------------------------------------
# 1. AI Draft service: add optional target BOQ + explicit frozen-file scope.
#    Defaults remain unchanged for the normal Quantara journey.
# -------------------------------------------------------------------------

$path = "src/lib/services/ai-draft-boq-service.ts"

$old = @'
export async function generateAiDraftBoq(actor: CurrentActor, projectIdentifier: string) {
  requireCapability(actor, "boq:edit");
  const project = await getProjectRecord(actor.companyId, projectIdentifier);

  const latest = await prisma.bOQ.findFirst({
    where: { companyId: actor.companyId, projectId: project.id },
    orderBy: { revisionNumber: "desc" },
    select: { id: true },
  });

  const targetBoqId = latest?.id
    ?? (await createProjectBOQ(actor.companyId, project.id)).id;

  return prisma.$transaction(async (tx) => {
    const current = await getBOQRecord(actor.companyId, targetBoqId, tx);
    assertAiDraftEditable(current);

    const rows = await tx.extractedEntity.findMany({
      where: {
        companyId: actor.companyId,
        projectId: project.id,
        status: { in: ["EXTRACTED", "NEEDS_REVIEW", "CONFIRMED", "CORRECTED"] },
      },
'@

$new = @'
export type AiDraftGenerationOptions = {
  targetBoqId?: string;
  projectFileIds?: readonly string[];
};

export async function generateAiDraftBoq(
  actor: CurrentActor,
  projectIdentifier: string,
  options: AiDraftGenerationOptions = {},
) {
  requireCapability(actor, "boq:edit");
  const project = await getProjectRecord(actor.companyId, projectIdentifier);

  const latest = options.targetBoqId
    ? null
    : await prisma.bOQ.findFirst({
        where: { companyId: actor.companyId, projectId: project.id },
        orderBy: { revisionNumber: "desc" },
        select: { id: true },
      });

  const targetBoqId = options.targetBoqId
    ?? latest?.id
    ?? (await createProjectBOQ(actor.companyId, project.id)).id;

  const explicitSourceScope = options.projectFileIds !== undefined;
  const scopedProjectFileIds = [
    ...new Set(
      (options.projectFileIds ?? [])
        .map((id) => id.trim())
        .filter(Boolean),
    ),
  ];

  if (explicitSourceScope && scopedProjectFileIds.length === 0) {
    throw new ConflictError(
      "AI_DRAFT_SOURCE_SCOPE_EMPTY",
      "The requested AI Draft source scope is empty. Quantara will not silently widen it to unrelated project files.",
    );
  }

  return prisma.$transaction(async (tx) => {
    const current = await getBOQRecord(actor.companyId, targetBoqId, tx);
    assertAiDraftEditable(current);

    if (current.projectId !== project.id) {
      throw new ConflictError(
        "AI_DRAFT_BOQ_PROJECT_MISMATCH",
        "The requested AI Draft BOQ belongs to another project.",
      );
    }

    const rows = await tx.extractedEntity.findMany({
      where: {
        companyId: actor.companyId,
        projectId: project.id,
        ...(scopedProjectFileIds.length > 0
          ? { projectFileId: { in: scopedProjectFileIds } }
          : {}),
        status: { in: ["EXTRACTED", "NEEDS_REVIEW", "CONFIRMED", "CORRECTED"] },
      },
'@

Replace-Exact -Path $path -Old $old -New $new

# -------------------------------------------------------------------------
# 2. TAYQAN service imports and progress contract.
# -------------------------------------------------------------------------

$path = "src/lib/services/tayqan-work-order-service.ts"

Replace-Exact -Path $path -Old @'
  Prisma,
  TayqanIntakeMessageRole,
'@ -New @'
  Prisma,
  QuantityProvenanceSource,
  RateProvenanceSource,
  TayqanIntakeMessageRole,
'@

Replace-Exact -Path $path -Old @'
import { getSourceProcessingCapability } from "@/lib/files/source-processing-capability";
import { extractionJobQueue } from "@/lib/jobs/extraction-worker";
import { createProjectBOQ } from "@/lib/repositories/boq-repository";
'@ -New @'
import { getSourceProcessingCapability } from "@/lib/files/source-processing-capability";
import { getAiDraftExtractedEntityId } from "@/lib/guidance/ai-draft-boq";
import { extractionJobQueue } from "@/lib/jobs/extraction-worker";
import {
  createProjectBOQ,
  getBOQRecord,
} from "@/lib/repositories/boq-repository";
'@

Replace-Exact -Path $path -Old @'
import {
  confirmExtractedEntity,
  correctExtractedEntity,
  rejectExtractedEntity,
} from "@/lib/services/extracted-entity-service";
import { importExtractedEntityToBoq } from "@/lib/services/extraction-to-boq-service";
'@ -New @'
import { generateAiDraftBoq } from "@/lib/services/ai-draft-boq-service";
import {
  confirmExtractedEntity,
  correctExtractedEntity,
  rejectExtractedEntity,
} from "@/lib/services/extracted-entity-service";
import { importExtractedEntityToBoq } from "@/lib/services/extraction-to-boq-service";
'@

Replace-Exact -Path $path -Old @'
  selectedSourceFileIds?: string[];
};
'@ -New @'
  selectedSourceFileIds?: string[];

  /**
   * Draft-first handoff state. Kept inside the EXISTING progressJson so
   * there is no Prisma/schema change. The normal Quantara AI Draft service
   * remains the single implementation of draft creation.
   */
  aiDraft?: {
    boqId: string;
    addedCount: number;
    skippedCount: number;
    alreadyPresentCount: number;
    unreviewedAddedCount: number;
    reviewedAddedCount: number;
  };
};
'@

# -------------------------------------------------------------------------
# 3. Add draft-first helper + professional review aggregation.
# -------------------------------------------------------------------------

$old = @'
function sourceScopedEntityFilter(
  order: {
    progressJson: Prisma.JsonValue | null;
  },
) {
  const sourceFileIds =
    sourceFileIdsFromProgress(order);

  return sourceFileIds.length > 0
    ? {
        projectFileId: {
          in: sourceFileIds,
        },
      }
    : {};
}
'@

$new = @'
function sourceScopedEntityFilter(
  order: {
    progressJson: Prisma.JsonValue | null;
  },
) {
  const sourceFileIds =
    sourceFileIdsFromProgress(order);

  return sourceFileIds.length > 0
    ? {
        projectFileId: {
          in: sourceFileIds,
        },
      }
    : {};
}

function usesDraftFirstWorkflow(
  order: {
    desiredDeliverable: string;
  },
): boolean {
  return (
    order.desiredDeliverable === "COMPLETE_BOQ_FROM_SOURCES"
    || order.desiredDeliverable === "UPDATE_EXISTING_BOQ"
  );
}

function aiDraftBoqHref(
  projectSlug: string,
  summary: WorkProgress["aiDraft"],
): string {
  const params = new URLSearchParams({
    aiDraft: "1",
    added: String(summary?.addedCount ?? 0),
    skipped: String(summary?.skippedCount ?? 0),
    existing: String(summary?.alreadyPresentCount ?? 0),
  });

  return `/projects/${projectSlug}/boq?${params.toString()}`;
}

async function prepareTayqanAiDraft(
  actor: CurrentActor,
  projectSlug: string,
  order: Awaited<ReturnType<typeof loadOrder>>,
) {
  const boqId =
    await ensureWorkingBoq(
      actor,
      projectSlug,
      order,
    );

  const selectedSourceFileIds =
    sourceFileIdsFromProgress(order);

  const result =
    await generateAiDraftBoq(
      actor,
      projectSlug,
      {
        targetBoqId: boqId,
        projectFileIds: selectedSourceFileIds,
      },
    );

  const progress =
    parseProgress(order.progressJson);

  const aiDraft: NonNullable<
    WorkProgress["aiDraft"]
  > = {
    boqId: result.boqId,
    addedCount: result.addedCount,
    skippedCount: result.skippedCount,
    alreadyPresentCount:
      result.alreadyPresentCount,
    unreviewedAddedCount:
      result.unreviewedAddedCount,
    reviewedAddedCount:
      result.reviewedAddedCount,
  };

  await updateOrder(
    actor,
    order.id,
    {
      boqId,
      progressJson: jsonObject({
        ...progress,
        aiDraft,
      }),
      lastAdvancedAt: new Date(),
    },
    "AI_DRAFT_BOQ_GENERATED",
    {
      ...aiDraft,
      selectedSourceCount:
        selectedSourceFileIds.length,
    },
  );

  const loaded =
    await loadOrder(
      actor.companyId,
      order.id,
    );

  if (
    aiDraft.addedCount === 0
    && aiDraft.alreadyPresentCount === 0
  ) {
    return block(
      actor,
      loaded,
      "AI_DRAFT_NO_USABLE_ITEMS",
      "tayqan.hire.workflow.draftNoUsableItems",
      {
        kind: "ACTION",
        i18nKey:
          "tayqan.hire.workflow.draftNoUsableItems",
        actionHref:
          `/projects/${projectSlug}/extractions`,
      },
    );
  }

  const assembly =
    await moveStage(
      actor,
      loaded,
      TayqanWorkStage.BOQ_ASSEMBLY,
      "AI_DRAFT_BOQ_READY_FOR_REVIEW",
    );

  return block(
    actor,
    assembly,
    "AI_DRAFT_REVIEW_REQUIRED",
    "tayqan.hire.workflow.draftReadyForReview",
    {
      kind: "ACTION",
      i18nKey:
        "tayqan.hire.workflow.draftReadyForReview",
      actionHref:
        aiDraftBoqHref(
          projectSlug,
          aiDraft,
        ),
    },
  );
}

async function advanceAiDraftProfessionalReview(
  actor: CurrentActor,
  projectSlug: string,
  order: Awaited<ReturnType<typeof loadOrder>>,
) {
  if (!order.boqId) {
    throw new ConflictError(
      "TAYQAN_BOQ_REQUIRED",
      "TAYQAN needs a working BOQ before professional review.",
    );
  }

  const boq =
    await getBOQRecord(
      actor.companyId,
      order.boqId,
    );

  const aiDraftItems =
    boq.sections
      .flatMap((section) => section.items)
      .filter(
        (item) =>
          getAiDraftExtractedEntityId(
            item.sourceReference,
          ) !== null,
      );

  if (aiDraftItems.length === 0) {
    return block(
      actor,
      order,
      "AI_DRAFT_NO_USABLE_ITEMS",
      "tayqan.hire.workflow.draftNoUsableItems",
      {
        kind: "ACTION",
        i18nKey:
          "tayqan.hire.workflow.draftNoUsableItems",
        actionHref:
          `/projects/${projectSlug}/extractions`,
      },
    );
  }

  const pendingQuantityCount =
    aiDraftItems.filter((item) => {
      const provenance =
        item.quantityProvenance;

      return (
        !provenance
        || provenance.sourceType
          === QuantityProvenanceSource
            .LEGACY_UNVERIFIED
        || provenance.confirmedAt === null
      );
    }).length;

  if (pendingQuantityCount > 0) {
    return block(
      actor,
      order,
      "AI_DRAFT_REVIEW_REQUIRED",
      "tayqan.hire.workflow.draftReadyForReview",
      {
        kind: "ACTION",
        i18nKey:
          "tayqan.hire.workflow.draftReadyForReview",
        actionHref:
          aiDraftBoqHref(
            projectSlug,
            parseProgress(order.progressJson)
              .aiDraft,
          ),
      },
    );
  }

  const remainingExtractionCount =
    await prisma.extractedEntity.count({
      where: {
        companyId: actor.companyId,
        projectId: order.projectId,
        ...sourceScopedEntityFilter(order),
        status: {
          in: [
            ExtractedEntityStatus.EXTRACTED,
            ExtractedEntityStatus.NEEDS_REVIEW,
          ],
        },
      },
    });

  if (remainingExtractionCount > 0) {
    return block(
      actor,
      order,
      "AI_DRAFT_EXCEPTIONS_REMAIN",
      "tayqan.hire.workflow.draftExceptionsRemain",
      {
        kind: "ACTION",
        i18nKey:
          "tayqan.hire.workflow.draftExceptionsRemain",
        actionHref:
          `/projects/${projectSlug}/extractions`,
      },
    );
  }

  if (order.includeRates) {
    const pendingRateCount =
      aiDraftItems.filter((item) => {
        const provenance =
          item.rateProvenance;

        return (
          !provenance
          || provenance.sourceType
            === RateProvenanceSource
              .LEGACY_UNVERIFIED
          || provenance.confirmedAt === null
        );
      }).length;

    if (pendingRateCount > 0) {
      return block(
        actor,
        order,
        "AI_DRAFT_RATES_REMAIN",
        "tayqan.hire.workflow.draftRatesRemain",
        {
          kind: "ACTION",
          i18nKey:
            "tayqan.hire.workflow.draftRatesRemain",
          actionHref:
            aiDraftBoqHref(
              projectSlug,
              parseProgress(order.progressJson)
                .aiDraft,
            ),
        },
      );
    }
  }

  const next =
    await moveStage(
      actor,
      order,
      TayqanWorkStage.VALIDATION,
      "AI_DRAFT_PROFESSIONAL_REVIEW_COMPLETE",
    );

  return advanceValidation(
    actor,
    projectSlug,
    next,
  );
}
'@

Replace-Exact -Path $path -Old $old -New $new

# -------------------------------------------------------------------------
# 4. Source processing: draft-first only for complete/update deliverables.
#    Existing strict/review/takeoff path remains unchanged.
# -------------------------------------------------------------------------

Replace-Exact -Path $path -Old @'
  const next = await moveStage(actor, order, TayqanWorkStage.EVIDENCE_REVIEW, "SOURCE_PROCESSING_COMPLETE");
  return advanceEvidenceReview(actor, projectSlug, next);
'@ -New @'
  if (usesDraftFirstWorkflow(order)) {
    return prepareTayqanAiDraft(
      actor,
      projectSlug,
      order,
    );
  }

  const next = await moveStage(actor, order, TayqanWorkStage.EVIDENCE_REVIEW, "SOURCE_PROCESSING_COMPLETE");
  return advanceEvidenceReview(actor, projectSlug, next);
'@

# -------------------------------------------------------------------------
# 5. Dispatcher: rescue existing pre-upgrade COMPLETE/UPDATE work orders at
#    EVIDENCE_REVIEW, and use BOQ_ASSEMBLY as the draft-review handoff.
# -------------------------------------------------------------------------

Replace-Exact -Path $path -Old @'
    case TayqanWorkStage.EVIDENCE_REVIEW:
      return advanceEvidenceReview(actor, project.slug, order);
'@ -New @'
    case TayqanWorkStage.EVIDENCE_REVIEW:
      if (
        usesDraftFirstWorkflow(order)
        && !parseProgress(order.progressJson)
          .aiDraft
      ) {
        return prepareTayqanAiDraft(
          actor,
          project.slug,
          order,
        );
      }
      return advanceEvidenceReview(actor, project.slug, order);
'@

Replace-Exact -Path $path -Old @'
    case TayqanWorkStage.BOQ_ASSEMBLY:
      return advanceBoqAssembly(actor, project.slug, order);
'@ -New @'
    case TayqanWorkStage.BOQ_ASSEMBLY:
      if (
        parseProgress(order.progressJson)
          .aiDraft
      ) {
        return advanceAiDraftProfessionalReview(
          actor,
          project.slug,
          order,
        );
      }
      return advanceBoqAssembly(actor, project.slug, order);
'@

# -------------------------------------------------------------------------
# 6. English + Arabic delivery copy. No key deletion or rename.
# -------------------------------------------------------------------------

Replace-Exact -Path "src/lib/i18n/dictionaries/en.ts" -Old @'
        reviewEvidence: "I found extracted project evidence that requires a professional decision before I can use it in the BOQ.",
'@ -New @'
        reviewEvidence: "I found extracted project evidence that requires a professional decision before I can use it in the BOQ.",
        draftReadyForReview: "Your AI Draft BOQ is ready. I prepared everything I could use safely without pretending you already approved it. Review or correct the draft quantities in the BOQ, then ask me to check again and I will continue to final QA.",
        draftExceptionsRemain: "Your AI Draft BOQ is already prepared. Some remaining extraction exceptions still need a professional decision before I can complete final QA. Review only those exceptions, then ask me to check again.",
        draftRatesRemain: "Your AI Draft BOQ is ready, but one or more required rates are still unverified. Complete the missing or unconfirmed pricing in the BOQ; I will not invent a commercial rate. Then ask me to check again.",
        draftNoUsableItems: "I processed the selected project sources but could not safely create a BOQ row from the remaining candidates because required quantity or unit evidence is incomplete. Review the extraction exceptions; I will not invent missing values.",
'@

Replace-Exact -Path "src/lib/i18n/dictionaries/ar.ts" -Old @'
        reviewEvidence: "وجدت أدلة مستخرجة من المشروع تحتاج إلى قرار مهني قبل استخدامها في جدول الكميات.",
'@ -New @'
        reviewEvidence: "وجدت أدلة مستخرجة من المشروع تحتاج إلى قرار مهني قبل استخدامها في جدول الكميات.",
        draftReadyForReview: "مسودة جدول الكميات بالذكاء الاصطناعي جاهزة. أعددت كل ما أمكن استخدامه بأمان من دون اعتبارك موافقًا عليه مسبقًا. راجع الكميات في المسودة أو صححها داخل جدول الكميات، ثم اطلب مني التحقق مرة أخرى وسأتابع إلى المراجعة النهائية.",
        draftExceptionsRemain: "مسودة جدول الكميات جاهزة بالفعل. ما زالت بعض استثناءات الاستخراج تحتاج إلى قرار مهني قبل إكمال المراجعة النهائية. راجع هذه الاستثناءات فقط ثم اطلب مني التحقق مرة أخرى.",
        draftRatesRemain: "مسودة جدول الكميات جاهزة، لكن لا يزال هناك سعر واحد أو أكثر غير متحقق منه. أكمل الأسعار المفقودة أو غير المؤكدة داخل جدول الكميات؛ لن أختلق سعرًا تجاريًا. ثم اطلب مني التحقق مرة أخرى.",
        draftNoUsableItems: "عالجت مصادر المشروع المحددة، لكن لا يمكنني إنشاء بند آمن في جدول الكميات من العناصر المتبقية لأن دليل الكمية أو الوحدة المطلوبة غير مكتمل. راجع استثناءات الاستخراج؛ لن أختلق قيمًا مفقودة.",
'@

# -------------------------------------------------------------------------
# 7. Focused regression tests: update TAYQAN contract + lock source scoping.
# -------------------------------------------------------------------------

Replace-Exact -Path "tests/tayqan-complete-workflow.test.ts" -Old @'
  it("requires professional review of extracted evidence instead of auto-confirming it", () => {
    const source = read("src", "lib", "services", "tayqan-work-order-service.ts");
    expect(source).toContain("EVIDENCE_REVIEW_REQUIRED");
    expect(source).toContain("confirmExtractedEntity");
    expect(source).toContain("rejectExtractedEntity");
    expect(source).not.toMatch(/status:\s*ExtractedEntityStatus\.CONFIRMED[\s\S]{0,100}updateMany/);
  });
'@ -New @'
  it("delivers the AI Draft before professional review without auto-confirming extraction", () => {
    const source = read("src", "lib", "services", "tayqan-work-order-service.ts");
    expect(source).toContain("generateAiDraftBoq");
    expect(source).toContain("AI_DRAFT_REVIEW_REQUIRED");
    expect(source).toContain("AI_DRAFT_EXCEPTIONS_REMAIN");
    expect(source).toContain("AI_DRAFT_RATES_REMAIN");
    expect(source).toContain("QuantityProvenanceSource");
    expect(source).toContain("RateProvenanceSource");
    expect(source).toContain("confirmExtractedEntity");
    expect(source).toContain("rejectExtractedEntity");
    expect(source).not.toMatch(/status:\s*ExtractedEntityStatus\.CONFIRMED[\s\S]{0,100}updateMany/);
  });
'@

Replace-Exact -Path "tests/tayqan-complete-workflow.test.ts" -Old @'
  it("assembles through the governed extraction-to-BOQ import service and ends ready for acceptance", () => {
    const source = read("src", "lib", "services", "tayqan-work-order-service.ts");
    expect(source).toContain("importExtractedEntityToBoq");
    expect(source).toContain("enqueueWorkerReview");
    expect(source).toContain("READY_FOR_ACCEPTANCE");
    expect(source).not.toMatch(/status:\s*(?:BOQStatus\.)?(?:LOCKED|ISSUED|APPROVED)/);
  });
'@ -New @'
  it("reuses the normal AI Draft path for complete/update work and preserves the strict legacy path", () => {
    const source = read("src", "lib", "services", "tayqan-work-order-service.ts");
    expect(source).toContain("usesDraftFirstWorkflow");
    expect(source).toContain('order.desiredDeliverable === "COMPLETE_BOQ_FROM_SOURCES"');
    expect(source).toContain('order.desiredDeliverable === "UPDATE_EXISTING_BOQ"');
    expect(source).toContain("projectFileIds: selectedSourceFileIds");
    expect(source).toContain("importExtractedEntityToBoq");
    expect(source).toContain("enqueueWorkerReview");
    expect(source).toContain("READY_FOR_ACCEPTANCE");
    expect(source).not.toMatch(/status:\s*(?:BOQStatus\.)?(?:LOCKED|ISSUED|APPROVED)/);
  });
'@

Replace-Exact -Path "tests/tayqan-complete-workflow.test.ts" -Old @'
    expect(source).toContain(
      "in: sourceFileIds",
    );
  });
'@ -New @'
    expect(source).toContain(
      "in: sourceFileIds",
    );

    expect(source).toContain(
      "projectFileIds: selectedSourceFileIds",
    );
  });
'@

Replace-Exact -Path "tests/ai-draft-boq-workflow.test.ts" -Old @'
  it("exposes all three post-extraction choices and BOQ-level confirmation", () => {
'@ -New @'
  it("allows a delegated worker to pin the target BOQ and frozen source-file scope", () => {
    const service = readFileSync(
      "src/lib/services/ai-draft-boq-service.ts",
      "utf8",
    );

    expect(service).toContain("targetBoqId?: string");
    expect(service).toContain("projectFileIds?: readonly string[]");
    expect(service).toContain("AI_DRAFT_SOURCE_SCOPE_EMPTY");
    expect(service).toContain("AI_DRAFT_BOQ_PROJECT_MISMATCH");
    expect(service).toContain("projectFileId: { in: scopedProjectFileIds }");
  });

  it("exposes all three post-extraction choices and BOQ-level confirmation", () => {
'@

# -------------------------------------------------------------------------
# HARD FILE SCOPE GATE
# -------------------------------------------------------------------------

$changed = @(
    git diff --name-only
) | Where-Object { $_ -and $_.Trim() } | Sort-Object -Unique

$expected = $allowed | Sort-Object -Unique

if ($changed.Count -ne $expected.Count) {
    Write-Host "`nChanged files:" -ForegroundColor Yellow
    $changed | ForEach-Object { Write-Host $_ }
    Stop-Run "Expected exactly $($expected.Count) changed files, found $($changed.Count)."
}

for ($i = 0; $i -lt $expected.Count; $i++) {
    if ($changed[$i] -ne $expected[$i]) {
        Write-Host "`nExpected:" -ForegroundColor Yellow
        $expected | ForEach-Object { Write-Host $_ }
        Write-Host "`nActual:" -ForegroundColor Yellow
        $changed | ForEach-Object { Write-Host $_ }
        Stop-Run "Changed-file scope mismatch."
    }
}

$forbiddenPrefixes = @(
    "prisma/",
    "src/lib/stripe/",
    "src/app/api/webhooks/",
    "src/lib/commerce/",
    "src/lib/auth/",
    "src/lib/entitlements/",
    "src/lib/catalogue/",
    "src/lib/services/tayqan-checkout-service.ts",
    "src/lib/services/tayqan-stripe-fulfillment-service.ts"
)

foreach ($file in $changed) {
    foreach ($prefix in $forbiddenPrefixes) {
        if ($file.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
            Stop-Run "Protected path changed: $file"
        }
    }
}

Write-Host "`nPASS: exact six-file scope; protected areas untouched." -ForegroundColor Green

Write-Host "`n=== DIFF CHECK ===" -ForegroundColor Cyan
git diff --check
if ($LASTEXITCODE -ne 0) { Stop-Run "git diff --check failed." }

Write-Host "`n=== FOCUSED TESTS ===" -ForegroundColor Cyan
npx vitest run `
    tests/ai-draft-boq-workflow.test.ts `
    tests/tayqan-complete-workflow.test.ts `
    tests/i18n-dictionary-parity.test.ts
if ($LASTEXITCODE -ne 0) { Stop-Run "Focused TAYQAN/AI Draft tests failed." }

Write-Host "`n=== ESLINT ===" -ForegroundColor Cyan
npx eslint `
    src/lib/services/ai-draft-boq-service.ts `
    src/lib/services/tayqan-work-order-service.ts `
    src/lib/i18n/dictionaries/en.ts `
    src/lib/i18n/dictionaries/ar.ts `
    tests/ai-draft-boq-workflow.test.ts `
    tests/tayqan-complete-workflow.test.ts
if ($LASTEXITCODE -ne 0) { Stop-Run "ESLint failed." }

Write-Host "`n=== TYPECHECK ===" -ForegroundColor Cyan
npm run typecheck
if ($LASTEXITCODE -ne 0) { Stop-Run "Typecheck failed." }

Write-Host "`n=== FINAL PROTECTED-AREA CHECK ===" -ForegroundColor Cyan
$protectedDiff = @(
    git diff --name-only $base -- `
        prisma/schema.prisma `
        prisma/migrations `
        src/lib/stripe `
        src/app/api/webhooks `
        src/lib/commerce `
        src/lib/auth `
        src/lib/entitlements
) | Where-Object { $_ -and $_.Trim() }

if ($protectedDiff.Count -gt 0) {
    $protectedDiff | ForEach-Object { Write-Host $_ }
    Stop-Run "Protected areas differ from pinned base."
}

Write-Host "PASS: protected areas unchanged." -ForegroundColor Green

Write-Host "`n=== STAGE EXACT FILES ===" -ForegroundColor Cyan
git add -- $allowed

$staged = @(
    git diff --cached --name-only
) | Where-Object { $_ -and $_.Trim() } | Sort-Object -Unique

if ($staged.Count -ne $expected.Count) {
    Stop-Run "Staged file count mismatch."
}

for ($i = 0; $i -lt $expected.Count; $i++) {
    if ($staged[$i] -ne $expected[$i]) {
        Stop-Run "Staged scope mismatch."
    }
}

git diff --cached --check
if ($LASTEXITCODE -ne 0) { Stop-Run "Staged diff check failed." }

Write-Host "`n=== COMMIT ===" -ForegroundColor Cyan
git commit -m "feat: make TAYQAN deliver AI draft before review"
if ($LASTEXITCODE -ne 0) { Stop-Run "Commit failed." }

$commit = (git rev-parse HEAD).Trim()

Write-Host "`n=== PUSH FEATURE BRANCH ===" -ForegroundColor Cyan
git push -u origin $branch
if ($LASTEXITCODE -ne 0) { Stop-Run "Push failed." }

$statusAfter = @(git status --porcelain)
if ($statusAfter.Count -gt 0) {
    Write-Host ($statusAfter -join "`n")
    Stop-Run "Worktree is not clean after commit/push."
}

Write-Host "`n==================================================" -ForegroundColor Green
Write-Host "TAYQAN PHASE 1 DRAFT-FIRST COMPLETE" -ForegroundColor Green
Write-Host "Branch: $branch" -ForegroundColor Green
Write-Host "Base:   $base" -ForegroundColor Green
Write-Host "Commit: $commit" -ForegroundColor Green
Write-Host "Files:  $($allowed.Count)" -ForegroundColor Green
Write-Host "Focused tests: PASS" -ForegroundColor Green
Write-Host "ESLint:        PASS" -ForegroundColor Green
Write-Host "Typecheck:     PASS" -ForegroundColor Green
Write-Host "Prisma/schema: UNCHANGED" -ForegroundColor Green
Write-Host "Stripe:        UNCHANGED" -ForegroundColor Green
Write-Host "Catalogue:     UNCHANGED" -ForegroundColor Green
Write-Host "Auth:          UNCHANGED" -ForegroundColor Green
Write-Host "Database command executed by runner: NO" -ForegroundColor Green
Write-Host "==================================================" -ForegroundColor Green
Write-Host "`nDO NOT MERGE YET. Send this final block for audit." -ForegroundColor Yellow
